medieval source (Project 1320 Perc v0.2.3): everything behind medieval.zip, for anyone who wants to read, change or
rebuild it.

  source/   the drum engine for the Hundekraft Workshop 3.0.3: C source, generated tables, art and font, the bank
            and kit tools, the host tests (harness/), the match test against v0.2.2 (harness/match.sh) and the
            Blackfin cycle bench (harness/cycles/). source/README.md has the build and test steps. The v0.1 synth
            engine is archived in source/synth-engine/. md_bank.h (the EP-1320 audio) is left out: see
            source/README.md, "Build".
  opus/     FEASIBILITY.md: what Opus 2 can and can't run, and what a native port would reuse.
  release/  CHANGELOG.md and test-results.txt (the full output of every test run for v0.2.3). The built .knl files
            and the drum kits are left out: they hold the EP-1320 audio. Build your own from your own exports.

GPL-3.0-or-later with the OP-1 firmware permission (source/LICENSE, source/NOTICE). The EP-1320 audio is Teenage
Engineering's and isn't in this zip: builds you make with it are for your own use.
