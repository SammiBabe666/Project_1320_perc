medieval source (Project 1320 Perc v0.2.3): everything behind medieval.zip, for anyone who wants to read, change or
rebuild it.

  source/   the drum engine for the Hundekraft Workshop 3.0.3: C source, generated tables, art and font, the bank
            and kit tools, the host tests (harness/), the match test against v0.2.2 (harness/match.sh) and the
            Blackfin cycle bench (harness/cycles/). source/README.md has the build and test steps. The v0.1 synth
            engine is archived in source/synth-engine/. md_bank.h (the EP-1320 audio) is left out: see
            source/README.md, "Build".
  opus/     FEASIBILITY.md: what Opus 2 can and can't run, and what a native port would reuse.
  release/  the built files: medieval.knl (v0.2.3) with its SHA-256, older/medieval-v0.2.2.knl, the drum kits
            (medieval-kits.zip), CHANGELOG.md and test-results.txt (the full output of every test run for v0.2.3).

GPL-3.0-or-later with the OP-1 firmware permission (source/LICENSE, source/NOTICE). The EP-1320 audio in the .knl
files and the kits is Teenage Engineering's: keep those files for your own use.
