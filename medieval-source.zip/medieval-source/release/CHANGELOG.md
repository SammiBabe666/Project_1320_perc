# Project 1320 Perc (medieval) changelog

## v0.2.3 (2026-10-31)

The same sound as v0.2.2, sample for sample, with fixes and less processor time.

- **Fixed: a click when a stock kit takes a voice.** When a stock kit's hit took a voice that was still playing a
  medieval sound, and a medieval hit later got that voice back, v0.2.2 faded out the old sample at the start of the
  new hit. In the test that was a step of 5,249 of 32,767, an audible click. The voice now forgets the medieval sound
  when the stock hit takes it (`md_fw.c`, test `test_steal_back`).
- **Safer: a hit while the voice renders.** A new hit now switches the voice off before it fills it and on again
  last, so an audio render that interrupts the hit never mixes the old sound and the new one (`md_voice_on`).
- **Faster: the 16-tap filter.** v0.2.3 does one window copy per source block, instead of a cache lookup with a
  `% 3` on every sample. On the Blackfin, the filter is now one multiply-add per tap with both loads in the same
  instruction. The pad gain is worked out only when the velocity changes. In the Blackfin simulator, one voice takes
  25,448 cycles per render instead of 79,184. Twelve voices at their heaviest take 576,384 at worst instead of
  1,192,990, close to v0.2.1 (516,596), the version that played well on the OP-1. It has not been measured on the
  device.
- **Memory:** `.bss` grew from 5,972 to 7,940 bytes (a 162-byte window per voice), and the render's stack frame
  shrank from 128 to 116 bytes. `medieval.knl` grew from 467,136 to 467,288 bytes.
- **Tests:** added the side-by-side match against v0.2.2 (183 M samples, 0 differ), the Blackfin cycle bench with
  its per-block hash check, and the steal-back test.
- **Built with** GCC 13.3.0 and binutils 2.38. The same toolchain rebuilds v0.2.2's `medieval.knl` byte for byte.
- **Opus 2:** a feasibility study (`opus/FEASIBILITY.md`). The Opus 2 build waits for the new bridge.

## v0.2.2

The sound got cleaner: a 16-point windowed-sinc filter replaced the straight-line resampling, the bank was
re-encoded with a searching ADPCM encoder, and the output is 3 dB lower for headroom.

## v0.2.1

Text was moved off the bottom of the pages, where it was cut off on the device. The scroll and the textura lettering
were added.

## v0.2.0

medieval became a drum engine (the Workshop 3.0.3 drum type hook), with four kits, 96 sounds and the King David
pages. The v0.1 synth engine is archived in `source/synth-engine/`.

## v0.1

A synth engine that played the 24 sounds of a kit across the OP-1's keys.
