# medieval on Opus 2: feasibility

Target: [Opus 2](https://github.com/LizardMan245/opus) for the original OP-1, firmware 246 (not the OP-1 field, not the
OP-XY), plugin kit at opus commit `d7f28b0`. Source: medieval v0.2.3, a drum type for the Hundekraft Workshop 3.0.3.

## Verdict

**Opus 2 can't run medieval as a native drum engine. It can run it as a native synth engine, with the 24 sounds
across the keys. That port is on hold, at your request, until the new bridge ships.**

- The kit's engine service adds **synth engines** only: `opus_engine_add`, listed in the OS's engine list under shift
  + T1 (`docs/api.md`, Engines; `sdk/opus_plugin.h`). The API and header have no drum type, no drum-voice hook and no
  drum page. The only drum calls are effect slots (`OPUS_FX_DRUM`), the instrument now playing
  (`opus_instrument_now`), the current slot (`opus_sound_slot`) and firmware addresses in `op1fw.h`, such as
  `fw_drum_slot_is_kit`. None of them can replace the DrumSampler voice.
- The sampler service (`OPUS_ENGINE_SAMPLE`, core 2.10) plays one synth slot's sample. It isn't a drum kit.
- The repository's README says `opus.bridge` (alpha) runs op1r's and Hundekraft's *synths, effects and sequencers*.
  Drum types aren't listed, so `medieval.knl` (a drum type) isn't expected to run on the current bridge. This wasn't
  tried: the bridge isn't in the kit, and there is no OP-1 here.
- Patching the DrumSampler ourselves (`place` lines at its vtable, as the Workshop core does) would make a deep plugin
  tied to firmware addresses that the kit doesn't document for drums. The kit's rules say to do that only when no
  `opus_*` service does the job, and only with verified addresses. Guessing them isn't safe next to someone's tape.

## What a native Opus synth engine would reuse

| Part | Reuse | Why |
|---|---|---|
| `md_voice.c`, `md_voice.h`: ADPCM decoding, the 16-tap filter, decay, drive, dusk, age, click guards | **As is**, almost | Pure C, integer only, no firmware addresses, no allocation, fixed per-voice state. Two inputs change: the rate (Opus gives 128 phase steps at 88.2 kHz, so the source step is the sound's 44.1 kHz step halved) and the pad gain (Opus's OS applies the envelope and the velocity, so `md_gain` would be dropped). |
| `md_bank.h`, `md_tables.h`, `md_names.h`, `kits.py`, the tools | **As is** | Data. 436,608 bytes of bank fits a plugin image (1 MB at most). |
| `md_fw.c`: the drum hooks, the pad and velocity reads, `"op1r"` JSON persistence | **Rewrite** | No drum hook in Opus. As an engine: `init`/`note_on`/`release`/`render`/`finished` in `struct opus_engine`. The pad comes from the pitch (nearest semitone, as v0.1's synth engine did) and the per-kit values from the sound's knobs. The per-pad sounds and starts are saved with `opus_engine_data` (256 bytes: 24 x 2 bytes fit). |
| `md_page.c`: the King David scene | **Adapt** | The scene's maths stays. The drawing moves from the Workshop raster to `opus_page_*` and `opus_path_*` calls in the display thread, with the still parts as SVG art (`opus_art_*`), as the kit's outatime example does. |
| One-shot / gate | **Adapt** | `OPUS_ENGINE_OWN_ENVELOPE` with `finished`: a hit plays out after the key is let go and frees its voice when the sound ends. Gate would become a knob or a setting, because synth sounds have no pad words. |
| 12 voices, 24 pads, drum sequencers, drum-mode tape | **Lost** | A synth engine gets the OS's 6 synth voices and synth mode's keys and sequencers. |

Costs on Opus: the render runs at 88.2 kHz (128 samples a block, twice the drum voice's rate per hit), so one voice
would cost about what one v0.2.3 drum voice costs per render, roughly 25,000 to 42,000 simulator cycles. Six voices
would be about 150,000 to 250,000, above the 58,052 cycles an unmeasured plugin is held to. So the `cpu.txt` figure
would need measuring on the device, as the kit asks.

## What changes the answer

- A bridge that runs Hundekraft drum types: then `medieval.knl` v0.2.3 is the Opus build, unchanged.
- A drum-type service in a later Opus core: then a native drum port reuses `md_voice.c` and swaps `md_fw.c`'s hooks
  for the service's.

Until then, the download's Workshop build is the one that plays in drum mode.
