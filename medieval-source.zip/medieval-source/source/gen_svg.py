#!/usr/bin/env python3
"""Generate medieval.svg: King David and his musicians, after the Olomouc Bible (folio 276r), in the OP-1 line style
(320 x 160, thin coloured lines on black), drawn the same way as the Project ERD screen.

The scene, left to right: a drummer with a pair of nakers, a shawm player, two horn players blowing upward behind the
king, the crowned king on a long cushion with his hand raised, a lute player and a bagpiper. A pointed gothic arch over
the king holds the bell of the bell tower. Red hose, blue and white robes, green crown, cushion and grass, as in the
manuscript's colouring.

Moving groups (mdscreen.c turns them by id; pivots listed in PIVOTS must match mdscreen.c):
  drummer, shawm, lute, piper  the standing musicians: sway to the music about their feet, more while you play
  head, hand    the king nods and waves his raised hand
  hornL, hornR  the horns: bob as they're blown and tilt with the green knob (pitch)
  sticks        the drummer's sticks: strike on low-key hits (and sway with the drummer)
  bell          sways gently, swings on high-key hits
The diamond lattice of the manuscript's background, the rings, sparks and the kit numeral are drawn by mdscreen.c.
Native SVG subset only: groups, lines, circles, polylines, M/L/C paths, at most 1 decimal.
    python3 gen_svg.py > medieval.svg
Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE, NOTICE).
"""
BLUE, GREEN, WHITE, RED, GREY = '#4D9EFF', '#00ED95', '#FFFFFF', '#FF3A5D', '#6F7173'
GROUND = 140
PIVOTS = {'hornL': (112, 52), 'hornR': (208, 52), 'sticks': (34, 92), 'bell': (160, 6), 'drummer': (34, 138),
          'shawm': (76, 138), 'lute': (248, 138), 'piper': (290, 138), 'head': (160, 70), 'hand': (182, 92)}


def f(v):
    s = f'{v:.1f}'.rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s


def poly(p, col, w=1.0):
    return f'<polyline points="{" ".join(f"{f(x)},{f(y)}" for x, y in p)}" fill="none" stroke="{col}" stroke-width="{f(w)}"/>'


def line(a, b, col, w=1.0):
    return f'<line x1="{f(a[0])}" y1="{f(a[1])}" x2="{f(b[0])}" y2="{f(b[1])}" stroke="{col}" stroke-width="{f(w)}"/>'


def circle(c, r, col, w=1.0):
    return f'<circle cx="{f(c[0])}" cy="{f(c[1])}" r="{f(r)}" fill="none" stroke="{col}" stroke-width="{f(w)}"/>'


def path(d, col, w=1.0):
    return f'<path d="{d}" fill="none" stroke="{col}" stroke-width="{f(w)}"/>'


def curve(p0, c0, c1, p1, col, w=1.0):
    return path(f'M{f(p0[0])},{f(p0[1])} C{f(c0[0])},{f(c0[1])} {f(c1[0])},{f(c1[1])} {f(p1[0])},{f(p1[1])}', col, w)


def ellipse(cx, cy, rx, ry, col, w=1.0):
    k = 0.5523
    d = (f'M{f(cx - rx)},{f(cy)} C{f(cx - rx)},{f(cy - ry * k)} {f(cx - rx * k)},{f(cy - ry)} {f(cx)},{f(cy - ry)} '
         f'C{f(cx + rx * k)},{f(cy - ry)} {f(cx + rx)},{f(cy - ry * k)} {f(cx + rx)},{f(cy)} '
         f'C{f(cx + rx)},{f(cy + ry * k)} {f(cx + rx * k)},{f(cy + ry)} {f(cx)},{f(cy + ry)} '
         f'C{f(cx - rx * k)},{f(cy + ry)} {f(cx - rx)},{f(cy + ry * k)} {f(cx - rx)},{f(cy)}')
    return path(d, col, w)


def figure(x, hy, robe, cap, hem=112, step=0):
    """a standing musician: head at (x, hy), a robe from the shoulders to the hem, red hose, shoes; `step` spreads the
    feet. Returns the elements and the shoulder points (left, right)."""
    out = [circle((x, hy), 6, WHITE)]
    sy = hy + 10
    shL, shR = (x - 9, sy), (x + 9, sy)
    out.append(poly([(x - 3, hy + 6), shL, (x - 13, hem), (x + 13, hem), shR, (x + 3, hy + 6)], robe))
    for s in (-1, 1):
        fx = x + s * (5 + step)
        out.append(line((x + s * 5, hem), (fx, GROUND - 2), RED))
        out.append(line((fx, GROUND - 2), (fx + 5 * s, GROUND - 2), WHITE))
    if cap == 'cap':
        out.append(curve((x - 7, hy - 3), (x - 6, hy - 11), (x + 7, hy - 12), (x + 8, hy - 3), RED))
        out.append(line((x - 7, hy - 3), (x + 8, hy - 3), RED))
    elif cap == 'hood':
        out.append(curve((x - 7, hy - 2), (x - 8, hy - 10), (x + 4, hy - 12), (x + 10, hy - 6), BLUE))
    return out, shL, shR


def drummer():
    x, hy = 34, 58
    out, shL, shR = figure(x, hy, BLUE, 'cap', step=3)
    hL, hR = (24, 90), (44, 90)                                         # hands
    out += [poly([shL, (20, 80), hL], WHITE), poly([shR, (48, 80), hR], WHITE)]
    for cx in (25, 43):                                                 # the nakers: two small kettle drums at the belt
        out.append(ellipse(cx, 101, 8, 2.5, WHITE))
        out.append(curve((cx - 8, 101), (cx - 8, 109), (cx + 8, 109), (cx + 8, 101), WHITE))
    out.append(line((25, 98.5), (43, 98.5), GREY, 0.8))                 # the strap between them
    sticks = [line(hL, (29, 99), WHITE, 1.2), line(hR, (39, 99), WHITE, 1.2)]
    return out, sticks


def shawm_player():
    x, hy = 76, 50
    out, shL, shR = figure(x, hy, WHITE, 'cap', hem=114)
    out.append(poly([(80, 56), (84, 76), (93, 96)], WHITE, 1.2))        # the shawm, down to the right
    out.append(poly([(90, 92), (93, 96), (97, 98)], WHITE))             # its bell
    out += [poly([shL, (78, 72), (85, 78)], WHITE), poly([shR, (90, 72), (89, 86)], WHITE)]
    return out


def horn_player(x, s):
    """s = -1: horn to the upper left, +1: to the upper right; the player turns to that side"""
    hy = 50
    out, shL, shR = figure(x, hy, BLUE if s < 0 else WHITE, 'hood' if s < 0 else 'cap', hem=104)
    m = (x + 6 * s, hy + 2)                                             # mouth, on the outer side of the face
    horn = [curve(m, (m[0] + 6 * s, m[1] - 10), (m[0] + 12 * s, m[1] - 24), (m[0] + 24 * s, m[1] - 38), WHITE, 1.2),
            curve((m[0] + 21 * s, m[1] - 41), (m[0] + 25 * s, m[1] - 41), (m[0] + 28 * s, m[1] - 37),
                  (m[0] + 27 * s, m[1] - 34), WHITE),                                                   # flared end
            line((m[0] + 7 * s, m[1] - 14), (m[0] + 10 * s, m[1] - 13), GREY)]
    sh = shL if s < 0 else shR
    out.append(poly([sh, (sh[0] + 7 * s, sh[1] + 12), (m[0] + 8 * s, m[1] - 11)], WHITE))      # arm up to the horn
    return out, horn


def king():
    """-> body (static), head (head, crown, beard: nods about the neck), hand (forearm and raised hand: waves)"""
    x, hy = 160, 62
    head = [circle((x, hy), 7, WHITE)]
    head.append(poly([(151, 56), (151, 46), (155, 51), (160, 43), (165, 51), (169, 46), (169, 56)], GREEN))   # crown
    head.append(line((151, 56), (169, 56), GREEN))
    head.append(curve((154, 68), (152, 74), (157, 78), (160, 79), WHITE, 0.8))   # beard
    head.append(curve((166, 68), (168, 74), (163, 78), (160, 79), WHITE, 0.8))
    out = []
    out.append(poly([(156, 70), (147, 74), (140, 112)], WHITE))           # robe
    out.append(poly([(164, 70), (173, 74), (180, 112)], WHITE))
    out.append(line((160, 80), (160, 112), BLUE, 0.8))                    # the robe's opening
    out.append(poly([(147, 76), (141, 96), (156, 101)], WHITE))           # left arm on the lap
    out.append(line((173, 76), (182, 92), WHITE))                         # right upper arm
    hand = [line((182, 92), (186, 82), WHITE), poly([(184, 82), (186, 77), (189, 81)], WHITE, 0.8)]
    out.append(poly([(150, 116), (170, 136), (176, 136)], RED))          # crossed legs
    out.append(poly([(170, 116), (150, 136), (144, 136)], RED))
    # the long green cushion of the bench, and the bench below it
    out.append(path('M134,112 C130,112 130,120 134,120 L190,120 C194,120 194,112 190,112 Z', GREEN))
    out.append(poly([(136, 120), (136, 138)], GREY))
    out.append(poly([(188, 120), (188, 138)], GREY))
    return out, head, hand


def lute_player():
    x, hy = 248, 54
    out, shL, shR = figure(x, hy, BLUE, 'hood', step=1)
    out.append(ellipse(244, 96, 12, 10, WHITE))                           # the lute's round body
    out.append(circle((246, 94), 3, GREY))                                # rosette
    out.append(poly([(255, 91), (277, 79), (281, 81)], WHITE))            # neck and bent-back pegbox
    out.append(line((236, 101), (241, 103), WHITE, 0.8))                  # bridge
    out += [poly([shL, (236, 78), (243, 92)], WHITE), poly([shR, (262, 74), (268, 84)], WHITE)]
    return out


def bagpiper():
    x, hy = 290, 56
    out, shL, shR = figure(x, hy, WHITE, 'cap')
    out.append(ellipse(298, 92, 9, 7, WHITE))                             # the bag under the arm
    out.append(poly([(287, 62), (283, 82), (279, 104)], WHITE, 1.2))      # chanter
    out.append(poly([(276, 101), (279, 104), (282, 101)], WHITE))
    out.append(line((302, 86), (309, 52), WHITE))                         # drone over the shoulder
    out.append(line((307, 52), (311, 52), WHITE))
    out += [poly([shL, (281, 74), (283, 84)], WHITE), poly([shR, (304, 76), (300, 86)], WHITE)]
    return out


def arch_and_bell():
    # a pointed gothic arch over the king; its apex holds the bell
    arch = [curve((132, 40), (132, 22), (146, 10), (160, 3), WHITE), curve((188, 40), (188, 22), (174, 10), (160, 3), WHITE),
            line((130, 40), (134, 40), WHITE), line((186, 40), (190, 40), WHITE)]
    bell = [line((160, 4), (160, 9), WHITE),
            path('M160,9 C154,9 153,14 153,20 C153,25 150,26 148,28 L172,28 C170,26 167,25 167,20 C167,14 166,9 160,9', WHITE),
            line((160, 28), (160, 31), BLUE), circle((160, 32.5), 1.5, BLUE)]
    return arch, bell


def ground():
    out = [line((8, GROUND), (312, GROUND), WHITE)]
    for x in (12, 104, 214, 306):                                # tufts of grass
        out.append(poly([(x - 3, GROUND), (x - 1, GROUND - 5), (x, GROUND), (x + 2, GROUND - 6), (x + 3, GROUND)], GREEN))
    return out


def g(id_, els):
    return f'<g id="{id_}">' + ''.join(els) + '</g>'


def main():
    d_body, sticks = drummer()
    hl_static, horn_l = horn_player(118, -1)
    hr_static, horn_r = horn_player(202, 1)
    arch, bell = arch_and_bell()
    k_body, k_head, k_hand = king()
    static = ground() + arch + hl_static + hr_static + k_body
    body = (g('scene', static) + g('drummer', d_body) + g('shawm', shawm_player()) + g('lute', lute_player())
            + g('piper', bagpiper()) + g('head', k_head) + g('hand', k_hand) + g('hornL', horn_l) + g('hornR', horn_r)
            + g('sticks', sticks) + g('bell', bell))
    print(f'<svg xmlns="http://www.w3.org/2000/svg" width="320" height="160" viewBox="0 0 320 160">{body}</svg>')


if __name__ == '__main__':
    main()
