# medieval (Project Medieval v0.2.3, drum engine)

An EP-1320 Medieval drum kit for the original OP-1, as a **drum engine**: it plays in drum mode, on the 24 drum pads,
with the drum sequencers, like any OP-1 kit. Every pad plays a real recording from the EP-1320: war drums, frame
drums, tambourines, clappers, coconuts, swords, chains, anvils, bells, stabs and horns. 96 sounds in four kits are built
into the plugin, and any pad can play any of the 96. The pages are an animated line drawing of King David and his
musicians, after the Olomouc Bible miniature.

v0.1 was a synth engine. v0.2 replaces it: same sounds and sound shaping, now a drum type (see "What drum mode can and
can't do"). The v0.1 engine is archived in `synth-engine/`. v0.2.2 sounds cleaner than v0.2.1 (see "Sound quality"). v0.2.3 plays the same
samples as v0.2.2 with about a third of its processor time, and fixes a click (see "v0.2.3").

## What drum mode can and can't do

medieval uses the drum type hook of the Workshop 3.0.3 core (`op1_feature_drum.h`), the same hook drum+ uses. That
decides a few things:

- **It plays every drum voice natively.** 12 voices, 24 pads, velocity, the drum sequencers and tape recording all work
  as with a stock kit. The stock pad settings still apply to medieval pads: pitch, volume, reverse and one-shot / gate.
- **The kit is made from a sampled kit.** You turn any sampled drum kit into a medieval kit in the drum type browser.
  medieval then plays its own built-in sounds and ignores that kit's samples.
- **The browser row is called "drum+".** The core has one drum type row, and its name is fixed in the firmware's
  database. A plugin can't add or rename it, so medieval appears under that name.
- **Only one drum type can be active, so medieval replaces drum+ while it is installed.** drum+ kits then play as plain
  sampled kits, with their own samples and pad settings but without the drum+ extras, and the drum+ pages are not
  shown. Switch medieval off on the Workshop's plugins page, or remove it, to use drum+ again. Nothing is lost either
  way: each kit keeps its own settings, and when its engine is back it plays as before.
- **Without medieval installed, a medieval kit plays as the sampled kit it was made from.**
- **The pages are drawn in code.** A drum type's pages get a raster to draw lines and text on, not an SVG screen, so
  the scene was converted to line segments (`tools/gen_art.py`).

## Controls

T1 and T2 show the medieval pages while the current drum slot is a medieval kit. "The pad" is the last pad you played.

**T1, play:**

| Knob | Name | What it does |
|---|---|---|
| Blue | PITCH | The pad's pitch. This is the stock drum pitch, unchanged. |
| Green | SOUND | The pad's sound, any of the 96, one per click. The name shows at the top right. |
| White | DECAY | How long hits ring, for the whole kit: they fall 60 dB in 40 ms at the bottom, up to 4 s. "full" plays each sound to its natural end. |
| Orange | DRIVE | Gain into a soft clipper, for the whole kit, with the level compensated. At 0 the sound is clean. |
| Press blue | | The pad plays forwards or in reverse (the stock reverse word). |
| Press green | | The pad is one-shot (plays to the end) or gate (stops when you let go, with a 1.5 ms fade). |
| Shift + orange | | The pad's volume, the stock drum volume. |

**T2, kit:**

| Knob | Name | What it does |
|---|---|---|
| Blue | KIT | Loads kit I war drums, II tavern, III armory or IV royal court onto all 24 pads, one per click. This replaces every pad's sound and start. |
| Green | START | Starts the pad's sound later, up to three quarters in. A later start fades in over 1.5 ms, so it doesn't click. |
| White | DUSK | Darkens the tone with a low-pass filter, for the whole kit. At 0 the filter is open. |
| Orange | AGE | Sample-and-hold and fewer bits, for the whole kit: a worn, old sound. At 0 it is off. |

Everything is saved in the kit, in an `"op1r"` object of the drum patch, and the stock patch writer saves it with the
kit. Other Shift + knob turns on these pages do nothing.

## Screen

King David and his musicians, in the OP-1 line style: a drummer with a pair of nakers, a shawm player, two horn
players behind the crowned king on his long green cushion, a lute player and a bagpiper, under a gothic arch with a
bell. The diamond lattice of the manuscript fills the sky. The scene moves all the time:

- **Always:** the four standing musicians sway, each in their own time, and sway more while you play. The king nods
  and waves, the horns bob as they are blown, the bell sways and the lattice twinkles.
- **Every hit:** a ring of sound spreads from the nakers for pads 1 to 12, as the sticks strike, or from the bell for
  pads 13 to 24, as it swings. A music note floats up from the musician who plays that pad: pads 1 to 6 the drummer,
  7 to 12 the shawm, 13 to 18 the lute and 19 to 24 the bagpipes.
- **Pitch:** the horns tilt up or down with the pad's pitch.
- **Decay:** the rings travel further and last longer, the bell swings longer and more of the lattice lights up.
- **Drive:** the rings flare into a turning six-pointed star and throw red sparks.
- **Dusk:** a crescent moon rises over the bagpiper.
- **Age:** dust drifts down through the scene.
- **Text, in a textura (gothic book hand) lettering drawn in the picture:** the pad number and sound name at the top
  right. Turn or press a knob and a parchment scroll unrolls at the top left for 2.5 s with its value in the knob's
  colour and a red initial, as in a manuscript: "decay 739ms", the new sound's name, "kit ii", "reverse", "one shot".
  The kit numeral I to IV sits in its red box at the top left. v0.2.0 had the four values along the bottom in the
  OP-1's own font, and they were cut off on the device. v0.2.1 has no text below the ground line.

`medieval_drum_pages.png` shows six page states and `medieval_drum_screen.gif` shows 4 s of T1 being played. Both are
rendered from the real page code on a PC. All the text is the page's own lettering, so the previews show it as the OP-1
does. A frame with rings, notes and a scroll draws about 750 lines.

## The four kits

These are the sounds each kit puts on the pads. Pads are counted from the lowest key, F. The numbers are the EP-1320
file numbers.

| Pad | I war drums | II tavern | III armory | IV royal court |
|---|---|---|---|---|
| 1 F | 001 Battle Kik | 053 Frame Drum A | 003 Axe Kik | 005 Royal Kik |
| 2 F# | 006 Stomp A | 030 Clapper A | 038 Junk | 064 Plague Drum F |
| 3 G | 002 Medium Evil Kik | 054 Frame Drum B | 009 Stomp D | 004 Medikik |
| 4 G# | 007 Stomp B | 031 Clapper B | 037 Scrap | 014 Tight Snare |
| 5 A | 050 War Tom A | 046 Frame Tom A | 041 Rubble | 056 Deep Tom A |
| 6 A# | 019 Big Clap | 032 Coconut A | 036 Dropper | 067 Plague Drum Edg B |
| 7 B | 051 War Tom B | 047 Frame Tom B | 040 Debris B | 057 Deep Tom B |
| 8 C | 052 War Tom C | 048 Frame Tom C | 042 Metal Clank | 068 Plague Drum Soft |
| 9 C# | 018 Thud | 033 Coconut B | 044 Scrap Brush | 017 Edge C |
| 10 D | 058 Deep Tom C | 049 Frame Tom D | 159 Clank A | 069 Plague Drum Sof B |
| 11 D# | 157 Armor Thud | 034 Coconut C | 161 Clink | 016 Edge B |
| 12 E | 060 Plague Drum B | 055 Frame Drum C | 160 Clank B | 059 Plague Drum A |
| 13 F | 061 Plague Drum C | 011 Market Snare | 166 Sword A | 130 Stab A |
| 14 F# | 066 Plague Drum Edge | 020 Tambo A | 170 Sword Clink | 136 Honk |
| 15 G | 062 Plague Drum D | 012 Tambo Snare | 167 Sword B | 131 Stab B |
| 16 G# | 175 Chain Thud | 027 Tambo Hat | 163 Arrow Hit | 118 Trumpet |
| 17 A | 063 Plague Drum E | 013 Jester Snare | 168 Sword C | 134 Stab E |
| 18 A# | 043 Chain Hit | 028 Tambo Short | 169 Sword D | 116 Glittern |
| 19 B | 010 Fair Snare | 021 Tambo B | 172 Sword Scrape | 083 Glittern A |
| 20 C | 015 Edge A | 029 Tambo Cap | 174 Chain | 151 Drone A |
| 21 C# | 156 Anvil Hit | 023 Tambo D | 039 Debris A | 124 Citole |
| 22 D | 155 Hell Bell | 026 Tambo Tight A | 187 Woosh B | 122 Mouth Harp |
| 23 D# | 171 Sword Clang | 025 Tambo Long | 158 Beheading | 144 Cit Chrd A |
| 24 E | 008 Stomp C | 199 Peasant Hey | 182 Snapper | 138 Horn A |

The sound numbers on T1 green count through the bank in this order: 1 to 24 are kit I, 25 to 48 kit II, 49 to 72 kit
III and 73 to 96 kit IV.

## Install

`medieval.knl` was built with the Workshop's own packer from the 3.0.3 SDK (`hundekraft-3.0.3-source.tar.gz`, SHA-256
`2f745e38…26995b1d7`, checked). It is 456 KiB, under the 512 KiB limit. It imports nothing from the core and has no
exclusive claims.

1. If the v0.1 synth version of `medieval.knl` is on the OP-1, remove it from **Your plugins** first: both files are
   called `medieval`.
2. Open the [Hundekraft Workshop](https://hundekraft.github.io/op1-workshop/) with an OP-1 that already runs
   Workshop 3.0. Add `medieval.knl` under **Your plugins**, press **Update OP-1**, read the review, send, and press T1
   on the OP-1.
3. After the restart, go to drum mode and load any **sampled** drum kit into a slot, for example a factory kit or one
   of your own. A synthesised dbox kit won't work, because the core only turns sampled kits into a drum type.
4. Press Shift + T1 to open the drum type browser and turn to the row named **drum+**. That is medieval's row (see
   above). The slot becomes a medieval kit with kit I, war drums, on the pads.
5. Leave the browser. T1 and T2 now show the medieval pages. Choose a kit on T2 blue and shape it.

To keep the kit, save it as you would any drum kit. To go back to a stock kit, load another kit into the slot.

The v0.1 synth presets don't apply to the drum engine. The drum kits below replace them.

## Presets: four drum kits

`medieval-kits.zip` holds four drum kit files, made by `tools/make_kits.py`. Each kit mixes sounds from across the
bank, and with medieval installed it loads straight in as a medieval kit, with no trip to the drum type browser.

| Kit | Decay, drive, dusk, age | Character | FX |
|---|---|---|---|
| siege | 26, 14, 0, 0 | Kicks, stomps and war toms low, big clap and snares in the middle, chain, anvil, arrow, sword clang, hell bell, trumpet and horn on top, driven hard | spring |
| crypt | full, 0, 18, 4 | Soft plague drums, deep toms and edges, darkened by dusk. Hell bell, sword scrape, chain, long tambourine and citole play reversed as swells, with drone, mouth harp, glittern, citole chord and honk on top | delay |
| jester feast | 20, 0, 0, 0 | Frame drums and frame toms, clappers, coconuts, snares and every tambourine, with the peasant's shout on the top pad. Three long tambourines are on gate, so they stop when you let go | spring |
| plague cart | 22, 8, 6, 14 | Stomps, junk, scrap, rubble, debris, clanks and swords, worn by age. Woosh and glittern play reversed, and the stabs start partway in | grid |

**How the files work.** Each one is a normal OP-1 sampled drum kit in the same layout as a kit the OP-1 saves
(`EP1320proper.aif` was used as the reference): 16-bit mono 44.1 kHz with 24 regions, under the 12 s limit. It carries two
layers:

- The `"op1r"` object makes it a medieval kit: the sound and start of each pad, and the kit's decay, drive, dusk and
  age. With medieval installed, the pads play the plugin's own bank with all of that applied.
- The kit's own audio is the same 24 sounds, shortened to fit 12 s (at most 0.5 to 1.35 s each). Without medieval, the
  kit still plays its sounds as a plain sampled kit, without decay, drive, dusk or age.

Direction and one-shot / gate are the stock pad words, so they work with or without medieval. Pitch is 0 and volume is
the factory default 8192 on every pad. The FX values stay inside the ranges of the OP-1's factory presets.

**Install:**

1. Put the OP-1 in disk mode: Shift + COM, then T3.
2. Unzip `medieval-kits.zip`. Copy its `drum/medieval` folder into the OP-1 disk's `drum/` folder, so the files end up
   in `drum/medieval/`, for example `drum/medieval/siege.aif`. Then eject.
3. In drum mode, load a kit from the `medieval` folder as you would any of your own kits.

To make your own, edit `KITS` in `tools/make_kits.py` (bank sound numbers 0 to 95, as in `bank.json`) and run
`python3 tools/make_kits.py "<ep1320 sounds>" kits`.

## How the engine gets the EP-1320 sounds

An OP-1 plugin can't open files at runtime, so the sounds are built into the plugin itself:

1. **Source:** your own exports of the EP-1320's factory sounds, the `ep1320 sounds` folder: 220 mono 16-bit 48 kHz
   WAVs named `NNN NAME.wav`.
2. **Choice:** `kits.py` lists which file goes on which pad of which kit. Edit it to make your own kits.
3. **Build:** `tools/build_bank.py` trims the silence before each hit, cuts the tail where it falls 36 dB below the peak
   (at most 0.8 s), fades the last 15 % to exactly zero, and resamples each sound to the lowest of 11.025, 16 or
   22.05 kHz that keeps 99.5 % of its energy. It then normalises each sound to -1 dBFS and encodes it as IMA ADPCM
   (4.5 bits per sample) in independent 64-sample blocks. That is about 3.5 times smaller than plain 16-bit audio,
   and the engine can still start anywhere and play backwards. The encoder, `tools/adpcm_enc.c`, searches each block
   for the codes with the least error rather than taking the nearest code sample by sample. It's slow (about 30 CPU
   minutes for the bank; `--fast` uses the quick encoder) but the files it writes are ordinary IMA ADPCM.
4. **Result:** `md_bank.h`, 96 sounds in 426 KiB, compiled into the plugin, plus `bank.json` (names, rates, quality),
   from which `tools/gen_names.py` makes the sound names the page shows.

**The size limit decides how much fits.** The Workshop accepts plugin files up to 512 KiB, code included. 96 sounds fill
426 KiB, about 50 seconds of audio. That's why long sounds stop at 0.8 s and why the melodic EP-1320 sounds (drones,
hurdy-gurdy phrases, crowds, animals) are left out.

### Using other EP-1320 sounds

```
ep1320 sounds/            your exports, any folder name
  001 BATTLE KIK.wav      16-bit WAV, mono or stereo (summed), any sample rate;
  002 MEDIUM EVIL KIK.wav the first three characters are the number used in kits.py
  ...
```

1. Edit `kits.py`: four kits of exactly 24 `(file number, tune)` pairs. The drum engine uses the pad's stock pitch, so
   leave tune at 0.
2. Run `python3 tools/build_bank.py "<path to ep1320 sounds>"`, then `python3 tools/gen_names.py > md_names.h`. The
   bank builder refuses a bank over 440 KiB.
3. Rebuild the plugin (Build below) and re-run the tests.

## Sound quality

You reported that v0.2.1 sounded a bit fuzzy on the speakers. I found three things in the engine that add fuzz, and
v0.2.2 deals with each:

1. **Fizz from the resampling.** The bank's sounds are stored at 11, 16 or 22 kHz to save space, and the engine
   converts them to the OP-1's 44.1 kHz as it plays. v0.2.1 did that by drawing a straight line between neighbouring
   samples. That leaves faint mirror images of the sound above its own top end, heard as a fizz or hiss on top of
   cymbals, tambourines and clangs. v0.2.2 uses a 16-point windowed-sinc filter (`md_fir` in `md_tables.h`), which
   removes them: the energy above each sound's own band fell from -11 dB to -41 dB in the worst sound, and from -28 dB
   to -53 dB in the typical one.
2. **Compression noise.** The sounds are stored at 4 bits per sample (ADPCM) so that 96 of them fit in the plugin.
   v0.2.2 re-encodes the same sounds with a searching encoder, which lowers that noise by about 2.5 dB (median
   22.6 to 25.1 dB signal to noise; worst sound 14.4 to 16.2 dB) with the same size and the same decoder.
3. **No headroom.** A single hit at full velocity peaked at -3.3 dBFS, so two or three hits together could clip in the
   mix. v0.2.2 plays 3 dB lower: a full-velocity hit at the default pad volume now peaks at about -7 dBFS. Turn the
   OP-1's volume up a little to match.

Together, the engine's output is now 4.8 dB closer to the original recordings for the typical sound and 7 dB closer
for the worst one (end-to-end signal to noise: median 20.4 to 25.2 dB, worst sound 8.9 to 16.1 dB). That was measured
on a PC by playing each sound through the engine's own code and comparing it with the recording resampled to 44.1 kHz.

What is left is the 4-bit compression itself. The way to go further is fewer sounds stored at higher quality (for
example 48 sounds instead of 96), which would mean a different set of kits. Tell me if you want that.

The filter costs processor time. v0.2.2 estimated 70 to 90 more cycles per sample per voice than v0.2.1; measured in
the Blackfin simulator it was about three times v0.2.1's cost. v0.2.3 brings it back to about v0.2.1's level with
the same filter and the same samples (next section).

## v0.2.3

Same sound, same pages, controls, kits and saved data as v0.2.2: the engine gives v0.2.2's samples exactly (checked
below). Three changes, all in `md_voice.c` and `md_fw.c`:

1. **A click when a stock kit takes a voice.** If a voice was playing a medieval sound when a stock kit's hit took it,
   and later a medieval hit got that voice again, v0.2.2 faded out the medieval sample it had stopped on, which could
   be thousands of steps away from silence: a click at the start of the new hit (5,249 of 32,767 in the test). The
   voice now forgets its medieval sound when a stock hit takes it. Test: `test_steal_back` in `harness/md_test.c`
   (v0.2.2 fails it, v0.2.3 passes).
2. **A hit that a render interrupts.** A new hit fills the voice while the audio may render it. v0.2.3 switches the
   voice off first and on last, so a render in between sees either the old sound or the new one, never half of each
   (the same order drum+ uses for its own state). This is a guard: no fault from it was seen.
3. **Processor time.** The 16-tap filter read its taps through the block cache once per sample, with a `% 3` for
   each lookup, and copied the taps whenever they straddled two blocks. v0.2.3 copies each block, with the start of
   the next, into one window when the filter moves into it, and on the Blackfin the 16 taps are 16 multiply-adds with
   both loads in the same instruction (`md_fir16`). The pad gain is worked out again only when the velocity changes.
   The window adds 162 bytes per voice (12 voices: 1,968 bytes more, `.bss` 5,972 to 7,940 bytes) and the render's
   stack frame goes from 128 to 116 bytes.

**Measured** in GDB's Blackfin simulator (`--model bf524`), cycles for one 128-sample render, `harness/cycles/`:

| Case | v0.2.1 (linear) | v0.2.2 | v0.2.3 |
|---|---|---|---|
| 1 voice, plain, as recorded: average | 25,088 | 79,184 | 25,448 |
| 1 voice, heaviest (drive, dusk, age full, reversed, late start): worst | 37,687 | 102,504 | 41,752 |
| 12 voices, plain, as recorded: worst | 326,879 | 992,362 | 384,286 |
| 12 voices, heaviest, twice the pitch: worst | 516,596 | 1,192,990 | 576,384 |

The simulator counts instructions and branch delays, not the device's multi-cycle multiplies or cache and memory
waits, so these numbers compare versions; they are not device figures. The twelve voices in the bench start
together and cross block edges at the same time, which is worse than playing. v0.2.1 is the version you reported as
running well on the OP-1. v0.2.3 has not been measured on the device.

## Build

You need Python 3 with numpy and scipy, a C compiler for your PC (`cc`, for the bank encoder and the tests), and a
Blackfin cross compiler, `bfin-elf-gcc` 13.3.0 with binutils.

Unpack `hundekraft-3.0.3-source.tar.gz` (from the Workshop's `source/` folder; check its SHA-256), copy `plugin.json`,
`LICENSE`, `NOTICE` and every `md_*.c` and `md_*.h` file to `ext/kennel/synth_sdk/plugins/medieval/`, and run this
from `ext/kennel`:

```sh
python3 tools/kennel/pack.py synth_sdk/plugins/medieval -o build/medieval.knl --toolchain /path/to/toolchain
```

The toolchain directory holds `bfin-gcc/bin` and `bfin/bin`. v0.2.2 was built with GCC 13.3.0 and binutils 2.41.50
(2024-01-13 snapshot). v0.2.3 was built with GCC 13.3.0 and binutils 2.38, the versions the Opus plugin kit's
`tools/toolchain/build-bfin-toolchain.sh` names, built with that script's Linux step from the release tarballs in
Ubuntu's archive (`gcc-13.3.0.tar.xz` SHA-256 `0845e962…061a0c083`, `binutils_2.38.orig.tar.xz` SHA-256
`e316477a…048ecfe024`). That toolchain rebuilds v0.2.2's `medieval.knl` from its source byte for byte (SHA-256
`0829c0c4…09d0d55f2`), so the two builds differ only by the source changes.

**`md_bank.h` is not in the source zip.** It holds the EP-1320 audio (see `NOTICE`). Use the one from the v0.2.2
source zip (it is unchanged, SHA-256 `9bdb4fd9…7170c4bc`), or make it again from your exports with `tools/build_bank.py`.

**Source files:**

- `md_fw.c`: the drum type: the hooks for note-on, render and note-off, loading and saving the kit, and the
  `FEATURE_medieval` descriptor.
- `md_voice.c` and `md_voice.h`: one drum voice: ADPCM decoding, the 16-tap resampling filter, decay, drive, dusk,
  age, the click guards and the stock pad gain.
- `md_page.c`: the T1 and T2 pages: edits, labels and the animated scene.
- `md_fw.h`: what those files share.
- `md_font.h`, from `tools/gen_font.py`: the textura stroke font. `python3 tools/gen_font.py --png sample.png` draws a
  specimen.

**Generated files:**

- `python3 tools/build_bank.py "<ep1320 sounds>"` regenerates `md_bank.h` and `bank.json`.
- `python3 tools/gen_names.py > md_names.h` regenerates the sound names.
- `python3 tools/gen_tables.py > md_tables.h` regenerates the decay tables and the resampling filter.
- `python3 tools/gen_art.py > md_art.h` regenerates the line art from `gen_svg.py`. `python3 gen_svg.py` still writes
  the same scene as an SVG.

## Tests

These run on a PC, with the SDK's headers and op1r-src's host header (`harness/op1_host.h`):

```sh
cc -fsanitize=address,undefined -fno-sanitize-recover=all -Wall -Wextra -DOP1_HOST -I . -I harness \
   -I <sdk>/ext/kennel/synth_sdk -I <op1r-src>/synth_sdk harness/md_test.c md_fw.c md_voice.c md_page.c -lm
python3 harness/md_preview.py <sdk>/ext/kennel/synth_sdk <op1r-src>/synth_sdk out/
python3 harness/md_demo.py <sdk>/ext/kennel/synth_sdk <op1r-src>/synth_sdk out/
harness/match.sh <v0.2.2 source folder>                       # v0.2.3 against v0.2.2, sample by sample
harness/cycles/run.sh <v0.2.2 source folder> <folder with bfin-elf-gcc> <gdb>/sim/bfin/run   # cycles, Blackfin
```

The op1r-src header used is commit `087775b` (2026-10-22); later commits changed `host_shift` in `op1_host.h`,
which the harness doesn't build against. The Blackfin simulator is GDB 16.3's (`configure --target=bfin-elf
--disable-gdb && make all-sim`).

`md_demo.py` makes `medieval_demo.mp4` and `medieval_demo.wav`, a one-minute demo: the four kits, then decay, drive,
dusk, age, reverse and pitch. It plays a scripted performance through the real drum hooks, voices and pages on a PC
(`md_test demo`), so the sound and screen are the engine's own, dry (no OP-1 FX), with one gain on the whole mix so it
peaks at -1 dBFS. It is not a recording of the OP-1.

| Test | Result for v0.2.3 |
|---|---|
| Stock kits are untouched | Pass. A stock kit's note-on, render and note-off all go to the stock functions. A drum+ kit is recognised and goes to the stock functions too. |
| Medieval kits never reach the stock voice | Pass. A finished medieval voice stays silent and never falls back to the stock render. |
| Voice states | Pass. Note-on sets held, note-off sets released, and the voice turns off when its sound ends. Gate fades out in 64 samples, then turns off. One-shot keeps playing after note-off. |
| Every sound with extreme settings | Pass. 27,648 hits: all 96 sounds, decay 0, 15 and 31, drive, dusk, age and start at 0 and full, forwards and reversed, at a quarter, one and four times the speed. All ended, under ASan and UBSan. The largest jump in a hit's first four samples is 788 of 32,767, and the loudest peak is 17,136. |
| Retrigger clicks | Pass. A pad restruck mid-sound steps by at most 34 of 32,767. |
| Levels | Pass. Velocity 127 at the default pad volume peaks at 14,990 (-6.8 dBFS; v0.2.1: 22,532, -3.3 dBFS). Velocity 64 and half volume are each about 12 dB lower, as the stock volume law gives. Twice the pitch plays in half the time. |
| Sound quality | The same as v0.2.2 (the samples are identical, next row). Measured for v0.2.2 as in "Sound quality": end-to-end signal to noise median 25.2 dB, worst 16.1 dB (v0.2.1: 20.4 and 8.9 dB); energy above each sound's own band median -53 dB, worst -41 dB (v0.2.1: -28 and -11 dB). |
| Same samples as v0.2.2 (PC) | Pass. `harness/match.sh`: 16,114 hits through v0.2.2's and v0.2.3's `md_voice.c` side by side, every sound forwards and reversed, four starts, three pitches, decay, drive, dusk and age at 0, half and full, steady and changing velocity, three volumes, gate releases and retriggers: 182,934,400 samples, 0 differ, under ASan and UBSan. A one-step change to the output gain makes 21.5 M of them differ, so the check would see a change. |
| Same samples as v0.2.2 (Blackfin) | Pass. `harness/cycles/run.sh` builds both versions with the target compiler and runs them in GDB's Blackfin simulator: the hash of every output block is the same for all 12 cases, so the Blackfin filter (`md_fir16`) gives the C version's sums. |
| Stock kit takes a voice | Pass (v0.2.2: fail). A medieval hit after a stock hit took its voice starts within 800 of silence; v0.2.2 started at 5,249. |
| Static analysis | Clean. `cppcheck --enable=warning,performance,portability` and GCC 13's `-fanalyzer` on `md_fw.c`, `md_voice.c` and `md_page.c` (v0.2.2: one cppcheck note, a right shift of a negative number in the filter, now gone). |
| Save and load | Pass. Every page edit is written to the kit's `"op1r"` object and reads back identically. Blue and Shift + orange on T1 go to the stock controller, and the presses change the stock reverse and playmode words. |
| Target compile | Clean, no warnings, with the Workshop's flags (`-O2 -mcpu=bf524 -ffreestanding -fno-builtin -nostdlib -Wall`), and with `-Wextra` as well. The plugin imports nothing from the core. |
| Workshop format | Pass. `python3 -m unittest tools/kennel/test_plugin_format.py tools/kennel/test_exports.py` in the SDK runs 11 tests with medieval in `synth_sdk/plugins`. gin and oblique were set aside because they need generated files the bundle doesn't include. |
| Workshop loader | Not run. `tools/kennel/test_loader.py` needs `harness/kennel_load_host.c`, which the 3.0.3 source bundle doesn't include. |

## Status of v0.2.3

**On the device:** you reported that v0.2.1 is really good on your OP-1, but sounds a bit fuzzy on the speakers.
v0.2.2 changed only the sound (see "Sound quality"), and v0.2.3 changes nothing you hear: the same samples, pages,
controls, kits and saved data as v0.2.2, so kits saved with v0.2.1 or v0.2.2 load unchanged. Neither v0.2.2 nor
v0.2.3 has run on an OP-1 yet: everything here was checked on a PC and in the Blackfin simulator.

**Not yet checked on the device:**

- That pad 1 is the lowest key. The engine uses the pad number the firmware gives each voice.
- The level: the engine applies the stock drum gain law, and at the default pad volume (8192) it plays the bank 5.5 dB
  below the bank's own level (3 dB lower than v0.2.1, for headroom). How that compares with stock kits could not be
  checked against the firmware's own voice. If medieval kits are much louder or quieter than stock kits, `OUT_GAIN`
  in `md_voice.c` sets it.
- That picking the drum+ row on a sampled kit makes it medieval straight away. If the pages show "medieval / plays as a
  stock kit", leave and re-enter T1. The page finishes setting the kit up when it is shown.
- The cost of the pages on the OP-1's graphics thread (about 750 lines a frame) and of 12 voices with drive, dusk and
  age on, now with the 16-point filter (resource monitor: clock screen + T1).
- The detent size of the encoders on these pages: one sound or kit per 2048 of delta, and one step of decay, drive,
  start, dusk or age per 1024.
- That the OP-1 keeps the `"op1r"` object when it loads a kit file from disk. The core's code keeps it on every drum
  patch load, which is how drum+ kits keep their settings. If a kit loads as a plain kit (the T1 page is the stock one),
  it still plays its 24 sounds from its own audio, but without medieval's shaping. Picking the drum+ row then would
  start a fresh medieval kit with kit I on the pads, so tell me instead.
- The sequencer report from v0.1, below.

**The sequencer report from v0.1.** You said the sequencer stayed on after you turned it off and went back to the
synth screen. I couldn't find anything in the engine that touches the sequencer: a synth engine only renders voices,
and the core runs the sequencers. The one unusual thing v0.1 did was claim the encoder presses for its second page. The
drum engine doesn't do that on the synth side at all. If it happens again with v0.2, try the same steps with medieval
switched off on the plugins page. That tells us whether medieval is involved or it's the firmware.

**Not implemented:**

- Its own row name in the drum type browser, and running side by side with drum+ (see above).
- Per-pad decay, drive, dusk and age: these are per kit. Per pad there is sound, start, pitch, volume, direction and
  playmode.
- Choke groups, velocity layers and loop playmode (loop plays as gate).
- A reverb inside the engine: use the OP-1's FX slot.

## Credits and license

- **Engine, pages and artwork:** Project Medieval. The art is an original line drawing after the King David miniature
  in the Olomouc Bible (15th century, public domain).
- **Control idea:** one sound per pad across all 24, with pitch and decay on the encoders, from GIN by SquareWave
  Studio (op1-mods). No GIN code is used.
- **Plugin API, drum type hook, host harness and packer:** kennel / Workshop (Hundekraft) and op1r-src (pcppcp). The
  stock drum gain law follows drum+'s model of the stock voice.
- **Sounds:** Teenage Engineering EP-1320 Medieval factory sounds, from your own device's exports. They are not covered
  by this project's license: keep plugin files that contain them for your own use, and share the source without
  `md_bank.h`.

The code and art are GPL-3.0-or-later with the OP-1 firmware permission (see `LICENSE` and `NOTICE`). EP-1320,
OP-1 and Teenage Engineering belong to Teenage Engineering AB. This is an unofficial fan project.
