/* medieval drum type: what md_fw.c (hooks, persistence) and md_page.c (the T1 / T2 pages) share.
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and
 * NOTICE). */
#ifndef MD_FW_H
#define MD_FW_H
#include "md_voice.h"

#define MD_ENGINE  "medieval"    /* the kit's "op1r" "engine": the type's name */
#define MD_NSOUNDS 96

extern md_kit_t md_slot[8];
extern uint8_t md_foreign[8];
extern volatile uint8_t md_hit_count, md_hit_pad, md_hit_vel;
extern volatile uint32_t md_samples;

void md_store(int slot);
void md_pad_words_changed(int slot);
void md_check_slot(int slot);

void md_page_init(void);
void md_page_draw(int page, int slot, void *raster);
int  md_page_turn(int page, int slot, int knob, int delta);
void md_page_press(int page, int slot, int knob);
#endif
