#!/usr/bin/env python3
"""The medieval drum kit presets: OP-1 drum patch files that load as medieval kits.

    python3 tools/make_kits.py "<folder with the EP-1320 WAVs>" [OUT_DIR]    -> OUT_DIR/*.aif (default: kits/)

Each file is an OP-1 sampled drum kit (AIFC, 16-bit mono 44.1 kHz, 'sowt', an APPL chunk with "op-1" + JSON), in the
layout of a kit saved by the OP-1 (EP1320proper.aif in the project files: "drum_version": 2, regions in "start" /
"end" at 4058 per sample frame, 12 s at most). Two layers:
  - the "op1r" object makes it a medieval kit ({"engine": "medieval", "kit", "decay", "drive", "dusk", "age",
    "pads": [[sound, start], ...]}, as md_fw.c reads it): with medieval installed the pads play the plugin's bank
  - the kit's own audio is the same 24 sounds, shortened to fit the 12 s, so without medieval the kit still plays its
    sounds (stock playback, without decay, drive, dusk or age)
The stock pad words set direction and one-shot / gate; pitch stays 0 and volume 8192 (the factory default).
Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE, NOTICE).
"""
import json, math, os, struct, sys
from pathlib import Path
import numpy as np
from scipy.signal import resample_poly

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from build_bank import find_wav, read_wav  # noqa: E402

SR = 44100
POS_PER_FRAME = 4058             # region units per sample frame (OP-1 drum patches)
MAX_FRAMES = 11.5 * SR           # under the OP-1's 12 s drum sample, with a margin
FWD, REV = 8192, 16384           # reverse word
SHOT, GATE = 8192, 4096          # playmode word
RANGE_FX = {                     # factory preset ranges (as presets.py / Project ERD)
    "delay": [(3392, 11200), (4969, 32767), (0, 16384), (1332, 32767)],
    "spring": [(1344, 16448), (9920, 16448), (0, 16384), (2047, 26120)],
    "grid": [(1344, 12824), (1344, 13752), (13392, 28165), (6854, 32767)],
}

R = 'rev'
# name: kit-wide steps (decay, drive, dusk, age; 0..31), FX, 24 pads of (bank sound index, start 0..31, flags)
KITS = [
    ("siege", (26, 14, 0, 0), ("spring", [12000, 15000, 3000, 9000]), [
        (0, 0, ''), (2, 0, ''), (48, 0, ''), (72, 0, ''), (1, 0, ''), (3, 0, ''), (4, 0, ''), (6, 0, ''),
        (7, 0, ''), (9, 0, ''), (5, 0, ''), (18, 0, ''), (36, 0, ''), (8, 0, ''), (10, 0, ''), (15, 0, ''),
        (17, 0, ''), (20, 0, ''), (22, 0, ''), (63, 0, ''), (70, 0, ''), (21, 0, ''), (87, 0, ''), (95, 0, '')]),
    ("crypt", (31, 0, 18, 4), ("delay", [7000, 16000, 6000, 14000]), [
        (74, 0, ''), (76, 0, ''), (78, 0, ''), (79, 0, ''), (81, 0, ''), (83, 0, ''), (11, 0, ''), (12, 0, ''),
        (14, 0, ''), (16, 0, ''), (77, 0, ''), (80, 0, ''), (82, 0, ''), (13, 0, ''), (21, 0, R), (66, 0, R),
        (67, 0, R), (46, 0, R), (91, 0, ''), (93, 0, ''), (89, 0, ''), (92, 0, R), (94, 0, ''), (85, 0, '')]),
    ("jester feast", (20, 0, 0, 0), ("spring", [8000, 12000, 1500, 6000]), [
        (24, 0, ''), (26, 0, ''), (35, 0, ''), (28, 0, ''), (30, 0, ''), (31, 0, ''), (33, 0, ''), (25, 0, ''),
        (27, 0, ''), (29, 0, ''), (32, 0, ''), (34, 0, ''), (40, 0, ''), (38, 0, ''), (75, 0, ''), (37, 0, ''),
        (42, 0, 'gate'), (44, 0, 'gate'), (39, 0, ''), (41, 0, ''), (43, 0, ''), (45, 0, ''), (46, 0, 'gate'),
        (47, 0, '')]),
    ("plague cart", (22, 8, 6, 14), ("grid", [3000, 6000, 18000, 12000]), [
        (50, 0, ''), (23, 0, ''), (49, 0, ''), (51, 0, ''), (52, 0, ''), (53, 0, ''), (54, 0, ''), (68, 4, ''),
        (56, 0, ''), (55, 0, ''), (57, 0, ''), (59, 0, ''), (58, 0, ''), (60, 0, ''), (61, 0, ''), (62, 0, ''),
        (64, 0, ''), (65, 0, ''), (69, 0, R), (71, 6, ''), (84, 8, ''), (86, 6, ''), (88, 0, ''), (90, 0, R)]),
]


def ieee_extended(x):
    exp = int(math.floor(math.log2(x)))
    return struct.pack(">HQ", exp + 16383, int(x / 2 ** exp * 2 ** 63))


def chunk(cid, body):
    return cid + struct.pack(">I", len(body)) + body + (b"\0" if len(body) & 1 else b"")


def sound_audio(folder, num):
    """the sound at 44.1 kHz: hit onset (2 ms lead) to where it falls 36 dB below the peak, float"""
    x, sr = read_wav(find_wav(folder, num))
    g = math.gcd(SR, sr)
    x = resample_poly(x, SR // g, sr // g)
    pk = np.abs(x).max()
    on = int(np.argmax(np.abs(x) > pk * 0.01))
    x = x[max(0, on - int(0.002 * SR)):]
    hop = SR // 100
    env = np.maximum.reduceat(np.abs(x), np.arange(0, len(x), hop))
    above = np.nonzero(env > pk * 10 ** (-36 / 20))[0]
    return x[:min(len(x), (above[-1] + 1) * hop)]


def fit(sounds):
    """cap the longest sounds until all fit MAX_FRAMES; fade each one's last 15 % (>= 10 ms) to zero; -1 dBFS"""
    lens = [len(s) for s in sounds]
    lo, hi = 0, max(lens)
    while lo < hi:                                        # largest cap that fits
        mid = (lo + hi + 1) // 2
        if sum(min(n, mid) for n in lens) <= MAX_FRAMES: lo = mid
        else: hi = mid - 1
    out = []
    for s in sounds:
        y = s[:lo].copy()
        nf = min(len(y), max(int(0.010 * SR), int(0.15 * len(y))))
        y[-nf:] *= 0.5 + 0.5 * np.cos(np.linspace(0, np.pi, nf))
        y *= 10 ** (-1 / 20) / max(np.abs(y).max(), 1e-9)
        out.append(np.clip(np.round(y * 32767), -32768, 32767).astype('<i2'))
    return out, lo / SR


def check_range(name, what, vals, ranges):
    for i, (v, (a, b)) in enumerate(zip(vals, ranges)):
        if not a <= v <= b:
            raise ValueError(f'{name}: {what}[{i}] = {v} outside {a}..{b}')


def kit_file(folder, sounds_meta, name, steps, fx, pads):
    assert len(pads) == 24 and all(0 <= s < 96 and 0 <= st <= 31 for s, st, _ in pads), name
    assert all(0 <= v <= 31 for v in steps) and len(name) <= 14 and set(name) <= set('abcdefghijklmnopqrstuvwxyz ')
    check_range(name, 'fx ' + fx[0], fx[1], RANGE_FX[fx[0]])
    audio, cap = fit([sound_audio(folder, sounds_meta[s]['num']) for s, _, _ in pads])
    start, end, pos = [], [], 0
    for a in audio:
        start.append(pos * POS_PER_FRAME); pos += len(a); end.append(pos * POS_PER_FRAME)
    assert end[-1] < 2 ** 31
    decay, drive, dusk, age = steps
    meta = {
        "drum_version": 2, "type": "drum", "name": name,
        "start": start, "end": end, "octave": 0,
        "pitch": [0] * 24,
        "playmode": [GATE if 'gate' in f else SHOT for _, _, f in pads],
        "reverse": [REV if f == R else FWD for _, _, f in pads],
        "volume": [8192] * 24,
        "dyna_env": [0, 8192, 0, 8192, 0, 0, 0, 0],
        "fx_active": True, "fx_type": fx[0], "fx_params": list(fx[1]) + [8000] * 4,
        "lfo_active": False, "lfo_type": "tremolo", "lfo_params": [16000, 16000, 16000, 16000, 0, 0, 0, 0],
        "op1r": {"engine": "medieval", "kit": 0, "decay": decay, "drive": drive, "dusk": dusk, "age": age,
                 "pads": [[s, st] for s, st, _ in pads]},
    }
    js = b"op-1" + json.dumps(meta, separators=(",", ":")).encode() + b"\0"
    if len(js) & 1:
        js += b"\0"
    data = b"".join(a.tobytes() for a in audio)
    comm = struct.pack(">hIh", 1, pos, 16) + ieee_extended(SR) + b"sowt" + b")Signed integer (little-endian) linear PCM"
    body = (chunk(b"FVER", bytes.fromhex("a2805140")) + chunk(b"COMM", comm) + chunk(b"APPL", js)
            + chunk(b"SSND", struct.pack(">II", 0, 0) + data))
    return b"FORM" + struct.pack(">I", len(body) + 4) + b"AIFC" + body, pos / SR, cap


def main():
    if len(sys.argv) not in (2, 3):
        sys.exit(__doc__)
    folder = sys.argv[1]
    out = Path(sys.argv[2]) if len(sys.argv) == 3 else HERE.parent / 'kits'
    out.mkdir(parents=True, exist_ok=True)
    sounds = json.loads((HERE.parent / 'bank.json').read_text())['sounds']
    for name, steps, fx, pads in KITS:
        b, secs, cap = kit_file(folder, sounds, name, steps, fx, pads)
        (out / f'{name}.aif').write_bytes(b)
        print(f'{name}.aif: {len(b)} bytes, {secs:.2f} s of fallback audio, longest sound {cap:.2f} s')


if __name__ == '__main__':
    main()
