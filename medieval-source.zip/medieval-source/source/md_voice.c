/* medieval: one drum voice playing a sound of the EP-1320 bank (see md_voice.h).
 * Per sample: a 16-tap interpolation (md_fir), the decay envelope, the optional drive, dusk and age, and the stock
 * pad gain. The bank is IMA ADPCM in independent 64-sample blocks; a voice keeps the last three blocks it read
 * decoded, so each block is decoded once per hit.
 * Click-free by design: every sound in the bank ends faded to zero, a later start fades in over 64 samples, a voice
 * that is retriggered while sounding fades its last output out over 64 samples, a gate let go fades out over 64
 * samples, and the decay ramps within each block. Integer only.
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and
 * NOTICE). */
#include "md_voice.h"
#include "md_bank.h"
#include "md_tables.h"

#define BLOCK       128         /* samples per render call (the drum voice block) */
#define OUT_GAIN    17408       /* Q15, -5.5 dB: the bank peaks at -1 dBFS, so one hit peaks near -6.5 dBFS, with room
                                   * for a few hits together before the mix clips (v0.2.1 had 3 dB less) */
#define ENV_STOP    8           /* Q15 envelope below which a decaying voice stops */
#define VOL_SHIFT   11          /* pad gain: dp_gain(8192, velocity 127) = 2016 ~ 2^11 plays the bank at its level */

static const int16_t ima_step[89] = {
    7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107,
    118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963,
    1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894,
    6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794,
    32767 };
static const int8_t ima_index[8] = { -1, -1, -1, -1, 2, 4, 6, 8 };

/* decode one 36-byte block (int16 first sample, uint8 step index, pad, 64 nibbles) into its 64 samples (the 64th
 * nibble gives the next block's first sample, which that block's header holds exactly) */
static void md_decode(int16_t *out, const uint8_t *b)
{
    int32_t pred = (int16_t)(b[0] | (b[1] << 8)), idx = b[2];
    out[0] = (int16_t)pred;
    for (int i = 0; i < MD_BLOCK - 1; i++) {
        int32_t n = (b[4 + (i >> 1)] >> ((i & 1) << 2)) & 15, st = ima_step[idx], d = st >> 3;
        if (n & 1) d += st >> 2;
        if (n & 2) d += st >> 1;
        if (n & 4) d += st;
        pred = n & 8 ? pred - d : pred + d;
        pred = pred > 32767 ? 32767 : (pred < -32768 ? -32768 : pred);
        idx += ima_index[n & 7];
        idx = idx < 0 ? 0 : (idx > 88 ? 88 : idx);
        out[i + 1] = (int16_t)pred;
    }
}

static const int16_t md_zeros[MD_BLOCK];

/* decoded block b of the sound at base (nblk blocks); silence outside it */
static const int16_t *md_block(md_voice_t *v, const uint8_t *base, int32_t b, int32_t nblk)
{
    if (b < 0 || b >= nblk) return md_zeros;
    int line = (int)(b % 3);
    if (v->tag[line] != b) { md_decode(v->cache[line], base + b * MD_BLOCK_BYTES); v->tag[line] = b; }
    return v->cache[line];
}

static inline int16_t sat16(int32_t x) { return (int16_t)(x > 32767 ? 32767 : x < -32768 ? -32768 : x); }

/* the stock drum voice's per-sample gain: vol^2 * e^2 (drumplus/dp_voice.h dp_gain, bit for bit) */
static inline int32_t md_gain(int32_t vol, int32_t e)
{
    int32_t g = (vol * e * 2 + 0x8000) >> 16; g = g > 32767 ? 32767 : g < -32768 ? -32768 : g;
    g = (g * vol * 2 + 0x8000) >> 16;         g = g > 32767 ? 32767 : g < -32768 ? -32768 : g;
    g = (g * e * 2 + 0x8000) >> 16;           return g > 32767 ? 32767 : g < -32768 ? -32768 : g;
}

/* the filter's dot product: 16 source samples by 16 taps. The sum stays within 2^30 (the taps of a phase sum to
 * about 2^14), so a 32-bit sum and the 40-bit accumulator give the same result. On the Blackfin it is one
 * multiply-accumulate a tap with both loads in the same instruction (v0.2.3); elsewhere, plain C. */
static inline int32_t md_fir16(const int16_t *x, const int16_t *h)
{
#ifdef __bfin__
    int32_t r, a, b;
    __asm__ volatile(
        "%1.L = W[%3++];\n\t"
        "%2.L = W[%4++];\n\t"
        "A0 = %1.L * %2.L (IS) || %1.L = W[%3++] || %2.L = W[%4++];\n\t"
        ".rept 14\n\t"
        "A0 += %1.L * %2.L (IS) || %1.L = W[%3++] || %2.L = W[%4++];\n\t"
        ".endr\n\t"
        "A0 += %1.L * %2.L (IS);\n\t"
        "%0 = A0 (IS);"
        : "=d"(r), "=&d"(a), "=&d"(b), "+b"(x), "+b"(h)
        :
        : "A0", "memory");
    return r;
#else
    int32_t acc = 0;
    for (int k = 0; k < 16; k++) acc += x[k] * h[k];
    return acc;
#endif
}

static int clamp_step(int s) { return s < 0 ? 0 : s > MD_STEPS - 1 ? MD_STEPS - 1 : s; }

void md_kit_set(md_kit_t *k, int kit)
{
    kit = kit < 0 ? 0 : kit >= MD_KITS ? MD_KITS - 1 : kit;
    k->kit = (uint8_t)kit;
    for (int p = 0; p < MD_PADS; p++) { k->snd[p] = md_kit[kit][p].snd; k->start[p] = 0; }
}

void md_kit_defaults(md_kit_t *k)
{
    k->decay = MD_STEPS - 1; k->drive = 0; k->dusk = 0; k->age = 0;
    md_kit_set(k, 0);
}

int32_t md_decay_ms(int step) { step = clamp_step(step); return step == MD_STEPS - 1 ? 0 : md_t60_ms[step]; }
int32_t md_sound_ms(int snd)
{
    if ((unsigned)snd >= MD_SOUNDS) return 0;
    return (int32_t)(((int64_t)md_sound[snd].len * 1000 * 65536 / md_sound[snd].inc) / 44100);
}

void md_voice_on(md_voice_t *v, const md_kit_t *k, int pad, int reverse)
{
    if ((unsigned)pad >= MD_PADS) pad = 0;
    int snd = k->snd[pad] < MD_SOUNDS ? k->snd[pad] : 0;
    const md_sound_t *s = &md_sound[snd];
    /* The hit may be interrupted by this voice's render (v0.2.3): the voice is off while it is filled, so a render in
     * between only fades the old sound's last sample out, and it plays again from the last line. */
    int16_t prev = v->state != MD_OFF ? v->last : 0;
    *(volatile uint8_t *)&v->state = MD_OFF;
    v->declick = prev;
    int32_t last = s->len - 1;
    int32_t off = (int32_t)(((uint32_t)last * (uint32_t)(clamp_step(k->start[pad]) * 3)) / (4 * MD_STEPS));
    v->snd = (uint8_t)snd;
    v->rev = reverse != 0;
    v->pos = (v->rev ? last - 1 - off : off) << 16;
    if (v->pos < 0) v->pos = 0;
    v->fade_in = off > 0;
    v->env = 32767; v->tag[0] = v->tag[1] = v->tag[2] = -1; v->wblk = -2;
    v->lp = 0; v->age = 0; v->hold = 0; v->hold_n = 0; v->fade_n = 0;
    *(volatile uint8_t *)&v->state = MD_PLAY;
}

void md_voice_release(md_voice_t *v)
{
    if (v->state == MD_PLAY) { v->state = MD_FADE; v->fade_n = MD_DECLICK; }
}

int md_voice_render(md_voice_t *v, const md_kit_t *k, int16_t *out, const int32_t *inc, const int16_t *vel,
                    int16_t volume)
{
    int32_t dc = v->declick;
    if (v->state == MD_OFF) {
        for (int i = 0; i < BLOCK; i++) out[i] = i < MD_DECLICK ? (int16_t)(dc * (MD_DECLICK - i) / MD_DECLICK) : 0;
        v->declick = 0; v->last = 0;
        return 0;
    }

    /* per block: rate (the stock increment carries the pad's pitch), envelope ramp, drive, dusk and age */
    const md_sound_t *s = &md_sound[v->snd];
    int32_t step = inc[0] >> 17;                                      /* 1/2048 sample; 2048 = as recorded */
    if (step <= 0) step = 2048;
    int32_t rate = (int32_t)(((int64_t)s->inc * step) >> 11);          /* Q16 source samples per output sample */
    if (rate < 1) rate = 1;
    int32_t e0 = v->env;
    int32_t e1 = (int32_t)(((int64_t)e0 * md_decay[clamp_step(k->decay)]) >> 15);
    if (e1 > 32767) e1 = 32767;
    int32_t de = e1 - e0;
    int32_t drive = clamp_step(k->drive);
    int32_t dg = 4096 + drive * 7 * 4096 / (MD_STEPS - 1);           /* Q12 gain 1 .. 8 */
    int32_t mk = OUT_GAIN - drive * 11000 / (MD_STEPS - 1);           /* level compensation for the clip */
    int32_t dusk = clamp_step(k->dusk);
    int32_t a = 32767 - dusk * 31000 / (MD_STEPS - 1);                /* low pass: open .. ~240 Hz */
    int32_t agev = clamp_step(k->age);
    int32_t hold_len = 1 + agev * 7 / (MD_STEPS - 1), mask = ~((1 << (agev >> 2)) - 1);
    int32_t last = s->len - 1;
    const uint8_t *base = md_adpcm + s->block * MD_BLOCK_BYTES;
    int32_t nblk = (last + MD_BLOCK - 1) / MD_BLOCK;

    int32_t pos = v->pos, lp = v->lp;
    /* The 16 source samples the filter reads, from one decoded block and the start of the next, copied into one
     * window each time the filter moves into the next (or, reversed, the previous) block: one copy per 64 source
     * samples instead of a cache lookup per sample and a copy whenever the taps straddle two blocks (v0.2.3). */
    int32_t cur = v->wblk;                                            /* the block in win (-1: silence before it) */
    int16_t *win = v->win;
    int32_t vel_last = -1, g = 0;                                     /* the pad gain, recomputed when vel changes */
    int i = 0, done = 0;
    for (; i < BLOCK; i++) {
        int32_t idx = pos >> 16;
        if (pos < 0 || idx >= last) { done = 1; break; }
        /* 16-tap interpolation: source samples idx - 7 .. idx + 8. idx >= 0 here, so lo >= -7, and block -1 (the
         * 7 samples before the sound) is silence, as v0.2.2 had it. */
        int32_t lo = idx - 7, b0 = lo < 0 ? -1 : lo >> 6, o0 = lo & (MD_BLOCK - 1);
        if (b0 != cur) {
            const int16_t *p0 = md_block(v, base, b0, nblk), *p1 = md_block(v, base, b0 + 1, nblk);
            for (int k = 0; k < MD_BLOCK; k++) win[k] = p0[k];
            for (int k = 0; k < 16; k++) win[MD_BLOCK + k] = p1[k];
            cur = b0;
        }
        int32_t acc = md_fir16(win + o0, md_fir[(pos >> 10) & 63]);
        int32_t x = acc >> 14;
        x = x > 32767 ? 32767 : x < -32768 ? -32768 : x;
        x = (x * (e0 + ((de * i) >> 7))) >> 15;                        /* decay */
        if (drive) {                                                  /* drive: cubic soft clip */
            x = (x * dg) >> 12;
            x = x > 32767 ? 32767 : (x < -32767 ? -32767 : x);
            int32_t x2 = (x * x) >> 15;
            x = ((3 * x) >> 1) - (((x * x2) >> 15) >> 1);
        }
        if (dusk) { lp += ((x - lp) * a) >> 15; x = lp; }            /* dusk */
        if (agev) {                                                   /* age: hold, fewer bits */
            if (v->hold_n == 0) { v->hold = (int16_t)(x & mask); v->hold_n = (uint8_t)hold_len; }
            v->hold_n--;
            x = v->hold;
        }
        if (v->fade_in && v->age < MD_DECLICK) x = x * v->age / MD_DECLICK;   /* a later start fades in */
        x = (x * mk) >> 15;
        if (v->state == MD_FADE) {                                    /* gate let go */
            if (!v->fade_n) { done = 1; break; }
            x = x * v->fade_n / MD_DECLICK; v->fade_n--;
        }
        if (vel[i] != vel_last) { vel_last = vel[i]; g = md_gain(volume, vel_last); }
        int32_t y = (x * g) >> VOL_SHIFT;
        if (i < MD_DECLICK && dc) y += dc * (MD_DECLICK - i) / MD_DECLICK;
        out[i] = sat16(y);
        if (v->age < 0xFFFF) v->age++;
        pos = v->rev ? pos - rate : pos + rate;
    }
    for (; i < BLOCK; i++)                                            /* the sound ended inside this block */
        out[i] = (int16_t)(i < MD_DECLICK && dc ? dc * (MD_DECLICK - i) / MD_DECLICK : 0);
    v->pos = pos; v->lp = (int16_t)lp; v->env = e1; v->declick = 0; v->last = out[BLOCK - 1]; v->wblk = cur;
    if (done || e1 < ENV_STOP) v->state = MD_OFF;
    return v->state != MD_OFF;
}
