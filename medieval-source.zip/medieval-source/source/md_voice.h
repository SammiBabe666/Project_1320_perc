/* medieval: one drum voice playing a sound of the EP-1320 bank (md_bank.h), and the settings of a medieval kit.
 * Pure C, no firmware addresses: md_fw.c calls it from the drum type hooks, the host tests call it directly.
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and
 * NOTICE). */
#ifndef MD_VOICE_H
#define MD_VOICE_H
#include <stdint.h>

#define MD_PADS     24
#define MD_STEPS    32          /* every page value is a step 0..31 */
#define MD_NKITS    4

/* one drum slot of the medieval type: what the pages edit and the patch saves ("op1r" object, md_fw.c) */
typedef struct {
    uint8_t on;                 /* the slot is a medieval kit (else the drum type passes it to the stock voice) */
    uint8_t kit;                /* 0..3: the kit last chosen on T2 blue (the pads' sounds were set from it) */
    uint8_t decay;              /* 0..31: hit length, 40 ms .. 4 s to -60 dB; 31 = the sound's natural length */
    uint8_t drive;              /* 0..31: gain into a soft clip, with level compensation; 0 = clean */
    uint8_t dusk;               /* 0..31: one-pole low pass; 0 = open */
    uint8_t age;                /* 0..31: sample-and-hold and fewer bits, an old worn sound; 0 = off */
    uint8_t snd[MD_PADS];       /* sound of each pad, 0..95 (bank order) */
    uint8_t start[MD_PADS];     /* start of each pad, 0..31: later in the sound, up to 3/4 of it */
} md_kit_t;

enum { MD_OFF = 0, MD_PLAY, MD_FADE };

typedef struct {
    int32_t pos;                /* Q16 position in the sound (samples at its own rate) */
    int32_t env;                /* decay envelope, Q15 */
    int32_t tag[3];             /* block decoded into each cache line (block b in line b % 3), -1: none */
    int16_t cache[3][64];       /* decoded blocks: the 16-tap filter reads up to two neighbours */
    int32_t wblk;               /* block copied into win, -2: none (v0.2.3) */
    int16_t win[64 + 16];       /* that block and the start of the next, in one piece for the filter (v0.2.3) */
    int16_t last;               /* last output sample */
    int16_t declick;            /* output at a retrigger, faded out over MD_DECLICK samples */
    int16_t lp;                 /* dusk low pass state */
    int16_t hold;               /* age: held sample */
    uint16_t age;               /* samples since the hit, saturating (start fade-in) */
    uint8_t state, snd, rev, fade_in, hold_n, fade_n;
} md_voice_t;

#define MD_DECLICK 64           /* samples */

void md_kit_defaults(md_kit_t *k);
void md_kit_set(md_kit_t *k, int kit);                      /* the pads' sounds from kit 0..3, starts to 0 */
/* a hit: pad's sound and start from the kit, reverse from the stock pad word */
void md_voice_on(md_voice_t *v, const md_kit_t *k, int pad, int reverse);
void md_voice_release(md_voice_t *v);                      /* gate let go: fade out over MD_DECLICK samples */
/* one 128-sample block: inc and vel are the firmware's per-sample buffers (increment << 17 with 2048 = as recorded,
 * velocity << 8), volume the stock pad word. Returns 0 once the voice has finished (out is complete either way). */
int md_voice_render(md_voice_t *v, const md_kit_t *k, int16_t *out, const int32_t *inc, const int16_t *vel,
                    int16_t volume);
int32_t md_decay_ms(int step);                             /* for the page: time to -60 dB, 0 = natural */
int32_t md_sound_ms(int snd);                              /* length of a sound as recorded */
#endif
