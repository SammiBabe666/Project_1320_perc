/* medieval drum pages, drawn in code (a drum type's pages get a raster, not an SVG): King David and his musicians,
 * after the Olomouc Bible (folio 276r), as line art (md_art.h, made from gen_svg.py by tools/gen_art.py).
 *   T1 play : blue PITCH (stock, the pad) | green SOUND (the pad) | white DECAY (kit) | orange DRIVE (kit)
 *             presses: blue reverse (the pad), green one-shot / gate (the pad); Shift + orange: stock pad volume
 *   T2 kit  : blue KIT I..IV (sets all 24 pads' sounds) | green START (the pad) | white DUSK (kit) | orange AGE (kit)
 * Text is drawn in a textura stroke font (md_font.h): the pad and its sound at the top right, and a scroll at the top
 * left with the value of the knob just turned or pressed.
 * The scene is alive all the time and answers the playing:
 *   the four standing musicians sway, more while you play; the king nods and waves; the horns bob as they are blown
 *   and tilt with the pad's pitch; the lattice of the background twinkles, more of it with longer decay
 *   every hit: a ring of sound spreads from the nakers (pads 1-12) or the bell (13-24), the drummer's sticks strike or
 *   the bell swings, and a music note floats up from the musician who plays that pad (1-6 drummer, 7-12 shawm,
 *   13-18 lute, 19-24 bagpipes)
 *   drive: rings flare into a turning six-pointed star and throw red sparks; dusk: a moon rises; age: dust drifts
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and
 * NOTICE). */
#include "op1_synth.h"
#include "md_fw.h"
#include "md_art.h"
#include "md_names.h"
#include "md_font.h"

#ifndef OP1_HOST
#define LAST_PAD     (*(volatile int *)0xFF801044)             /* the pad last played or selected */
#define SHIFT_HELD   (*(volatile uint8_t *)0x01DD7F78)
#define PAD_TABLE(s) ((int16_t *)(0x01AAADB4 + (s) * 0x180))   /* live pad words, 8 per pad */
#else
#include "harness/md_host.h"
#endif

#define Q(v)     ((int32_t)(v) << 10)
#define DEG(d)   ((d) * 8192 / 360)                            /* sine-table units */
#define N_RINGS  8
#define N_NOTES  8
#define N_LAT    64
#define N_DUST   16
#define GROUND   140

static const uint8_t C_BLUE[4]  = { 0x4D, 0x9E, 0xFF, 0xFF }, C_GREEN[4] = { 0x00, 0xED, 0x95, 0xFF },
                     C_WHITE[4] = { 0xFF, 0xFF, 0xFF, 0xFF }, C_RED[4]   = { 0xFF, 0x3A, 0x5D, 0xFF },
                     C_GREY[4]  = { 0x6F, 0x71, 0x73, 0xFF }, C_PALE[4]  = { 0xAE, 0xB1, 0xDC, 0xFF },
                     C_ORANGE[4] = { 0xFF, 0x8C, 0x1A, 0xFF };
static const uint8_t *const art_col[5] = { C_BLUE, C_GREEN, C_WHITE, C_RED, C_GREY };
static const uint8_t *const knob_col[4] = { C_BLUE, C_GREEN, C_WHITE, C_RED };

/* ---- edits (shared with the host test) ---- */
enum { F_NONE = -1, F_STOCK = -2, F_SOUND = 0, F_DECAY, F_DRIVE, F_KIT, F_START, F_DUSK, F_AGE };
int md_turn_field(int page, int knob, int shift)
{
    static const int8_t f[2][4] = { { F_STOCK, F_SOUND, F_DECAY, F_DRIVE }, { F_KIT, F_START, F_DUSK, F_AGE } };
    if (shift) return page == 0 && knob == 3 ? F_STOCK : F_NONE;   /* Shift + T1 orange: stock pad volume */
    return f[page & 1][knob & 3];
}

static int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

/* steps: whole steps (signed). Returns 1 if the kit changed. */
int md_turn(md_kit_t *k, int field, int pad, int steps)
{
    if (!steps || (unsigned)pad >= MD_PADS) return 0;
    switch (field) {
    case F_SOUND: { int s = ((k->snd[pad] + steps) % MD_NSOUNDS + MD_NSOUNDS) % MD_NSOUNDS;
                    if (s == k->snd[pad]) return 0;
                    k->snd[pad] = (uint8_t)s; return 1; }
    case F_KIT:   { int n = clampi(k->kit + steps, 0, MD_NKITS - 1); if (n == k->kit) return 0; md_kit_set(k, n); return 1; }
    case F_START: { int n = clampi(k->start[pad] + steps, 0, MD_STEPS - 1); if (n == k->start[pad]) return 0; k->start[pad] = (uint8_t)n; return 1; }
    default: break;
    }
    uint8_t *w = field == F_DECAY ? &k->decay : field == F_DRIVE ? &k->drive : field == F_DUSK ? &k->dusk :
                 field == F_AGE ? &k->age : 0;
    if (!w) return 0;
    int n = clampi(*w + steps, 0, MD_STEPS - 1);
    if (n == *w) return 0;
    *w = (uint8_t)n;
    return 1;
}

/* press: edits the pad words (8 int16). Returns 1 if they changed. */
int md_press(int16_t *padw, int page, int knob)
{
    if (page != 0) return 0;
    if (knob == 0) { padw[4] = (int16_t)(padw[4] >> 14 ? 8192 : 16384); return 1; }   /* reverse: fwd 8192, rev 16384 */
    if (knob == 1) { padw[3] = (int16_t)((padw[3] >> 13) == 1 ? 4096 : 8192); return 1; } /* one-shot 8192 <-> gate 4096 */
    return 0;
}

/* ---- labels ---- */
static char *put(char *p, const char *s) { while (*s) *p++ = *s++; *p = 0; return p; }
static char *num(char *p, int v, int sign)
{
    char t[12]; int n = 0;
    if (v < 0) { *p++ = '-'; v = -v; } else if (sign && v) *p++ = '+';
    do { t[n++] = (char)('0' + v % 10); v /= 10; } while (v);
    while (n) *p++ = t[--n];
    *p = 0; return p;
}
static void fmt_ms(char *p, int32_t ms)
{
    if (ms < 1000) { put(num(p, ms, 0), "ms"); return; }
    p = num(p, ms / 1000, 0); *p++ = '.'; put(num(p, ms % 1000 / 100, 0), "s");
}
static const char *const roman[4] = { "i", "ii", "iii", "iv" };

/* the bottom label of knob k: name and value */
void md_label(const md_kit_t *k, const int16_t *padw, int page, int pad, int knob, char *out)
{
    char *p = out;
    if (page == 0) switch (knob) {
    case 0: p = put(p, "pitch "); num(p, padw[0] >> 9, 1); break;
    case 1: p = put(p, "sound "); num(p, k->snd[pad] + 1, 0); break;
    case 2: p = put(p, "decay "); if (k->decay == MD_STEPS - 1) put(p, "full"); else fmt_ms(p, md_decay_ms(k->decay)); break;
    default: p = put(p, "drive "); num(p, k->drive * 100 / (MD_STEPS - 1), 0); break;
    } else switch (knob) {
    case 0: p = put(p, "kit "); put(p, roman[k->kit & 3]); break;
    case 1: p = put(p, "start "); put(num(p, k->start[pad] * 75 / (MD_STEPS - 1), 0), "%"); break;
    case 2: p = put(p, "dusk "); num(p, k->dusk * 100 / (MD_STEPS - 1), 0); break;
    default: p = put(p, "age "); num(p, k->age * 100 / (MD_STEPS - 1), 0); break;
    }
}

/* ---- drawing ---- */
static void ln(void *r, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t w, const uint8_t *c)   /* Q10 */
{
    if (x0 == x1 && y0 == y1) return;                          /* zero-length lines are dropped by the rasteriser */
    op1_pt a = { x0, y0 }, b = { x1, y1 };
    op1_raster_line(r, &a, &b, w, c);
}
static inline int32_t tsin(int32_t a) { return OP1_SINE_TABLE[a & 8191]; }
static inline int32_t tcos(int32_t a) { return tsin(a + 2048); }

typedef struct { int32_t s, c, px, py; } rot_t;                /* a turn about a pivot (pivot in 1/8 px) */
static rot_t rot(int32_t ang, int px, int py) { rot_t t = { tsin(ang), tcos(ang), px * 8, py * 8 }; return t; }
static void apply(const rot_t *t, int32_t *x, int32_t *y)      /* 1/8 px */
{
    int32_t dx = *x - t->px, dy = *y - t->py;
    *x = t->px + ((dx * t->c - dy * t->s) >> 15);
    *y = t->py + ((dx * t->s + dy * t->c) >> 15);
}

/* draw group g, turned by t1 then t2 (either may be 0) */
static void draw_group(void *r, int g, const rot_t *t1, const rot_t *t2)
{
    const md_grp_t *gr = &md_grp[g];
    for (int i = gr->first; i < gr->first + gr->n; i++) {
        const md_poly_t *pl = &md_poly[i];
        const int16_t *pt = md_pt + 2 * pl->first;
        int32_t px = 0, py = 0, w = (int32_t)pl->w4 << 8;
        for (int j = 0; j < pl->n; j++) {
            int32_t x = pt[2 * j], y = pt[2 * j + 1];
            if (t1) apply(t1, &x, &y);
            if (t2) apply(t2, &x, &y);
            x <<= 7; y <<= 7;                                  /* 1/8 px -> Q10 */
            if (j) ln(r, px, py, x, y, w, art_col[pl->col]);
            px = x; py = y;
        }
    }
}

typedef struct { int16_t x, y, age, life; uint8_t on, bell; uint16_t seed; } ring_t;
typedef struct { int16_t x, y, age; uint8_t on, who; } note_t;

static ring_t rings[N_RINGS];
static note_t notes[N_NOTES];
static int16_t lat_x[N_LAT], lat_y[N_LAT];
static int n_lat;
static uint8_t seen_hits;
static uint32_t last_samples, t_ms, frames_still;
static int32_t stick_t = 1000, bell_t = 10000, act;            /* ms since the last strike / bell hit; activity Q15 */

/* the lattice shows only where no figure or text stands: these boxes (px) are kept clear */
static const int16_t clear_box[][4] = {
    { 12, 46, 58, 150 }, { 60, 38, 102, 150 }, { 82, 4, 138, 150 }, { 124, 0, 196, 150 }, { 182, 4, 240, 150 },
    { 224, 40, 286, 150 }, { 268, 40, 316, 150 }, { 4, 4, 32, 30 }, { 196, 0, 320, 20 },
    { 288, 14, 316, 50 },
};
/* where each musician's notes start (pads 1-6, 7-12, 13-18, 19-24): above the drummer, shawm, lute, bagpipes */
static const int16_t note_from[4][2] = { { 34, 42 }, { 76, 34 }, { 248, 42 }, { 286, 44 } };

/* text: drawn in md_font.h, a textura stroke font, as raster lines (the stock font's labels along the bottom were
 * cut off on the device). The pad and its sound at the top right; a scroll with the value of the knob just turned or
 * pressed, for 2.5 s, at the top left. */
static const uint8_t C_BLACK[4] = { 0, 0, 0, 0xFF };
static int text_w(const char *s)
{
    int w = 0;
    for (; *s; s++) { unsigned c = (unsigned char)*s - 32; if (c < 96 && md_glyph[c].adv) w += md_glyph[c].adv; }
    return w;
}
/* s at x, y (px, the top of the ascenders); the first letter in `init` (a rubricated initial) */
static void draw_text(void *r, int x, int y, const char *s, const uint8_t *col, const uint8_t *init)
{
    for (int i = 0; s[i]; i++) {
        unsigned c = (unsigned char)s[i] - 32;
        if (c >= 96 || md_glyph[c].off == 0xFFFF) continue;
        const uint8_t *p = md_strokes + md_glyph[c].off, *cc = i == 0 && init ? init : col;
        int32_t px = 0, py = 0, pen = 0;
        for (; *p != 0xFE; p++) {
            if (*p == 0xFF) { pen = 0; continue; }
            int32_t qx = Q(x + (*p >> 4)) + 0x200, qy = Q(y + (*p & 15)) + 0x200;
            if (pen) ln(r, px, py, qx, qy, 0x400, cc);
            else if (p[1] == 0xFE || p[1] == 0xFF) ln(r, qx, qy - 0x200, qx, qy + 0x200, 0x400, cc);   /* a dot */
            px = qx; py = qy; pen = 1;
        }
        x += md_glyph[c].adv;
    }
}
/* a parchment scroll with s on it, rolled at both ends, over whatever is behind it */
static void scroll(void *r, const char *s, const uint8_t *col)
{
    int x0 = 38, x1 = x0 + text_w(s) + 11, yc = 12;
    ln(r, Q(x0 - 3), Q(yc), Q(x1 + 3), Q(yc), Q(19), C_BLACK);  /* clears the scene behind it */
    ln(r, Q(x0), Q(3), Q(x1), Q(3), 0x400, C_PALE);
    ln(r, Q(x0), Q(21), Q(x1), Q(21), 0x400, C_PALE);
    for (int e = 0; e < 2; e++) {                              /* the rolls: tall ellipses */
        int32_t cx = Q(e ? x1 : x0), px = 0, py = 0;
        for (int i = 0; i <= 12; i++) {
            int32_t a = i * 8192 / 12;
            int32_t x = cx + ((tcos(a) * 3) >> 5), y = Q(yc) + ((tsin(a) * 9) >> 5);
            if (i) ln(r, px, py, x, y, 0x400, C_PALE);
            px = x; py = y;
        }
    }
    draw_text(r, x0 + 5, 4, s, col, C_RED);
}

static int8_t scroll_knob = -1, scroll_press;                  /* what the scroll shows */
static int16_t scroll_ms;

void md_page_init(void)
{
    n_lat = 0;                                                 /* diamond lattice: crossings every 14 px */
    for (int y = 8; y < 48 && n_lat < N_LAT; y += 7)
        for (int x = 8 + ((y / 7) & 1) * 7; x < 314 && n_lat < N_LAT; x += 14) {
            int clear = 1;
            for (unsigned b = 0; b < sizeof clear_box / sizeof clear_box[0]; b++)
                if (x >= clear_box[b][0] && x <= clear_box[b][2] && y >= clear_box[b][1] && y <= clear_box[b][3]) clear = 0;
            if (clear) { lat_x[n_lat] = (int16_t)x; lat_y[n_lat] = (int16_t)y; n_lat++; }
        }
    for (int i = 0; i < N_RINGS; i++) rings[i].on = 0;
    for (int i = 0; i < N_NOTES; i++) notes[i].on = 0;
    seen_hits = md_hit_count;
    last_samples = md_samples;
}

static void spawn(int pad, int vel, int decay)
{
    int bell = pad >= 12, best = 0;
    for (int i = 0; i < N_RINGS; i++) {                        /* a free ring, else the oldest */
        if (!rings[i].on) { best = i; break; }
        if (rings[i].age > rings[best].age) best = i;
    }
    ring_t *g = &rings[best];
    g->on = 1; g->bell = (uint8_t)bell; g->age = 0;
    g->x = bell ? 160 : 34; g->y = bell ? 28 : 102;
    g->life = (int16_t)(350 + decay * 1650 / (MD_STEPS - 1));
    g->seed = (uint16_t)(pad * 40503u + t_ms);
    if (bell) bell_t = 0; else stick_t = 0;
    best = 0;
    for (int i = 0; i < N_NOTES; i++) {
        if (!notes[i].on) { best = i; break; }
        if (notes[i].age > notes[best].age) best = i;
    }
    note_t *n = &notes[best];
    int who = pad / 6;
    n->on = 1; n->age = 0; n->who = (uint8_t)who;
    n->x = (int16_t)(note_from[who][0] + (int)((g->seed >> 3) % 9) - 4); n->y = note_from[who][1];
    act += 6000 + vel * 60; if (act > 32767) act = 32767;
}

/* a music note: oval head, stem and flag; x, y the head (Q10) */
static void draw_note(void *r, int32_t x, int32_t y, const uint8_t *c)
{
    int32_t px = 0, py = 0;
    for (int i = 0; i <= 8; i++) {
        int32_t a = i * 1024 + DEG(-20);
        int32_t xx = x + ((tcos(a) * 3) >> 5), yy = y + ((tsin(a) * 2) >> 5);   /* rx 3 px, ry 2 px (Q10 = <<10 >>15) */
        if (i) ln(r, px, py, xx, yy, 0x400, c);
        px = xx; py = yy;
    }
    ln(r, x + Q(3), y, x + Q(3), y - Q(9), 0x400, c);
    ln(r, x + Q(3), y - Q(9), x + Q(7), y - Q(5), 0x400, c);
}

static void numeral(void *r, int kit)                          /* the kit numeral I..IV in a red box */
{
    int32_t x0 = Q(8), y0 = Q(8), x1 = Q(30), y1 = Q(26), w = Q(1);
    ln(r, x0, y0, x1, y0, w, C_RED); ln(r, x1, y0, x1, y1, w, C_RED);
    ln(r, x1, y1, x0, y1, w, C_RED); ln(r, x0, y1, x0, y0, w, C_RED);
    int32_t top = Q(12), bot = Q(22), sw = 0x600;
    if (kit < 3) {
        int32_t x = Q(19) - kit * 2560;
        for (int i = 0; i <= kit; i++) ln(r, x + i * Q(5), top, x + i * Q(5), bot, sw, C_WHITE);
    } else {
        ln(r, Q(14), top, Q(14), bot, sw, C_WHITE);
        ln(r, Q(18), top, Q(21), bot, sw, C_WHITE);
        ln(r, Q(21), bot, Q(24), top, sw, C_WHITE);
    }
}

/* everything but the texts; dt in ms. Exposed for the host preview. */
void md_scene(void *r, const md_kit_t *k, const int16_t *padw, int dt)
{
    t_ms += (uint32_t)dt;
    int32_t t = (int32_t)(t_ms & 0x3FFFFFF);
    uint8_t hc = md_hit_count;                                 /* new hits since the last frame (3 at most) */
    int n_new = (uint8_t)(hc - seen_hits); seen_hits = hc;
    if (n_new > 3) n_new = 3;
    for (int i = 0; i < n_new; i++) spawn(md_hit_pad, md_hit_vel, k->decay);
    act -= act * dt / 1500 + 1; if (act < 0) act = 0;          /* activity falls back over ~1.5 s */

    /* lattice: grey crossings; with more decay more of them light up, and they twinkle */
    int32_t lit = (n_lat * (8 + k->decay)) / (MD_STEPS + 7);
    for (int i = 0; i < n_lat; i++) {
        int32_t x = Q(lat_x[i]), y = Q(lat_y[i]), h = 0x600;
        const uint8_t *c = C_GREY;
        if (((i * 37) % n_lat) < lit && tsin(t * 2 + i * 1300) > -12000) c = C_WHITE;
        ln(r, x - h, y - h, x + h, y + h, 0x400, c);
        ln(r, x - h, y + h, x + h, y - h, 0x400, c);
    }

    /* dusk: a crescent moon rises over the bagpiper */
    if (k->dusk) {
        int32_t my = Q(42) - k->dusk * Q(18) / (MD_STEPS - 1), mx = Q(302), pxx = 0, pyy = 0;
        for (int i = 0; i <= 10; i++) {                        /* outer arc, then inner arc back */
            int32_t a = DEG(60) + i * DEG(240) / 10;
            int32_t x = mx + ((tcos(a) * 7) >> 5), y = my + ((tsin(a) * 7) >> 5);
            if (i) ln(r, pxx, pyy, x, y, 0x400, C_PALE);
            pxx = x; pyy = y;
        }
        for (int i = 0; i <= 10; i++) {
            int32_t a = DEG(300) - i * DEG(240) / 10;
            int32_t x = mx - Q(3) + ((tcos(a) * 5) >> 5), y = my + ((tsin(a) * 6) >> 5);
            ln(r, pxx, pyy, x, y, 0x400, C_PALE);
            pxx = x; pyy = y;
        }
    }

    /* the scene: static parts, then each moving group with its turn */
    int32_t sway_amp = DEG(2) + (act * DEG(4) >> 15);
    static const int16_t period[4] = { 1900, 2300, 2100, 1700 }, phase[4] = { 0, 2700, 5400, 1300 };
    rot_t mus[4];
    for (int m = 0; m < 4; m++) {
        const md_grp_t *g = &md_grp[MD_G_DRUMMER + m];
        int32_t a = (tsin(t * 8192 / period[m] + phase[m]) * sway_amp) >> 15;
        mus[m] = rot(a, g->px, g->py);
    }
    draw_group(r, MD_G_SCENE, 0, 0);
    for (int m = 0; m < 4; m++) draw_group(r, MD_G_DRUMMER + m, &mus[m], 0);

    stick_t += dt; if (stick_t > 1000) stick_t = 1000;         /* sticks: a 14 degree strike, back over 150 ms */
    int32_t sa = (stick_t < 150 ? DEG(14) * (150 - stick_t) / 150 : 0) + ((tsin(t * 8192 / 520) * DEG(2)) >> 15);
    rot_t st = rot(sa, md_grp[MD_G_STICKS].px, md_grp[MD_G_STICKS].py);
    draw_group(r, MD_G_STICKS, &st, &mus[0]);

    int32_t nod = (tsin(t * 8192 / 1300) * (DEG(3) + (act * DEG(4) >> 15))) >> 15;
    rot_t hd = rot(nod, md_grp[MD_G_HEAD].px, md_grp[MD_G_HEAD].py);
    draw_group(r, MD_G_HEAD, &hd, 0);
    int32_t wave = DEG(-6) + ((tsin(t * 8192 / 900) * (DEG(10) + (act * DEG(10) >> 15))) >> 15);
    rot_t hn = rot(wave, md_grp[MD_G_HAND].px, md_grp[MD_G_HAND].py);
    draw_group(r, MD_G_HAND, &hn, 0);

    int32_t tilt = clampi(padw[0] >> 9, -24, 24) * DEG(1) / 2;  /* the pad's pitch: +-12 degrees */
    int32_t bobL = (tsin(t * 8192 / 760) * (DEG(3) + (act * DEG(3) >> 15))) >> 15;
    int32_t bobR = (tsin(t * 8192 / 820 + 3000) * (DEG(3) + (act * DEG(3) >> 15))) >> 15;
    rot_t hl = rot(tilt + bobL, md_grp[MD_G_HORNL].px, md_grp[MD_G_HORNL].py);
    rot_t hr = rot(-tilt + bobR, md_grp[MD_G_HORNR].px, md_grp[MD_G_HORNR].py);
    draw_group(r, MD_G_HORNL, &hl, 0);
    draw_group(r, MD_G_HORNR, &hr, 0);

    bell_t += dt; if (bell_t > 10000) bell_t = 10000;          /* bell: sways, swings 16 degrees on a hit */
    int32_t bdie = 500 + k->decay * 2500 / (MD_STEPS - 1);
    int32_t ba = (tsin(t * 8192 / 2400) * DEG(3)) >> 15;
    if (bell_t < bdie) ba += (int32_t)((tsin(bell_t * 8192 / 700) * DEG(16)) >> 15) * (bdie - bell_t) / bdie;
    rot_t bl = rot(ba, md_grp[MD_G_BELL].px, md_grp[MD_G_BELL].py);
    draw_group(r, MD_G_BELL, &bl, 0);

    numeral(r, k->kit & 3);

    /* age: dust drifting down through the scene */
    for (int i = 0; i < N_DUST * k->age / (MD_STEPS - 1); i++) {
        uint32_t s = (uint32_t)i * 2654435761u;
        int32_t x = (int32_t)(s >> 8) % 300 + 10 + ((tsin(t * 3 + i * 900) * 4) >> 15);
        int32_t y = (int32_t)((s >> 20) + t / (30 + i * 3)) % 130 + 4;
        ln(r, Q(x), Q(y), Q(x) + 0x800, Q(y) + 0x800, 0x500, C_PALE);
    }

    /* music notes: float up 26 px over 1.4 s, drifting from side to side */
    for (int i = 0; i < N_NOTES; i++) {
        note_t *n = &notes[i];
        if (!n->on) continue;
        n->age = (int16_t)(n->age + dt);
        if (n->age >= 1400) { n->on = 0; continue; }
        int32_t x = Q(n->x) + ((tsin(n->age * 6 + i * 2000) * 4) >> 5), y = Q(n->y) - n->age * Q(26) / 1400;
        static const uint8_t *const nc[4] = { C_WHITE, C_BLUE, C_GREEN, C_ORANGE };
        draw_note(r, x, y, n->age > 1000 ? C_GREY : nc[n->who & 3]);
    }

    /* rings: 24 segments, radius grows from 4 px to 14..44 px; flaring and sparking with drive */
    int32_t rmax = 14 + k->decay * 30 / (MD_STEPS - 1), drive = k->drive * 32767 / (MD_STEPS - 1);
    for (int n = 0; n < N_RINGS; n++) {
        ring_t *g = &rings[n];
        if (!g->on) continue;
        g->age = (int16_t)(g->age + dt);
        if (g->age >= g->life) { g->on = 0; continue; }
        int32_t p = (g->age << 15) / g->life;                  /* 0..32767 through its life */
        int32_t rad = Q(4) + ((Q(rmax - 4) >> 5) * ((p * (65536 - p)) >> 15) >> 10);   /* eases out */
        if (g->bell) rad = rad * 3 >> 2;
        const uint8_t *c = p > 21800 ? C_GREY : (g->bell ? C_BLUE : C_WHITE);
        int32_t jag = (drive * Q(3)) >> 15, px = 0, py = 0;
        for (int i = 0; i <= 24; i++) {
            int32_t a = (i % 24) * 8192 / 24;
            int32_t rr = rad + ((jag * tsin(a * 6 + g->seed + t)) >> 15);
            int32_t x = Q(g->x) + ((tcos(a) * (rr >> 5)) >> 10), y = Q(g->y) + ((tsin(a) * (rr >> 5)) >> 10);
            if (i && (y < Q(GROUND) || py < Q(GROUND))) ln(r, px, py, x, y, 0x400, c);
            px = x; py = y;
        }
        uint32_t s = g->seed;
        for (int i = 0; i < (drive * 7) >> 15; i++) {          /* red sparks thrown outward */
            s = s * 1664525u + 1013904223u;
            int32_t a = (int32_t)(s >> 19), r0 = rad + Q(3), r1 = r0 + Q(4);
            int32_t x0 = Q(g->x) + ((tcos(a) * (r0 >> 5)) >> 10), y0 = Q(g->y) + ((tsin(a) * (r0 >> 5)) >> 10);
            int32_t x1 = Q(g->x) + ((tcos(a) * (r1 >> 5)) >> 10), y1 = Q(g->y) + ((tsin(a) * (r1 >> 5)) >> 10);
            if (y1 < Q(GROUND) && p < 21800) ln(r, x0, y0, x1, y1, 0x400, C_RED);
        }
    }
}

static int cur_pad(void) { int p = LAST_PAD; return p >= 0 && p < MD_PADS ? p : 0; }

/* time since the last frame, from the audio clock (the page gets no frame time); 25 ms if the clock stands still */
static int frame_ms(void)
{
    uint32_t s = md_samples, d = s - last_samples;
    last_samples = s;
    if (!d) return ++frames_still > 2 ? 25 : 0;
    frames_still = 0;
    d = d * 10 / 441;
    return d > 100 ? 100 : (int)d;
}

void md_page_draw(int page, int slot, void *r)
{
    md_check_slot(slot);
    const md_kit_t *k = &md_slot[slot & 7];
    int pad = cur_pad();
    const int16_t *pw = PAD_TABLE(slot & 7) + pad * 8;
    if (!k->on) {                                              /* another engine's kit (drum+): plays stock here */
        draw_text(r, 40, 30, md_foreign[slot & 7] ? "a drum+ kit" : "medieval", C_PALE, C_RED);
        draw_text(r, 40, 46, "plays as a stock kit", C_GREY, 0);
        return;
    }
    int dt = frame_ms();
    md_scene(r, k, pw, dt);
    char a[40];
    put(put(num(a, pad + 1, 0), " "), md_name[k->snd[pad] % MD_NSOUNDS]);
    draw_text(r, 316 - text_w(a), 3, a, C_PALE, 0);
    if (scroll_knob >= 0) {
        scroll_ms = (int16_t)(scroll_ms - dt);
        if (scroll_ms <= 0) { scroll_knob = -1; return; }
        if (scroll_press) {                                    /* T1 blue / green presses */
            if (scroll_knob == 0) put(a, pw[4] >> 14 ? "reverse" : "forward");
            else put(a, (pw[3] >> 13) == 1 ? "one shot" : "gate");
        } else if (page == 0 && scroll_knob == 1) put(a, md_name[k->snd[pad] % MD_NSOUNDS]);
        else md_label(k, pw, page, pad, scroll_knob, a);
        scroll(r, a, knob_col[scroll_knob & 3]);
    }
}

static void show(int knob, int press) { scroll_knob = (int8_t)knob; scroll_press = (int8_t)press; scroll_ms = 2500; }

static int32_t acc[4];
int md_page_turn(int page, int slot, int knob, int delta)
{
    int f = md_turn_field(page, knob, SHIFT_HELD);
    if (f != F_NONE && !(SHIFT_HELD && knob == 3)) show(knob, 0);   /* (Shift + orange: volume, not shown) */
    if (f == F_STOCK) return 0;                                /* pitch, Shift + orange volume: the stock controller */
    if (f == F_NONE || (unsigned)slot >= 8 || !md_slot[slot].on) return f == F_NONE;
    int unit = f == F_SOUND || f == F_KIT ? 2048 : 1024;       /* sound / kit: one per detent */
    int32_t *a = &acc[knob & 3];
    if ((*a > 0 && delta < 0) || (*a < 0 && delta > 0)) *a = 0;
    *a += delta;
    int st = *a / unit;
    if (!st) return 1;
    *a -= st * unit;
    if (md_turn(&md_slot[slot], f, cur_pad(), st)) md_store(slot);
    return 1;
}

void md_page_press(int page, int slot, int knob)
{
    if ((unsigned)slot >= 8 || !md_slot[slot].on) return;
    if (md_press(PAD_TABLE(slot) + cur_pad() * 8, page, knob)) { md_pad_words_changed(slot); show(knob, 1); }
}
