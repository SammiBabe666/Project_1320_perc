#!/usr/bin/env python3
"""Build and run the host audio renders (sanitizers on) and write the WAVs:
    python3 harness/audition.py OP1R_SRC/synth_sdk OUT_DIR
  OUT_DIR/medieval_demo.wav       each preset kit playing a two-bar groove twice (demo.c), dry
  OUT_DIR/medieval_kit_tour.wav   every key of every kit, lowest to highest (kit_tour.c), dry
Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import os, subprocess, sys, wave
sdk, out = sys.argv[1], sys.argv[2]
HERE = os.path.dirname(os.path.abspath(__file__))
PLUG = os.path.dirname(HERE)
os.makedirs(out, exist_ok=True)
for name, wav in (('demo', 'medieval_demo.wav'), ('kit_tour', 'medieval_kit_tour.wav')):
    exe = f'/tmp/md_{name}'
    subprocess.run(['cc', '-O1', '-Wall', '-Wextra', '-fsanitize=address,undefined', '-fno-sanitize-recover=undefined',
                    '-DOP1_HOST', '-I', sdk, '-I', PLUG, os.path.join(HERE, name + '.c'), os.path.join(PLUG, 'medieval.c'),
                    '-lm', '-o', exe], check=True)
    r = subprocess.run([exe], capture_output=True, check=True)
    with wave.open(os.path.join(out, wav), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(44100); w.writeframes(r.stdout)
    print(f'{wav}: {len(r.stdout) / 88200:.1f} s, {r.stderr.decode().strip()}')
