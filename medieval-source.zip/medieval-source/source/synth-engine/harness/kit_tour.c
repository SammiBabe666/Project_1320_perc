/* Kit tour: every kit, its 24 keys from the lowest up, one hit every 0.35 s, rotating over the 6 voices and summed
 * (the firmware's envelope left at full, as with the presets' full sustain). Raw int16 mono 44.1 kHz on stdout.
 *   cc -O1 -DOP1_HOST -I<op1r-src>/synth_sdk -I.. kit_tour.c ../medieval.c -lm -o kit_tour
 *   ./kit_tour [kit 0..3 or -1 = all] [pitch] [decay] [drive] [start] [reverse] [dusk] > tour.raw
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission. */
#include "host_stubs.h"
int main(int argc, char **argv)
{
    int only = argc > 1 ? atoi(argv[1]) : -1;
    int16_t k[8] = { 0, 16384, 32767, 0, 0x5300, 0, 0, 0 };
    if (argc > 2) k[1] = (int16_t)atoi(argv[2]);
    if (argc > 3) k[2] = (int16_t)atoi(argv[3]);
    if (argc > 4) k[3] = (int16_t)atoi(argv[4]);
    for (int i = 5; i < 8 && i < argc; i++) k[i] = (int16_t)atoi(argv[i]);
    for (int i = 0; i < 128; i++) host_voice_env[i] = 32767;
    int16_t out[OP1_BLOCK]; int32_t mix[OP1_BLOCK]; int peak = 0, nv = 0, active[6] = { 0 };
    for (int kit = 0; kit < 4; kit++) {
        if (only >= 0 && kit != only) continue;
        k[0] = (int16_t)(kit * 8192 + 4096);
        for (int key = 0; key < 24 + 4; key++) {            /* 24 hits, then a short gap before the next kit */
            if (key < 24) {
                set_note(53 + key);
                ENGINE_medieval.note_on(voice(nv), k); active[nv] = 1; nv = (nv + 1) % 6;
            }
            for (int b = 0; b < 120; b++) {                  /* 0.35 s */
                for (int i = 0; i < OP1_BLOCK; i++) mix[i] = 0;
                for (int v = 0; v < 6; v++) {
                    if (!active[v]) continue;
                    ENGINE_medieval.render(voice(v), out, k);
                    for (int i = 0; i < OP1_BLOCK; i++) mix[i] += out[i] * 3 / 4;   /* -2.5 dB of mix headroom */
                }
                for (int i = 0; i < OP1_BLOCK; i++) {
                    int a = abs(mix[i]); if (a > peak) peak = a;
                    out[i] = op1_sat16(mix[i]);
                }
                fwrite(out, 2, OP1_BLOCK, stdout);
            }
        }
    }
    fprintf(stderr, "peak %d (%.1f dBFS)\n", peak, 20 * log10((peak + 1e-9) / 32768.0));
    return 0;
}
