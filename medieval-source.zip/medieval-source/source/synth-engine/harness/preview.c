/* Screen preview driver: the real engine + screen code against op1r-src's screen harness mocks, with hits at chosen
 * frames, then the last frame as JSON (as screen_harness.c prints it) for preview.py.
 *   ./preview k0 k1 k2 k3 frames "frame:midi,frame:midi,..."
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission. */
#define main screen_harness_main
#include "harness/screen_harness.c"
#undef main
static void json(void)
{
    printf("{\"nodes\": {");
    for (int i = 0; i < nnodes; i++) {
        printf("%s\"%s\": [", i ? ", " : "", node_id[i]);
        for (int j = 0; j < 9; j++) printf("%s%d", j ? ", " : "", node_m[i][j]);
        printf("]");
    }
    printf("}, \"hidden\": [], \"lines\": [");
    for (int i = 0; i < nlines; i++)
        printf("%s[%d, %d, %d, %d, %d, [%d, %d, %d, %d]]", i ? ", " : "", lines[i].x0, lines[i].y0,
               lines[i].x1, lines[i].y1, lines[i].w, lines[i].c[0], lines[i].c[1], lines[i].c[2], lines[i].c[3]);
    printf("]}\n");
}
int main(int argc, char **argv)
{
    for (int i = 0; i < 8192; i++) host_sine[i] = (int16_t)lrint(32767.0 * sin(2 * M_PI * i / 8192.0));
    for (int i = 0; i < 4; i++) host_knobs[0][i] = (int16_t)atoi(argv[1 + i]);
    host_knobs[0][4] = OP1_ENGINE_MAGIC;
    int frames = atoi(argv[5]);
    int hit_f[32], hit_n[32], nh = 0;
    for (char *p = argv[6]; *p && nh < 32; ) {
        hit_f[nh] = (int)strtol(p, &p, 10); if (*p == ':') p++;
        hit_n[nh++] = (int)strtol(p, &p, 10); if (*p == ',') p++;
    }
    for (int i = 0; i < 128; i++) host_voice_env[i] = 32767;
    int16_t out[OP1_BLOCK]; int nv = 0;
    SCREEN.init(0);
    for (int f = 0; f < frames; f++) {
        for (int h = 0; h < nh; h++) if (hit_f[h] == f) {
            for (int i = 0; i < 128; i++) host_pitch_inc[i] = (int32_t)lrint(4294967296.0 * 440.0 * pow(2, (hit_n[h] - 69) / 12.0) / 44100);
            ENGINE.note_on(OP1_VOICE(nv), host_knobs[0]);
            ENGINE.render(OP1_VOICE(nv), out, host_knobs[0]);
            nv = (nv + 1) % 6;
        }
        SCREEN.update(0, 16);
    }
    json();
    return 0;
}
