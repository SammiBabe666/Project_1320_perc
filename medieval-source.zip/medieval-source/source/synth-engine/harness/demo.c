/* Demo: each preset kit plays a two-bar groove twice at 96 BPM (sixteenth steps), dry (no OP-1 effect), voices
 * rotating over the 6 voices and summed. Raw int16 mono 44.1 kHz on stdout; harness/demo.py writes the WAV.
 *   cc -O1 -DOP1_HOST -I<op1r-src>/synth_sdk -I.. demo.c ../medieval.c -lm -o demo
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission. */
#include "host_stubs.h"
/* per kit: preset knobs (presets.py) and 32 steps; each step lists up to 3 keys (0..23, -1 none) and a velocity */
typedef struct { int16_t knobs[4]; int8_t step[32][3]; } groove_t;
#define _ { -1, -1, -1 }
static const groove_t G[4] = {
    { { 4096, 16384, 32767, 9000 }, {      /* war drums: kick and war toms, stomps, plague drum fills, a clang */
        { 0, -1, -1 }, _, _, _, { 4, -1, -1 }, _, { 1, -1, -1 }, _, { 0, 23, -1 }, _, { 6, -1, -1 }, _, { 5, -1, -1 }, _, { 7, -1, -1 }, _,
        { 0, -1, -1 }, _, { 2, -1, -1 }, _, { 12, -1, -1 }, { 14, -1, -1 }, { 1, -1, -1 }, _, { 0, 20, -1 }, _, { 16, -1, -1 }, { 13, -1, -1 }, { 5, 9, -1 }, _, { 11, -1, -1 }, { 22, -1, -1 } } },
    { { 12288, 16384, 26000, 0 }, {        /* tavern: frame drums, tambourines on the off-beats, clappers, a shout */
        { 0, -1, -1 }, { 19, -1, -1 }, { 15, -1, -1 }, { 19, -1, -1 }, { 12, 1, -1 }, { 19, -1, -1 }, { 15, -1, -1 }, { 3, -1, -1 },
        { 2, -1, -1 }, { 19, -1, -1 }, { 0, 15, -1 }, { 19, -1, -1 }, { 12, 1, -1 }, { 19, -1, -1 }, { 5, 15, -1 }, { 8, -1, -1 },
        { 0, -1, -1 }, { 19, -1, -1 }, { 15, -1, -1 }, { 19, -1, -1 }, { 14, 3, -1 }, { 19, -1, -1 }, { 15, -1, -1 }, { 10, -1, -1 },
        { 4, -1, -1 }, { 6, -1, -1 }, { 7, 15, -1 }, { 9, -1, -1 }, { 16, 1, -1 }, { 19, -1, -1 }, { 22, -1, -1 }, { 23, -1, -1 } } },
    { { 20480, 15000, 30000, 14000 }, {    /* armory: junk kick, chain and sword hits, clinks as hats */
        { 0, -1, -1 }, _, { 10, -1, -1 }, _, { 12, 3, -1 }, _, { 10, -1, -1 }, { 0, -1, -1 }, _, { 0, -1, -1 }, { 13, -1, -1 }, _, { 7, 3, -1 }, _, { 10, -1, -1 }, { 21, -1, -1 },
        { 0, -1, -1 }, _, { 10, -1, -1 }, _, { 14, 3, -1 }, _, { 11, -1, -1 }, { 0, -1, -1 }, _, { 2, -1, -1 }, { 15, -1, -1 }, _, { 19, 9, -1 }, { 17, -1, -1 }, { 16, -1, -1 }, { 22, -1, -1 } } },
    { { 28672, 16384, 32767, 3000 }, {     /* royal court: ceremonial kick, deep toms, a fanfare of stabs and a horn */
        { 0, 12, -1 }, _, _, _, { 3, -1, -1 }, _, { 0, -1, -1 }, _, { 4, 14, -1 }, _, { 6, -1, -1 }, _, { 3, -1, -1 }, _, { 7, -1, -1 }, { 9, -1, -1 },
        { 0, 16, -1 }, _, _, { 0, -1, -1 }, { 3, 18, -1 }, _, _, _, { 4, 23, -1 }, _, { 6, -1, -1 }, _, { 3, 21, -1 }, { 11, -1, -1 }, { 9, -1, -1 }, { 8, -1, -1 } } },
};
int main(void)
{
    for (int i = 0; i < 128; i++) host_voice_env[i] = 32767;
    int16_t out[OP1_BLOCK]; int32_t mix[OP1_BLOCK]; int peak = 0, nv = 0, active[6] = { 0 }, note[6] = { 0 };
    const int step_blocks = 54;                              /* 96 BPM sixteenths: 6891 samples ~ 54 blocks */
    for (int kit = 0; kit < 4; kit++) {
        int16_t k[8] = { G[kit].knobs[0], G[kit].knobs[1], G[kit].knobs[2], G[kit].knobs[3], 0x5300, 0, 0, 0 };
        for (int st = 0; st < 64 + 12; st++) {                 /* twice, then a pause */
            if (st < 64)
                for (int j = 0; j < 3; j++) {
                    int key = G[kit].step[st % 32][j];
                    if (key < 0) continue;
                    note[nv] = 53 + key;
                    host_voice_vel[nv] = (int16_t)(((st & 3) ? 90 : 127) << 8);
                    ENGINE_medieval.note_on(voice(nv), k);
                    active[nv] = 1; nv = (nv + 1) % 6;
                }
            for (int b = 0; b < step_blocks; b++) {
                for (int i = 0; i < OP1_BLOCK; i++) mix[i] = 0;
                for (int v = 0; v < 6; v++) {
                    if (!active[v]) continue;
                    set_note(note[v]);                          /* as the firmware: the pitch of the voice rendered */
                    ENGINE_medieval.render(voice(v), out, k);
                    /* velocity as the firmware applies it after render (stand-in: linear) */
                    int32_t g = (host_voice_vel[v] >> 8) * 258;
                    for (int i = 0; i < OP1_BLOCK; i++) mix[i] += ((out[i] * g) >> 16) * 3 / 4;   /* and -8.5 dB of mix headroom */
                }
                for (int i = 0; i < OP1_BLOCK; i++) { int a = abs(mix[i]); if (a > peak) peak = a; out[i] = op1_sat16(mix[i]); }
                fwrite(out, 2, OP1_BLOCK, stdout);
            }
        }
    }
    fprintf(stderr, "peak %d (%.1f dBFS)\n", peak, 20 * log10((peak + 1e-9) / 32768.0));
    return 0;
}
