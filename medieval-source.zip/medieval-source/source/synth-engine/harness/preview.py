#!/usr/bin/env python3
"""Knob-state preview grid of the medieval screen (real engine and screen code, mocked firmware calls), in the layout
of the Project ERD preview: 2 columns, a caption under each frame. Uses op1r-src's harness (render.py, screen_harness.c).

    python3 harness/preview.py OP1R_SRC/synth_sdk out.png
Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import json, os, subprocess, sys
import xml.etree.ElementTree as ET
sdk, out = sys.argv[1], sys.argv[2]
HERE = os.path.dirname(os.path.abspath(__file__))
PLUG = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(sdk, 'harness'))
import render, cairo  # noqa: E402

D = [4096, 16384, 32767, 0]
# (caption, knobs blue/green/white/orange, frames at 60 fps, hits "frame:midi,...")
STATES = [
    ('defaults: kit I war drums, no hit', D, 30, ''),
    ('low key struck: the drum rings, sticks strike', D, 24, '0:53,8:55,16:57'),
    ('high key struck: the bell swings and rings', D, 30, '0:70,14:72'),
    ('kit II, pitch up: horns tilt up', [12288, 32767, 16000, 0], 20, '0:57,10:74'),
    ('kit III, pitch down: horns tilt down', [20480, 0, 16000, 0], 20, '0:58'),
    ('kit IV, short decay: small, quick rings', [28672, 16384, 2000, 0], 12, '0:55,6:72'),
    ('drive max: rings flare, red sparks', [4096, 16384, 26000, 32767], 26, '0:53,8:70,16:56'),
    ('decay max: lattice lit, wide rings', [4096, 16384, 32767, 12000], 50, '0:53,12:70,24:60,36:74'),
]
exe = '/tmp/md_preview'
srcs = [os.path.join(PLUG, s) for s in ('medieval.c', 'mdscreen.c')]
subprocess.run(['cc', '-O1', '-Wall', '-Wno-unused-parameter', '-fsanitize=address,undefined', '-DOP1_HOST',
                '-DENGINE=ENGINE_medieval', '-DSCREEN=SCREEN_medieval', '-I', sdk, '-I', PLUG,
                os.path.join(HERE, 'preview.c'), *srcs, '-lm', '-o', exe], check=True)
svg = ET.parse(os.path.join(PLUG, 'medieval.svg')).getroot()
S, PAD, CAP = 2, 20, 28
W, H = 320 * S, 160 * S
single = os.environ.get('SINGLE')
states = [STATES[int(single)]] if single else STATES
cols, rows = (1, 1) if single else (2, (len(states) + 1) // 2)
if single:
    S, PAD, CAP = 4, 0, 0
    W, H = 320 * S, 160 * S
surf = cairo.ImageSurface(cairo.FORMAT_RGB24, cols * (W + PAD) + PAD, rows * (H + CAP + PAD) + PAD)
ctx = cairo.Context(surf); ctx.set_source_rgb(0.133, 0.133, 0.133); ctx.paint()
for n, (cap, k, frames, hits) in enumerate(states):
    fr = json.loads(subprocess.run([exe, *map(str, k), str(frames), hits], check=True, capture_output=True,
                                   text=True).stdout)
    x0, y0 = PAD + (n % cols) * (W + PAD), PAD + (n // cols) * (H + CAP + PAD)
    ctx.save(); ctx.translate(x0, y0); ctx.rectangle(0, 0, W, H); ctx.clip()
    ctx.set_source_rgb(0, 0, 0); ctx.paint(); ctx.scale(S, S)
    render.STYLES.clear()
    render.draw_svg(ctx, svg, fr['nodes'], set())
    for x1, y1, x2, y2, w, c in fr['lines']:
        ctx.set_source_rgb(*(v / 255 for v in c[:3])); ctx.set_line_width(w / 1024); ctx.set_line_cap(cairo.LINE_CAP_BUTT)
        ctx.move_to(x1 / 1024, y1 / 1024); ctx.line_to(x2 / 1024, y2 / 1024); ctx.stroke()
    ctx.restore()
    if not single:
        ctx.set_source_rgb(0.7, 0.7, 0.7); ctx.select_font_face('DejaVu Sans'); ctx.set_font_size(12)
        ctx.move_to(x0, y0 + H + 17); ctx.show_text(f'{cap}   ({", ".join(map(str, k))})')
surf.write_to_png(out); print('->', out)
