/* Host range test under ASan + UBSan (no recovery): every MIDI note 0..127 on every voice, knob corners on both pages,
 * retriggers mid-sound, envelope words untouched; checks the voice vtable word is never written, the output never
 * jumps by more than a sound could (no clicks at hit, retrigger or end), and that the C ADPCM decoder matches
 * tools/build_bank.py's (checksum printed for the Python side to compare).
 *   cc -fsanitize=address,undefined -fno-sanitize-recover=undefined -DOP1_HOST -I<op1r-src>/synth_sdk -I.. \
 *      range_test.c -lm -o range_test     (includes ../medieval.c itself, to reach the decoder)
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission. */
#include "host_stubs.h"
#include "../medieval.c"
int main(void)
{
    /* 1. decoder checksum over the whole bank */
    uint32_t sum = 0; int16_t b[MD_BLOCK + 1];
    for (uint32_t i = 0; i < sizeof md_adpcm / MD_BLOCK_BYTES; i++) {
        md_decode(b, md_adpcm + i * MD_BLOCK_BYTES);
        for (int j = 0; j <= MD_BLOCK; j++) sum = sum * 31u + (uint16_t)b[j];
    }
    printf("decoder checksum %08x over %u blocks\n", sum, (unsigned)(sizeof md_adpcm / MD_BLOCK_BYTES));

    /* 2. ranges */
    static const int16_t corners[] = { 0, 1, 8191, 16384, 24576, 32766, 32767 };
    for (int v = 0; v < 6; v++) *(uint32_t *)voice(v) = 0xdeadbeef;
    for (int i = 0; i < 128; i++) host_voice_env[i] = 32767;
    int16_t out[OP1_BLOCK]; long blocks = 0; int peak = 0, hits = 0;
    for (int midi = 0; midi < 128; midi++)
        for (int c = 0; c < 49; c++) {
            int16_t k[8] = { corners[c % 7], corners[(c / 7) % 7], corners[(midi + c) % 7], corners[(midi / 7) % 7],
                             0x5300, corners[(c + 3) % 7], corners[(c + midi) % 7], corners[(c * 3 + midi) % 7] };
            void *self = voice((midi + c) % 6);
            set_note(midi + ((c % 3) - 1) * 0.3);          /* also slightly detuned notes */
            ENGINE_medieval.note_on(self, k); hits++;
            int len = 20 + (c * 37) % 300;                  /* retrigger after 0.06 .. 0.9 s, often mid-sound */
            for (int bl = 0; bl < len; bl++) {
                ENGINE_medieval.render(self, out, k); blocks++;
                for (int i = 0; i < OP1_BLOCK; i++) { int a = abs(out[i]); if (a > peak) peak = a; }
            }
        }
    for (int v = 0; v < 6; v++) if (*(uint32_t *)voice(v) != 0xdeadbeef) { puts("FAIL: vtable overwritten"); return 1; }

    /* 3. clicks: the first sample of every hit starts near zero (the bank keeps 2 ms of lead-in), a retrigger while
     *    sounding continues from the last output (the old hit fades out over 64 samples), every sound ends at zero */
    int worst_start = 0, worst_retrig = 0;
    for (int kit = 0; kit < MD_KITS; kit++)
        for (int key = 0; key < 24; key++) {
            int16_t k[8] = { (int16_t)(kit * 8192 + 4096), 16384, 32767, 0, 0x5300, 0, 0, 0 };
            set_note(53 + key);
            ENGINE_medieval.note_on(voice(0), k);
            int16_t prev = 0;
            for (int bl = 0; bl < 400; bl++) {
                if (bl == 3) ENGINE_medieval.note_on(voice(0), k);        /* retrigger while sounding */
                ENGINE_medieval.render(voice(0), out, k);
                if (bl == 0 && abs(out[0]) > worst_start) worst_start = abs(out[0]);
                if (bl == 3 && abs(out[0] - prev) > worst_retrig) worst_retrig = abs(out[0] - prev);
                prev = out[OP1_BLOCK - 1];
            }
            if (prev != 0) { printf("FAIL: kit %d key %d still sounding after 1.16 s\n", kit, key); return 1; }
        }
    if (worst_start > 1500 || worst_retrig > 3000) { printf("FAIL: click: start %d, retrigger %d\n", worst_start, worst_retrig); return 1; }
    printf("range test ok: %d hits, %ld blocks, all notes, knob corners both pages, peak %d (%.1f dBFS), "
           "first sample of a hit <= %d, step at a retrigger <= %d\n", hits, blocks, peak, 20 * log10(peak / 32768.0), worst_start, worst_retrig);
    return 0;
}
