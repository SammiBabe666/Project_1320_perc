/* medieval: an EP-1320 Medieval drum kit on the OP-1's 24 keys, as a synth engine (Project Medieval).
 * Every key plays its own recorded sound from the sample bank compiled into the plugin (md_bank.h, made from the
 * owner's own EP-1320 exports by tools/build_bank.py). Four kits of 24 sounds each.
 *   blue  : KIT    - war drums, tavern, armory, royal court (four zones of the knob; read when a key is struck)
 *   green : PITCH  - the whole kit up or down, +-12 semitones (centre = as recorded)
 *   white : DECAY  - how long each hit rings: 40 ms .. 4 s to fall 60 dB; fully up = the sound's natural length
 *   red   : DRIVE  - (the orange knob) gain into a soft clip, with level compensation; 0 = clean
 * Page 2 (press the knob; saved with the sound):
 *   blue  : START  - start later in the sound, up to 3/4 of its length
 *   green : REVERSE - right half of the knob plays the sound backwards
 *   white : DUSK   - darkens the tone (one-pole low pass); 0 = open
 * The stock T2 envelope and velocity still shape the volume after render: for one-shot drums the presets use a fast
 * attack, full sustain and a long release, so a hit rings on after the key is let go.
 * Click-free by design: every sound in the bank ends faded to zero, a later START fades in over 64 samples, a voice that
 * is retriggered while sounding fades its last output out over 64 samples, and DECAY ramps within each block.
 * Integer only. Per sample: one interpolation, one envelope multiply, the optional drive and tone. The bank is IMA ADPCM
 * in independent 64-sample blocks; a voice decodes the block it is in (once per 64 source samples) into its buffer.
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and
 * NOTICE). */
#include "op1_plugin.h"
#include "md_bank.h"
#define MD_SYNTH_TABLES
#include "md_tables.h"

#define KEY_BASE    53          /* MIDI note of the OP-1's lowest key (F) at octave 0: key 0 of the kit */
#define DECLICK     64          /* samples: fade of a retriggered voice's last output, and of a later START */
#define OUT_GAIN    24576       /* Q15, -2.5 dB: the bank peaks at -1 dBFS, so one voice peaks near -3.5 dBFS */
#define ENV_STOP    8           /* Q15 envelope below which a decaying voice stops */

enum { V_OFF = 0, V_PENDING, V_PLAY };

typedef struct {
    int32_t pos;                /* Q16 position in the sound (samples at the sound's own rate) */
    int32_t env;                /* DECAY envelope, Q15 */
    int32_t blk;                /* block decoded into buf, -1: none */
    int16_t buf[MD_BLOCK + 1];  /* the decoded block: samples 64 blk .. 64 blk + 64 */
    int16_t last;               /* last output sample */
    int16_t declick;            /* output at a retrigger, faded out over DECLICK samples */
    int16_t lp;                 /* DUSK low-pass state */
    uint16_t age;               /* samples since the hit, saturating (START fade-in) */
    uint8_t state, snd, key, rev, fade_in;
    int8_t tune;
} md_voice_t;

static md_voice_t md_v[OP1_VOICES];

/* read by the screen (mdscreen.c): a counter that steps on every hit, the last key and kit, and each voice's level */
volatile uint8_t md_hit_count, md_hit_key, md_hit_kit;
volatile int16_t md_level[OP1_VOICES];

static const int16_t ima_step[89] = {
    7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107,
    118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963,
    1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894,
    6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794,
    32767 };
static const int8_t ima_index[8] = { -1, -1, -1, -1, 2, 4, 6, 8 };

/* decode one 36-byte block (int16 first sample, uint8 step index, pad, 64 nibbles) into 65 samples */
static void md_decode(int16_t *out, const uint8_t *b)
{
    int32_t pred = (int16_t)(b[0] | (b[1] << 8)), idx = b[2];
    out[0] = (int16_t)pred;
    for (int i = 0; i < MD_BLOCK; i++) {
        int32_t n = (b[4 + (i >> 1)] >> ((i & 1) << 2)) & 15, st = ima_step[idx], d = st >> 3;
        if (n & 1) d += st >> 2;
        if (n & 2) d += st >> 1;
        if (n & 4) d += st;
        pred = n & 8 ? pred - d : pred + d;
        pred = pred > 32767 ? 32767 : (pred < -32768 ? -32768 : pred);
        idx += ima_index[n & 7];
        idx = idx < 0 ? 0 : (idx > 88 ? 88 : idx);
        out[i + 1] = (int16_t)pred;
    }
}

static md_voice_t *md_voice(void *self)
{
    int i = op1_voice_index(self);
    return &md_v[i < 0 ? 0 : (i >= OP1_VOICES ? OP1_VOICES - 1 : i)];
}

/* nearest MIDI note of a phase increment (binary search over the half-note thresholds) */
static int md_note_of(uint32_t inc)
{
    int lo = 0, hi = 127;
    while (lo < hi) {
        int mid = (lo + hi) >> 1;
        if (inc < md_note_thr[mid]) hi = mid; else lo = mid + 1;
    }
    return lo;
}

static void md_note_on(void *self, const int16_t *params)
{
    md_voice_t *v = md_voice(self); (void)params;
    v->declick = v->state != V_OFF ? v->last : 0;
    v->state = V_PENDING;               /* the key is read from OP1_PITCH_INC in the first render */
}

/* first render of a hit: find the key, take the kit, place the start */
static void md_start(md_voice_t *v, const int16_t *params)
{
    int note = md_note_of((uint32_t)OP1_PITCH_INC[0]);
    int key = (note - KEY_BASE) % 24; if (key < 0) key += 24;
    int kit = (params[0] * MD_KITS) >> 15; if (kit > MD_KITS - 1) kit = MD_KITS - 1; if (kit < 0) kit = 0;
    const md_key_t *k = &md_kit[kit][key];
    const md_sound_t *s = &md_sound[k->snd];
    int32_t w5 = params[5] < 0 ? 0 : params[5], last = s->len - 1;
    int32_t off = (int32_t)(((uint32_t)last * (uint32_t)(w5 * 3 >> 2)) >> 15);   /* START: up to 3/4 */
    v->snd = k->snd; v->tune = k->tune; v->key = (uint8_t)key;
    v->rev = params[6] >= 16384;
    v->pos = (v->rev ? last - 1 - off : off) << 16;
    if (v->pos < 0) v->pos = 0;
    v->fade_in = off > 0;
    v->env = 32767; v->blk = -1; v->lp = 0; v->age = 0;
    v->state = V_PLAY;
    md_hit_key = (uint8_t)key; md_hit_kit = (uint8_t)kit; md_hit_count++;
}

static void md_render(void *self, int16_t *out, const int16_t *params)
{
    md_voice_t *v = md_voice(self);
    int vi = (int)(v - md_v);
    if (v->state == V_PENDING) md_start(v, params);

    int32_t dc = v->declick;
    if (v->state != V_PLAY) {
        for (int i = 0; i < OP1_BLOCK; i++) out[i] = i < DECLICK ? (int16_t)(dc * (DECLICK - i) / DECLICK) : 0;
        v->declick = 0; v->last = 0; md_level[vi] = 0;
        return;
    }

    /* per block: rate, envelope ramp, drive and tone settings */
    const md_sound_t *s = &md_sound[v->snd];
    int32_t q = ((params[1] - 16384) * 3) >> 10;                     /* green: -48..48 quarter semitones */
    q += v->tune * 4;
    q = q < -96 ? -96 : (q > 96 ? 96 : q);
    int32_t inc = (int32_t)(((int64_t)s->inc * md_pitch[q + 96]) >> 16);
    if (inc < 1) inc = 1;
    int32_t e0 = v->env;
    int32_t e1 = (int32_t)(((int64_t)e0 * md_decay[(params[2] < 0 ? 0 : params[2]) >> 10]) >> 15);
    if (e1 > 32767) e1 = 32767;
    int32_t de = e1 - e0;
    int32_t drive = params[3] < 0 ? 0 : params[3];
    int32_t dg = 4096 + ((drive * 7) >> 3);                          /* Q12 gain 1 .. 8 */
    int32_t mk = OUT_GAIN - ((drive * 11000) >> 15);                  /* level compensation for the clip */
    int32_t dusk = params[7] < 0 ? 0 : params[7];
    int32_t a = 32767 - ((dusk * 31000) >> 15);                       /* low pass: open .. ~240 Hz */
    int32_t last = s->len - 1;
    const uint8_t *base = md_adpcm + s->block * MD_BLOCK_BYTES;

    int32_t pos = v->pos, lp = v->lp, y = 0;
    int i = 0;
    for (; i < OP1_BLOCK; i++) {
        int32_t idx = pos >> 16;
        if (pos < 0 || idx >= last) { v->state = V_OFF; break; }
        int32_t blk = idx >> 6;
        if (blk != v->blk) { md_decode(v->buf, base + blk * MD_BLOCK_BYTES); v->blk = blk; }
        int32_t off = idx & (MD_BLOCK - 1), s0 = v->buf[off], s1 = v->buf[off + 1];
        int32_t x = s0 + (((s1 - s0) * ((pos >> 2) & 0x3FFF)) >> 14);
        x = (x * (e0 + ((de * i) >> 7))) >> 15;                        /* DECAY */
        if (v->fade_in && v->age < DECLICK) x = x * v->age / DECLICK;
        if (drive > 256) {                                            /* DRIVE: cubic soft clip */
            x = (x * dg) >> 12;
            x = x > 32767 ? 32767 : (x < -32767 ? -32767 : x);
            int32_t x2 = (x * x) >> 15;
            x = ((3 * x) >> 1) - (((x * x2) >> 15) >> 1);
        }
        if (dusk > 256) { lp += ((x - lp) * a) >> 15; x = lp; }      /* DUSK */
        y = (x * mk) >> 15;
        if (i < DECLICK && dc) y += dc * (DECLICK - i) / DECLICK;
        out[i] = op1_sat16(y);
        if (v->age < 0xFFFF) v->age++;
        pos = v->rev ? pos - inc : pos + inc;
    }
    for (; i < OP1_BLOCK; i++) {                                        /* the sound ended inside this block */
        y = i < DECLICK && dc ? dc * (DECLICK - i) / DECLICK : 0;
        out[i] = (int16_t)y;
    }
    v->pos = pos; v->lp = (int16_t)lp; v->env = e1; v->declick = 0; v->last = out[OP1_BLOCK - 1];
    if (e1 < ENV_STOP) v->state = V_OFF;
    md_level[vi] = v->state == V_PLAY ? (int16_t)e1 : 0;
}

const op1_engine_t ENGINE_medieval = {
    .note_on = md_note_on,
    .render = md_render,
    .note_off = 0,                      /* one-shot: a hit plays out; the stock release still applies */
    .press = { OP1_PRESS_PAGE, OP1_PRESS_PAGE, OP1_PRESS_PAGE, OP1_PRESS_NONE },
};
