/* medieval screen: King David and his musicians (medieval.svg, made by gen_svg.py), OP-1 line style.
 *   every hit     : a ring of sound spreads from the drummer's nakers (keys 1-12) or from the bell (keys 13-24); the
 *                   drummer's sticks strike, the bell swings
 *   blue  (kit)   : the kit's numeral, I to IV, in a red rubric box at the top left, as in a manuscript
 *   green (pitch) : the two horns tilt up for a higher kit, down for a lower one
 *   white (decay) : rings travel further and last longer, the bell swings longer, more of the lattice lights up
 *   red   (drive) : rings flare into a turning six-pointed star and throw red sparks
 * The diamond lattice of the manuscript's background, rings, sparks and the numeral are raster lines drawn after the
 * SVG (lines drawn before it are lost). Integer only.
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and
 * NOTICE). */
#include "op1_plugin.h"

/* geometry: must match gen_svg.py (PIVOTS) */
#define HORN_L_X 112
#define HORN_R_X 208
#define HORN_Y   52
#define STICK_X  34
#define STICK_Y  92
#define BELL_X   160
#define BELL_Y   6
#define DRUM_X   34           /* where low-key rings start: between the nakers */
#define DRUM_Y   102
#define CLAP_X   160          /* where high-key rings start: the bell's mouth */
#define CLAP_Y   28
#define N_RINGS  8
#define N_LAT    64
#define DEG(d)   ((d) * 8192 / 360)     /* sine-table units */

extern volatile uint8_t md_hit_count, md_hit_key, md_hit_kit;     /* medieval.c */

static const uint8_t C_BLUE[4]  = { 0x4D, 0x9E, 0xFF, 0xFF };
static const uint8_t C_WHITE[4] = { 0xFF, 0xFF, 0xFF, 0xFF };
static const uint8_t C_GREY[4]  = { 0x6F, 0x71, 0x73, 0xFF };
static const uint8_t C_RED[4]   = { 0xFF, 0x3A, 0x5D, 0xFF };

/* the lattice shows only where no figure stands: these boxes (px) are kept clear */
static const int16_t clear_box[][4] = {
    { 12, 46, 58, 150 }, { 60, 38, 102, 150 }, { 82, 4, 138, 150 }, { 124, 0, 196, 150 }, { 182, 4, 240, 150 },
    { 224, 40, 286, 150 }, { 268, 40, 316, 150 }, { 4, 4, 32, 30 },
};

typedef struct { int16_t x, y; int16_t age, life; uint8_t on, bell; uint16_t seed; } ring_t;

static void *n_horn_l, *n_horn_r, *n_sticks, *n_bell;
static uint32_t t_ms;
static uint8_t seen_hits;
static ring_t rings[N_RINGS];
static int16_t lat_x[N_LAT], lat_y[N_LAT];
static int n_lat;
static int32_t stick_t = 1000, bell_t = 10000;                      /* ms since the last strike / bell hit */

static inline int32_t tsin(int32_t a) { return OP1_SINE_TABLE[a & 8191]; }
static inline int32_t tcos(int32_t a) { return tsin(a + 2048); }

static void seg(void *r, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t w, const uint8_t *c)
{
    op1_pt a = { x0, y0 }, b = { x1, y1 };
    op1_raster_line(r, &a, &b, w, c);
}

static void rotate(void *node, int32_t px, int32_t py, int32_t ang)
{
    if (node) op1_node_rotate(node, OP1_Q10(px), OP1_Q10(py), tsin(ang), tcos(ang));
}

static void md_scr_init(void *scr)
{
    n_horn_l = op1_find_node(scr, "hornL");
    n_horn_r = op1_find_node(scr, "hornR");
    n_sticks = op1_find_node(scr, "sticks");
    n_bell = op1_find_node(scr, "bell");
    /* diamond lattice: crossings every 14 px, every other row shifted by half */
    n_lat = 0;
    for (int y = 8; y < 48 && n_lat < N_LAT; y += 7)
        for (int x = 8 + ((y / 7) & 1) * 7; x < 314 && n_lat < N_LAT; x += 14) {
            int clear = 1;
            for (unsigned b = 0; b < sizeof clear_box / sizeof clear_box[0]; b++)
                if (x >= clear_box[b][0] && x <= clear_box[b][2] && y >= clear_box[b][1] && y <= clear_box[b][3]) clear = 0;
            if (clear) { lat_x[n_lat] = (int16_t)x; lat_y[n_lat] = (int16_t)y; n_lat++; }
        }
    for (int i = 0; i < N_RINGS; i++) rings[i].on = 0;
    seen_hits = md_hit_count;
    t_ms = 0;
}

static void spawn(int bell, int32_t decay, int seed)
{
    int best = 0;
    for (int i = 0; i < N_RINGS; i++) {                             /* a free ring, else the oldest */
        if (!rings[i].on) { best = i; break; }
        if (rings[i].age > rings[best].age) best = i;
    }
    ring_t *g = &rings[best];
    g->on = 1; g->bell = (uint8_t)bell; g->age = 0;
    g->x = bell ? CLAP_X : DRUM_X; g->y = bell ? CLAP_Y : DRUM_Y;
    g->life = (int16_t)(350 + ((decay * 1650) >> 15));
    g->seed = (uint16_t)(seed * 40503u + t_ms);
    if (bell) bell_t = 0; else stick_t = 0;
}

/* the kit numeral I..IV in a red box at the top left */
static void numeral(void *r, int kit)
{
    int32_t x0 = OP1_Q10(8), y0 = OP1_Q10(8), x1 = OP1_Q10(30), y1 = OP1_Q10(26), w = OP1_Q10(1);
    seg(r, x0, y0, x1, y0, w, C_RED); seg(r, x1, y0, x1, y1, w, C_RED);
    seg(r, x1, y1, x0, y1, w, C_RED); seg(r, x0, y1, x0, y0, w, C_RED);
    int32_t top = OP1_Q10(12), bot = OP1_Q10(22), sw = OP1_Q10(1.5);
    if (kit < 3) {                                                  /* I, II, III */
        int32_t x = OP1_Q10(19) - kit * OP1_Q10(2.5);
        for (int i = 0; i <= kit; i++) seg(r, x + i * OP1_Q10(5), top, x + i * OP1_Q10(5), bot, sw, C_WHITE);
    } else {                                                        /* IV */
        seg(r, OP1_Q10(14), top, OP1_Q10(14), bot, sw, C_WHITE);
        seg(r, OP1_Q10(18), top, OP1_Q10(21), bot, sw, C_WHITE);
        seg(r, OP1_Q10(21), bot, OP1_Q10(24), top, sw, C_WHITE);
    }
}

static void md_scr_update(void *scr, int dt)
{
    int16_t k[4];
    op1_synth_knobs_live(OP1_SCREEN_SLOT & 7, k);
    int32_t kitk = k[0], pitch = k[1], decay = k[2], drive = k[3];
    t_ms += (uint32_t)dt;
    int32_t t = (int32_t)(t_ms & 0x3FFFFFF);

    /* new hits since the last frame (at most 3 rings per frame) */
    uint8_t hc = md_hit_count;
    int n_new = (uint8_t)(hc - seen_hits); seen_hits = hc;
    if (n_new > 3) n_new = 3;
    for (int i = 0; i < n_new; i++) spawn(md_hit_key >= 12, decay, hc - i);

    /* green: horns tilt +-12 degrees with the pitch, outward = higher */
    int32_t tilt = ((pitch - 16384) * DEG(12)) >> 14;
    rotate(n_horn_l, HORN_L_X, HORN_Y, tilt);
    rotate(n_horn_r, HORN_R_X, HORN_Y, -tilt);
    /* sticks: a 10 degree strike that springs back over 150 ms */
    stick_t += dt; if (stick_t > 1000) stick_t = 1000;
    int32_t sa = stick_t < 150 ? DEG(10) * (150 - stick_t) / 150 : 0;
    rotate(n_sticks, STICK_X, STICK_Y, sa);
    /* bell: swings 14 degrees, period 700 ms, dying away over 0.5 .. 3 s with the decay */
    bell_t += dt; if (bell_t > 10000) bell_t = 10000;
    int32_t bdie = 500 + ((decay * 2500) >> 15);
    int32_t ba = bell_t < bdie ? (int32_t)((tsin(bell_t * 8192 / 700) * DEG(14)) >> 15) * (bdie - bell_t) / bdie : 0;
    rotate(n_bell, BELL_X, BELL_Y, ba);

    op1_screen_draw(scr, dt);                                       /* the SVG first: raster lines before it are lost */
    void *r = op1_raster();

    /* lattice crossings: grey; with more decay more of them light up white and twinkle */
    int32_t lit = (decay * n_lat) >> 15;
    for (int i = 0; i < n_lat; i++) {
        int32_t x = OP1_Q10(lat_x[i]), y = OP1_Q10(lat_y[i]), h = OP1_Q10(1.5);
        const uint8_t *c = C_GREY;
        if (((i * 37) % n_lat) < lit && tsin(t * 2 + i * 1300) > -20000) c = C_WHITE;
        seg(r, x - h, y - h, x + h, y + h, OP1_Q10(1), c);
        seg(r, x - h, y + h, x + h, y - h, OP1_Q10(1), c);
    }

    numeral(r, (kitk * 4) >> 15 > 3 ? 3 : (kitk * 4) >> 15);

    /* rings: 24 segments; radius grows from 4 px to 14..44 px over the ring's life; flaring and sparking with drive */
    int32_t rmax = 14 + ((decay * 30) >> 15);
    for (int n = 0; n < N_RINGS; n++) {
        ring_t *g = &rings[n];
        if (!g->on) continue;
        g->age = (int16_t)(g->age + dt);
        if (g->age >= g->life) { g->on = 0; continue; }
        int32_t p = (g->age << 15) / g->life;                       /* 0..32767 through its life */
        int32_t rad = OP1_Q10(4) + ((OP1_Q10(rmax - 4) >> 5) * ((p * (65536 - p)) >> 15) >> 10);   /* eases out */
        if (g->bell) rad = rad * 3 >> 2;
        const uint8_t *c = p > 21800 ? C_GREY : (g->bell ? C_BLUE : C_WHITE);
        int32_t jag = (drive * OP1_Q10(3)) >> 15;
        uint32_t s = g->seed;
        int32_t px = 0, py = 0;
        for (int i = 0; i <= 24; i++) {
            int32_t a = (i % 24) * 8192 / 24;
            int32_t rr = rad + ((jag * tsin(a * 6 + g->seed + t)) >> 15);     /* a six-pointed, turning flare */
            int32_t x = OP1_Q10(g->x) + ((tcos(a) * (rr >> 5)) >> 10), y = OP1_Q10(g->y) + ((tsin(a) * (rr >> 5)) >> 10);
            if (i && (y < OP1_Q10(140) || py < OP1_Q10(140))) seg(r, px, py, x, y, OP1_Q10(1), c);   /* not below the ground */
            px = x; py = y;
        }
        int sparks = (drive * 7) >> 15;                             /* red sparks thrown outward */
        for (int i = 0; i < sparks; i++) {
            s = s * 1664525u + 1013904223u;
            int32_t a = (int32_t)(s >> 19), r0 = rad + OP1_Q10(3), r1 = r0 + OP1_Q10(4);
            int32_t x0 = OP1_Q10(g->x) + ((tcos(a) * (r0 >> 5)) >> 10), y0 = OP1_Q10(g->y) + ((tsin(a) * (r0 >> 5)) >> 10);
            int32_t x1 = OP1_Q10(g->x) + ((tcos(a) * (r1 >> 5)) >> 10), y1 = OP1_Q10(g->y) + ((tsin(a) * (r1 >> 5)) >> 10);
            if (y1 < OP1_Q10(140) && p < 21800) seg(r, x0, y0, x1, y1, OP1_Q10(1), C_RED);
        }
    }
}

const op1_screen_t SCREEN_medieval = { md_scr_init, md_scr_update };
