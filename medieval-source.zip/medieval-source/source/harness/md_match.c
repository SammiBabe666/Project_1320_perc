/* v0.2.3 against v0.2.2: the same hits through both versions' md_voice.c, sample by sample. Build: harness/match.sh.
 * Every one of the 96 sounds, forwards and reversed, at four starts, three pitches, the extreme decay, drive, dusk
 * and age, with steady and changing velocity, gate releases and retriggers mid-sound. The new voice must give the
 * same samples as v0.2.2's (the changes in md_voice.c are meant to change no sample).
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission. */
#include "md_voice.h"
#include <stdio.h>
#include <string.h>
void ref_md_voice_on(md_voice_t *v, const md_kit_t *k, int pad, int reverse);
void ref_md_voice_release(md_voice_t *v);
int ref_md_voice_render(md_voice_t *v, const md_kit_t *k, int16_t *out, const int32_t *inc, const int16_t *vel,
                        int16_t volume);
static uint32_t rnd = 12345;
static uint32_t next(void) { rnd = rnd * 1664525u + 1013904223u; return rnd >> 8; }
int main(void)
{
    static const int steps[3] = { 512, 2048, 8192 }, vals[3] = { 0, 15, 31 };
    long blocks = 0, samples = 0, diffs = 0, hits = 0;
    md_kit_t k; md_kit_defaults(&k);
    md_voice_t a, b; memset(&a, 0, sizeof a); memset(&b, 0, sizeof b);
    int32_t inc[128]; int16_t vel[128], oa[128], ob[128];
    for (int snd = 0; snd < 96; snd++)
    for (int rev = 0; rev < 2; rev++)
    for (int st = 0; st < 4; st++)
    for (int pi = 0; pi < 3; pi++)
    for (int set = 0; set < 6; set++) {
        k.snd[0] = (uint8_t)snd; k.start[0] = (uint8_t)(st * 10);
        k.decay = (uint8_t)(set == 0 ? 31 : vals[next() % 3]);
        k.drive = (uint8_t)(set < 2 ? 0 : vals[next() % 3]);
        k.dusk = (uint8_t)(set < 2 ? 0 : vals[next() % 3]);
        k.age = (uint8_t)(set < 2 ? 0 : vals[next() % 3]);
        int16_t volume = (int16_t)(set == 5 ? 16384 : set == 4 ? 4096 : 8192);
        int vary = set >= 3, release_at = set == 2 ? 6 : -1, retrig_at = set == 4 ? 3 : -1;
        for (int i = 0; i < 128; i++) inc[i] = steps[pi] << 17;
        ref_md_voice_on(&a, &k, 0, rev); md_voice_on(&b, &k, 0, rev); hits++;
        for (int bl = 0; bl < 3000; bl++) {
            for (int i = 0; i < 128; i++) vel[i] = (int16_t)((vary ? 40 + (int)(next() % 88) : 127) << 8);
            if (bl == release_at) { ref_md_voice_release(&a); md_voice_release(&b); }
            if (bl == retrig_at) { ref_md_voice_on(&a, &k, 0, !rev); md_voice_on(&b, &k, 0, !rev); hits++; }
            int ra = ref_md_voice_render(&a, &k, oa, inc, vel, volume), rb = md_voice_render(&b, &k, ob, inc, vel, volume);
            blocks++; samples += 128;
            for (int i = 0; i < 128; i++) if (oa[i] != ob[i]) diffs++;
            if (ra != rb) { printf("FAIL: voice state differs, sound %d block %d\n", snd, bl); return 1; }
            if (!ra) break;
        }
    }
    printf("match: %ld hits, %ld blocks, %ld samples, %ld samples differ\n", hits, blocks, samples, diffs);
    return diffs ? 1 : 0;
}
