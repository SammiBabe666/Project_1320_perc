/* Cycle bench for the drum voice in GDB's Blackfin simulator (bf524 model): v0.2.2's md_voice_render against
 * v0.2.3's, the same hits through both, and a check that both give the same samples (a hash of every block).
 * Cases: one plain hit (decay full, no drive, dusk or age) and the heaviest (decay 15, drive, dusk and age at full,
 * reversed, a late start), each at three pitches; and twelve voices together, the drum type's whole polyphony.
 * The simulator counts instructions and branch delays only: no multi-cycle multiplies, no cache or SDRAM waits.
 * Compare versions with it; it is not a device figure. Build and run: run.sh.
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission. */
#include "md_voice.h"
extern void sys_write(int fd, const char *buf, int len);
void ref_md_voice_on(md_voice_t *v, const md_kit_t *k, int pad, int reverse);
int ref_md_voice_render(md_voice_t *v, const md_kit_t *k, int16_t *out, const int32_t *inc, const int16_t *vel,
                        int16_t volume);
static void puts_(const char *s) { int n = 0; while (s[n]) n++; sys_write(1, s, n); }
static void putu(uint32_t v) { char b[12]; int i = 11; b[i] = 0; do { b[--i] = (char)('0' + v % 10); v /= 10; } while (v); puts_(b + i); }
static void puth(uint32_t v) { char b[9]; for (int i = 7; i >= 0; i--, v >>= 4) b[i] = "0123456789abcdef"[v & 15]; b[8] = 0; puts_(b); }
static inline uint32_t cyc(void) { uint32_t c; __asm__ volatile("%0 = CYCLES;" : "=d"(c)); return c; }

typedef void on_t(md_voice_t *, const md_kit_t *, int, int);
typedef int render_t(md_voice_t *, const md_kit_t *, int16_t *, const int32_t *, const int16_t *, int16_t);
static md_voice_t vs[12];
static int32_t inc[128]; static int16_t vel[128], out[128];

/* nv voices struck on pads 0.., rendered for nb blocks; returns the worst block of all nv voices together */
static uint32_t run(on_t *on, render_t *render, const md_kit_t *k, int nv, int rev, int nb, uint32_t *avg, uint32_t *hash)
{
    for (int v = 0; v < nv; v++) { uint8_t *p = (uint8_t *)&vs[v]; for (unsigned i = 0; i < sizeof vs[v]; i++) p[i] = 0; on(&vs[v], k, v, rev); }
    uint32_t worst = 0, total = 0, h = 2166136261u;
    for (int b = 0; b < nb; b++) {
        uint32_t d = 0;
        for (int v = 0; v < nv; v++) {
            uint32_t c0 = cyc();
            render(&vs[v], k, out, inc, vel, 8192);
            d += cyc() - c0;
            for (int i = 0; i < 128; i++) h = (h ^ (uint16_t)out[i]) * 16777619u;
        }
        total += d; if (d > worst) worst = d;
    }
    *avg = total / (uint32_t)nb; *hash = h;
    return worst;
}

static int fails;
static void cmp(const char *name, const md_kit_t *k, int nv, int rev, int step)
{
    for (int i = 0; i < 128; i++) { inc[i] = step << 17; vel[i] = 127 << 8; }
    uint32_t a0, h0, a1, h1;
    uint32_t w0 = run(ref_md_voice_on, ref_md_voice_render, k, nv, rev, 40, &a0, &h0);
    uint32_t w1 = run(md_voice_on, md_voice_render, k, nv, rev, 40, &a1, &h1);
    puts_(name); puts_(" pitch x"); putu((uint32_t)step * 100 / 2048); puts_("%: v0.2.2 worst "); putu(w0); puts_(" avg ");
    putu(a0); puts_(" | v0.2.3 worst "); putu(w1); puts_(" avg "); putu(a1); puts_(" | hash "); puth(h0);
    if (h0 != h1) { puts_(" != "); puth(h1); fails++; }
    puts_("\n");
}

int main(void)
{
    md_kit_t plain, heavy;
    md_kit_defaults(&plain);
    md_kit_defaults(&heavy);
    heavy.decay = 15; heavy.drive = 31; heavy.dusk = 31; heavy.age = 31;
    for (int p = 0; p < MD_PADS; p++) heavy.start[p] = 8;
    static const int steps[3] = { 1024, 2048, 4096 };
    for (int s = 0; s < 3; s++) cmp("1 voice, plain     ", &plain, 1, 0, steps[s]);
    for (int s = 0; s < 3; s++) cmp("1 voice, heaviest  ", &heavy, 1, 1, steps[s]);
    for (int s = 0; s < 3; s++) cmp("12 voices, plain   ", &plain, 12, 0, steps[s]);
    for (int s = 0; s < 3; s++) cmp("12 voices, heaviest", &heavy, 12, 1, steps[s]);
    puts_(fails ? "FAIL: the versions differ\n" : "OK: the same samples\n");
    return fails;
}
