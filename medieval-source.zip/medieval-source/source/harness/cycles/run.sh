#!/bin/sh
# The cycle bench: harness/cycles/run.sh V022_SOURCE_DIR TOOLCHAIN_BIN BFIN_SIM_RUN
#   V022_SOURCE_DIR  the v0.2.2 source folder (its md_voice.c is the reference)
#   TOOLCHAIN_BIN    the folder holding bfin-elf-gcc (GCC 13.3.0)
#   BFIN_SIM_RUN     GDB's sim/bfin/run (gdb source: configure --target=bfin-elf --disable-gdb; make all-sim)
set -e
REF=${1:?v0.2.2 source}; TC=${2:?toolchain bin}; RUN=${3:?bfin run}
HERE=$(cd "$(dirname "$0")" && pwd); SRC=$HERE/../..; OUT=$(mktemp -d)
GCC=$TC/bfin-elf-gcc
CF="-O2 -mcpu=bf524 -ffreestanding -fno-builtin -nostdlib -fno-common -Wall -I$SRC"
R=""; for n in md_voice_on md_voice_release md_voice_render md_kit_set md_kit_defaults md_decay_ms md_sound_ms; do
    R="$R -D$n=ref_$n"; done
$GCC $CF $R -I"$REF" -c "$REF/md_voice.c" -o $OUT/ref.o
$GCC $CF -c "$SRC/md_voice.c" -o $OUT/new.o
$GCC $CF -c "$HERE/bench.c" -o $OUT/bench.o
$GCC -mcpu=bf524 -c "$HERE/crt0.S" -o $OUT/crt0.o
$GCC -mcpu=bf524 -nostdlib -T "$HERE/link.ld" $OUT/crt0.o $OUT/bench.o $OUT/new.o $OUT/ref.o \
    "$($GCC -mcpu=bf524 -print-libgcc-file-name)" -o $OUT/bench.elf
"$RUN" --model bf524 --memory-size 32m --memory-region 0xff800000,0x8000 $OUT/bench.elf
rm -rf $OUT
