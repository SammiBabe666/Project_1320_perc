/* Host stand-ins for the firmware state md_fw.c and md_page.c read (OP1_HOST builds; harness/md_test.c defines
 * them): the 12 drum voice objects, their pads and velocities, the per-sample buffers, the pad table, the stock voice
 * functions (counted), and a small Json::Value with the same layout rules md_fw.c relies on (type byte at +8, int in
 * the first word, string pointer in the first word).
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission. */
#ifndef MD_HOST_H
#define MD_HOST_H
#include <stdint.h>

extern void *host_voice_obj[12];
extern int32_t host_voice_pad[12];
extern int16_t host_voice_vel12[12];
extern int32_t host_drum_slot, host_last_pad;
extern uint8_t host_shift;
extern int32_t host_buf_inc[128];
extern int16_t host_buf_vel[128];
extern int16_t host_pad_table[8][24 * 8];
extern int host_stock_calls[3], host_patch_changed;

#define VOICE_OBJ  ((void *const *)host_voice_obj)
#define VOICE_PAD  ((const int32_t *)host_voice_pad)
#define VOICE_VEL  ((const int16_t *)host_voice_vel12)
#define DRUM_SLOT  host_drum_slot
#define BUF_INC    ((const int32_t *)host_buf_inc)
#define BUF_VEL    ((const int16_t *)host_buf_vel)
#define LAST_PAD   host_last_pad
#define SHIFT_HELD host_shift
#define PAD_TABLE(s) (host_pad_table[(s) & 7])

void host_stock_render(void *, int16_t *, const void *);
void host_stock_note_on(void *, const void *);
void host_stock_note_off(void *, const void *);
#define STOCK_RENDER(a, b, c)  host_stock_render((a), (b), (c))
#define STOCK_NOTE_ON(a, b)    host_stock_note_on((a), (b))
#define STOCK_NOTE_OFF(a, b)   host_stock_note_off((a), (b))

typedef struct jv { union { int32_t i; char *s; struct jnode *node; } u; uint8_t type, pad[7]; } jv;
void *jv_key(void *v, const char *k);
void *jv_idx(void *v, unsigned i);
void *jv_assign(void *dst, const void *src);
unsigned jv_size(const void *v);
void jv_dtor(void *v, int how);
void *jv_from_int(void *v, int x);
extern jv host_patch_json[8];
#define JV_KEY      jv_key
#define JV_IDX      jv_idx
#define JV_ASSIGN   jv_assign
#define JV_SIZE     jv_size
#define JV_DTOR     jv_dtor
#define JV_FROM_INT jv_from_int
#undef  OP1_DRUM_PATCH_JSON
#define OP1_DRUM_PATCH_JSON(s) ((void *)&host_patch_json[(s) & 7])
#define DRUM_TO_PATCH(p)  ((void)(p), host_patch_changed++)
#define DRUM_PATCH(s)     ((void *)(intptr_t)(s))
#endif
