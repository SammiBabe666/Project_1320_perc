#!/usr/bin/env python3
"""Previews of the medieval drum pages from the real page code (md_page.c, host build with md_test.c's stand-ins):
a grid of page states (PNG) and an animation of T1 being played (GIF).

    python3 harness/md_preview.py HUNDEKRAFT_SDK/synth_sdk OP1R_SRC/synth_sdk out_dir

Text is drawn with a stand-in font (the OP-1's own font is firmware content and not used here): positions and
strings are the page's, the letter shapes are not.
Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import json, os, subprocess, sys
import cairo
from PIL import Image

hk, op1r, out = sys.argv[1:4]
HERE = os.path.dirname(os.path.abspath(__file__))
PLUG = os.path.dirname(HERE)
exe = os.path.join(out, 'md_test_preview')
os.makedirs(out, exist_ok=True)
subprocess.run(['cc', '-O1', '-Wall', '-DOP1_HOST', '-I', PLUG, '-I', HERE, '-I', hk, '-I', op1r,
                os.path.join(HERE, 'md_test.c'), *(os.path.join(PLUG, s) for s in ('md_fw.c', 'md_voice.c', 'md_page.c')),
                '-lm', '-o', exe], check=True)


def frames(page, count, hits, decay=31, drive=0, dusk=0, age=0, every=0, turn=None):
    env = dict(os.environ, **({'MD_TURN': turn} if turn else {}))
    r = subprocess.run([exe, 'frame', str(page), str(count), hits, str(decay), str(drive), str(dusk), str(age), str(every)],
                       check=True, capture_output=True, text=True, env=env)
    return [json.loads(l) for l in r.stdout.splitlines()]


def draw(c, fr, S):
    c.set_source_rgb(0, 0, 0); c.paint()
    c.save(); c.scale(S, S); c.set_line_cap(cairo.LINE_CAP_ROUND)
    for x0, y0, x1, y1, w, col in fr['lines']:
        c.set_source_rgb(*(v / 255 for v in col)); c.set_line_width(w / 1024)
        c.move_to(x0 / 1024, y0 / 1024); c.line_to(x1 / 1024, y1 / 1024); c.stroke()
    c.select_font_face('DejaVu Sans', cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL); c.set_font_size(9)
    for t in fr['text']:
        c.set_source_rgb(*(v / 255 for v in t['c'])); c.move_to(t['x'] / 1024, t['y'] + 8); c.show_text(t['s'])
    c.restore()


STATES = [
    ('T1 play: idle, the scene sways', 0, 40, '', {}),
    ('T1: pads 1, 3, 5 struck; white turned: the decay on a scroll', 0, 14, '0:0,4:2,8:4', {'decay': 20, 'turn': '2:-1024'}),
    ('T1: pads 14, 20; green turned: the new sound on a scroll', 0, 16, '0:13,6:19', {'turn': '1:2048'}),
    ('T1: drive full: rings flare, red sparks; blue pressed', 0, 14, '0:0,5:15,9:8', {'drive': 31, 'turn': 'p:0'}),
    ('T2 kit: dusk up, a moon rises; blue turned: the kit', 1, 20, '0:9', {'dusk': 28, 'decay': 12, 'turn': '0:2048'}),
    ('T2: age up, dust drifts; short decay', 1, 20, '0:2,8:16', {'age': 31, 'decay': 4}),
]
S, PAD, CAP = 2, 16, 26
W, H = 320 * S, 160 * S
surf = cairo.ImageSurface(cairo.FORMAT_RGB24, 2 * (W + PAD) + PAD, 3 * (H + PAD + CAP) + PAD)
c = cairo.Context(surf); c.set_source_rgb(0.22, 0.22, 0.24); c.paint()
for n, (cap, page, count, hits, kw) in enumerate(STATES):
    fr = frames(page, count, hits, **kw)[-1]
    x0, y0 = PAD + (n % 2) * (W + PAD), PAD + (n // 2) * (H + PAD + CAP)
    c.save(); c.set_source_rgb(1, 1, 1); c.set_font_size(13); c.move_to(x0, y0 + 16); c.show_text(cap); c.restore()
    c.save(); c.translate(x0, y0 + CAP); c.rectangle(0, 0, W, H); c.clip(); draw(c, fr, S); c.restore()
grid = os.path.join(out, 'medieval_drum_pages.png')
surf.write_to_png(grid)
print('->', grid)

# animation: 4 s of T1 at 25 fps with a little rhythm on the pads
beat = ','.join(f'{f}:{p}' for f, p in [(0, 0), (6, 2), (12, 0), (18, 13), (25, 0), (31, 4), (37, 19), (43, 8),
                                       (50, 0), (56, 2), (62, 14), (68, 0), (75, 6), (81, 20), (87, 0), (93, 22)])
imgs = []
for fr in frames(0, 100, beat, decay=24, drive=8, every=1):
    s = cairo.ImageSurface(cairo.FORMAT_RGB24, 640, 320)
    draw(cairo.Context(s), fr, 2)
    imgs.append(Image.frombuffer('RGBA', (640, 320), bytes(s.get_data()), 'raw', 'BGRA', 0, 1).convert('RGB')
                .quantize(colors=16, method=Image.Quantize.MEDIANCUT))
gif = os.path.join(out, 'medieval_drum_screen.gif')
imgs[0].save(gif, save_all=True, append_images=imgs[1:], duration=40, loop=0, optimize=True)
print('->', gif, len(imgs), 'frames')
