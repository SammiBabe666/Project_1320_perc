#!/bin/sh
# v0.2.3's md_voice.c against v0.2.2's, sample by sample: harness/match.sh V022_SOURCE_DIR (the v0.2.2 source folder)
set -e
cd "$(dirname "$0")/.."
REF=${1:?v0.2.2 source folder}; OUT=${TMPDIR:-/tmp}/md_match
F="-O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all -Wall -Wextra -I."
R=""; for n in md_voice_on md_voice_release md_voice_render md_kit_set md_kit_defaults md_decay_ms md_sound_ms; do
    R="$R -D$n=ref_$n"; done
cc $F $R -I"$REF" -c "$REF/md_voice.c" -o "$OUT.ref.o"
cc $F -c md_voice.c -o "$OUT.new.o"
cc $F -c harness/md_match.c -o "$OUT.main.o"
cc -fsanitize=address,undefined "$OUT.main.o" "$OUT.new.o" "$OUT.ref.o" -o "$OUT"
"$OUT"
