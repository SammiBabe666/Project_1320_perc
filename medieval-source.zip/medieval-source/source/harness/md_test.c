/* medieval drum type on the host: the real md_fw.c / md_voice.c / md_page.c against stand-ins for the firmware
 * (md_host.h). Checks the drum hooks (medieval and stock kits, voice states, gate / one-shot, retrigger), every sound
 * of the bank on its pad with the extreme settings, saving and loading the kit, and the page edits.
 *   ./md_test            run the checks
 *   ./md_test frame ...  print page frames as JSON lines for preview.py (see md_preview.py)
 *   ./md_test demo ...   play an event script: audio and page frames for md_demo.py
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission. */
#include "op1_feature_drum.h"
#include "md_fw.h"
#include "md_host.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern const op1_feature_t FEATURE_medieval;
void md_scene(void *r, const md_kit_t *k, const int16_t *padw, int dt);
int md_turn_field(int page, int knob, int shift);
int md_turn(md_kit_t *k, int field, int pad, int steps);
void md_label(const md_kit_t *k, const int16_t *padw, int page, int pad, int knob, char *out);

/* ---- firmware stand-ins ---- */
int16_t host_sine[8192]; int32_t host_pitch_inc[128]; uint8_t host_voice_mem[6 * 0x24]; int16_t host_voice_vel[6];
int16_t host_voice_env[128]; int16_t host_accel[3]; int16_t host_knobs[8][8]; int host_slot;
const uint8_t *host_sample_buffer[8]; int16_t host_fx_knobs[3][8]; int16_t host_fx_meter[3]; void *host_fx_scratch[3];

static uint8_t voice_mem[12][0x14];                           /* stock voice object: vtable, data, pos, state, blocks */
void *host_voice_obj[12]; int32_t host_voice_pad[12]; int16_t host_voice_vel12[12];
int32_t host_drum_slot, host_last_pad; uint8_t host_shift;
int32_t host_buf_inc[128]; int16_t host_buf_vel[128];
int16_t host_pad_table[8][24 * 8];
int host_stock_calls[3], host_patch_changed;
void host_stock_render(void *s, int16_t *o, const void *p) { (void)s; (void)p; memset(o, 0, 256); host_stock_calls[0]++; }
void host_stock_note_on(void *s, const void *p) { (void)s; (void)p; host_stock_calls[1]++; }
void host_stock_note_off(void *s, const void *p) { (void)s; (void)p; host_stock_calls[2]++; }

/* a small Json::Value: 16 bytes, type at +8 (as the firmware's); objects and arrays keep their members in a node */
typedef struct jnode { int n; const char *key[32]; jv val[32]; } jnode;
jv host_patch_json[8];
enum { J_NULL = 0, J_INT = 1, J_STRING = 4, J_ARRAY = 6, J_OBJECT = 7 };
static jnode *node(jv *v, int type)
{
    if (v->type == J_NULL) { v->type = (uint8_t)type; v->u.node = calloc(1, sizeof(jnode)); }
    assert(v->type == type);
    return v->u.node;
}
void *jv_key(void *pv, const char *k)
{
    jnode *n = node(pv, J_OBJECT);
    for (int i = 0; i < n->n; i++) if (!strcmp(n->key[i], k)) return &n->val[i];
    assert(n->n < 32);
    n->key[n->n] = strdup(k); memset(&n->val[n->n], 0, sizeof(jv));
    return &n->val[n->n++];
}
void *jv_idx(void *pv, unsigned i)
{
    jnode *n = node(pv, J_ARRAY);
    assert(i < 32);
    while ((unsigned)n->n <= i) memset(&n->val[n->n++], 0, sizeof(jv));
    return &n->val[i];
}
void *jv_assign(void *d, const void *s) { assert(((const jv *)s)->type == J_INT); memcpy(d, s, sizeof(jv)); return d; }
unsigned jv_size(const void *v) { const jv *j = v; return j->type == J_ARRAY || j->type == J_OBJECT ? (unsigned)j->u.node->n : 0; }
void jv_dtor(void *v, int how) { (void)v; (void)how; }
void *jv_from_int(void *v, int x) { jv *j = v; memset(j, 0, sizeof *j); j->type = J_INT; j->u.i = x; return v; }
static void jv_set_str(jv *j, const char *s) { memset(j, 0, sizeof *j); j->type = J_STRING; j->u.s = strdup(s); }

/* raster and text: recorded for the preview */
typedef struct { int32_t x0, y0, x1, y1, w; uint8_t c[4]; } line_t;
static line_t lines[8192]; static int nlines;
typedef struct { int32_t x, y, size; uint8_t c[4]; char s[40]; } text_t;
static text_t *drawn[16]; static int ntext;
void *host_raster(void) { return (void *)1; }
void host_raster_line(void *r, const void *p0, const void *p1, int32_t w, const uint8_t *c)
{
    (void)r; const op1_pt *a = p0, *b = p1;
    if (nlines < 8192) { line_t *l = &lines[nlines++]; l->x0 = a->x; l->y0 = a->y; l->x1 = b->x; l->y1 = b->y; l->w = w; memcpy(l->c, c, 4); }
}
void *host_text_ctor(void *o, int32_t x, int32_t y, int32_t sz, const uint8_t *c)
{ text_t *t = o; t->x = x; t->y = y; t->size = sz; memcpy(t->c, c, 4); t->s[0] = 0; return o; }
void host_text_set(void *o, const char *s) { snprintf(((text_t *)o)->s, 40, "%s", s); }
void host_text_draw(void *o, void *r, const int32_t *m) { (void)r; (void)m; if (ntext < 16) drawn[ntext++] = o; }
void *host_find_node(void *s, const char *id) { (void)s; (void)id; return 0; }
void host_node_set_transform(void *n, const int32_t *m) { (void)n; (void)m; }
void host_node_set_visible(void *n, int on) { (void)n; (void)on; }
uint8_t *host_node_style_rgba(void *s, const char *id) { (void)s; (void)id; return 0; }
void host_screen_draw(void *s, int dt) { (void)s; (void)dt; }
void host_raster_dim(void *r) { (void)r; }

/* ---- helpers ---- */
static const struct op1_drum_type *T;
static int32_t *vstate(int v) { return (int32_t *)(voice_mem[v] + 12); }
static op1_drum_pad padw(int slot, int p) { op1_drum_pad d; memcpy(&d, host_pad_table[slot] + p * 8, 16); return d; }
static void set_pad_words(int slot, int16_t pitch_word, int16_t playmode, int16_t reverse, int16_t volume)
{
    for (int p = 0; p < 24; p++) {
        int16_t *w = host_pad_table[slot] + p * 8;
        w[0] = pitch_word; w[3] = playmode; w[4] = reverse; w[7] = volume;
    }
}
static void hit(int v, int slot, int pad, int vel, int step2048)
{
    host_drum_slot = slot; host_voice_pad[v] = pad; host_voice_vel12[v] = (int16_t)(vel << 8);
    for (int i = 0; i < 128; i++) { host_buf_inc[i] = step2048 << 17; host_buf_vel[i] = (int16_t)(vel << 8); }
    op1_drum_pad d = padw(slot, pad);
    T->note_on(host_voice_obj[v], &d);
}
static void render(int v, int slot, int pad, int16_t *out)
{
    op1_drum_pad d = padw(slot, pad);
    T->render(host_voice_obj[v], out, &d);
}
static void make_medieval(int slot)
{
    memset(&host_patch_json[slot], 0, sizeof(jv));
    jv_set_str(jv_key(jv_key(&host_patch_json[slot], OP1_DRUM_KEY), "engine"), "medieval");
    T->load(slot, jv_key(&host_patch_json[slot], OP1_DRUM_KEY));
}

static int fails;
#define CHECK(c, ...) do { if (!(c)) { fails++; printf("FAIL %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

static void init(void)
{
    for (int i = 0; i < 8192; i++) host_sine[i] = (int16_t)lrint(32767.0 * sin(2 * M_PI * i / 8192.0));
    for (int v = 0; v < 12; v++) host_voice_obj[v] = voice_mem[v];
    for (int s = 0; s < 8; s++) set_pad_words(s, 0, 8192, 8192, 8192);
    T = FEATURE_medieval.drum;
}

/* one hit played out: blocks until the voice turns off (-1: never), the largest step between samples of the first
 * block's first 4 samples and the hit's peak */
static int play_out(int v, int slot, int pad, int vel, int step, int *peak, int *first_step, int max_blocks)
{
    int16_t out[128]; int pk = 0, fs = 0, prev = 0;
    hit(v, slot, pad, vel, step);
    for (int b = 0; b < max_blocks; b++) {
        render(v, slot, pad, out);
        for (int i = 0; i < 128; i++) {
            if (abs(out[i]) > pk) pk = abs(out[i]);
            if (b == 0 && i < 4 && abs(out[i] - prev) > fs) fs = abs(out[i] - prev);
            prev = out[i];
        }
        if (*vstate(v) == 0) { if (peak) *peak = pk; if (first_step) *first_step = fs; return b + 1; }
    }
    if (peak) *peak = pk;
    return -1;
}

static void test_hooks(void)
{
    int16_t out[128];
    /* a stock kit: every call goes to the stock functions */
    memset(host_stock_calls, 0, sizeof host_stock_calls);
    T->load(0, 0);
    hit(0, 0, 3, 100, 2048); render(0, 0, 3, out);
    op1_drum_pad d = padw(0, 3); T->note_off(host_voice_obj[0], &d);
    CHECK(host_stock_calls[0] == 1 && host_stock_calls[1] == 1 && host_stock_calls[2] == 1, "stock kit not passed on");
    /* a drum+ kit while medieval is the type: stock too, marked foreign for the page */
    memset(&host_patch_json[1], 0, sizeof(jv));
    jv_set_str(jv_key(jv_key(&host_patch_json[1], OP1_DRUM_KEY), "engine"), "drum+");
    T->load(1, jv_key(&host_patch_json[1], OP1_DRUM_KEY));
    CHECK(!md_slot[1].on && md_foreign[1], "drum+ kit taken as medieval");
    /* a medieval kit: never the stock functions */
    make_medieval(2);
    CHECK(md_slot[2].on && md_slot[2].decay == MD_STEPS - 1 && md_slot[2].snd[5] == 5, "defaults");
    memset(host_stock_calls, 0, sizeof host_stock_calls);
    int n = play_out(1, 2, 0, 127, 2048, 0, 0, 2000);
    CHECK(n > 0 && !host_stock_calls[0] && !host_stock_calls[1], "medieval hit: %d blocks, stock %d %d", n,
          host_stock_calls[0], host_stock_calls[1]);
    /* after the end the voice stays medieval and silent (never the stock render on its old position) */
    render(1, 2, 0, out);
    int sum = 0; for (int i = 0; i < 128; i++) sum += abs(out[i]);
    CHECK(!sum && !host_stock_calls[0], "voice after its end: sum %d, stock %d", sum, host_stock_calls[0]);
    /* a voice struck on a stock kit after a medieval hit goes back to stock */
    hit(1, 0, 0, 127, 2048);
    CHECK(host_stock_calls[1] == 1, "voice back to stock");
}

/* v0.2.3: a medieval voice taken by a stock kit mid-sound, then struck on a medieval kit again, starts clean: no fade
 * of the stale sample the medieval sound had reached before the stock hit (v0.2.2 faded it out: a click) */
static void test_steal_back(void)
{
    int16_t out[128];
    /* slot 2: the medieval kit test_hooks made; slot 0: its stock kit */
    hit(4, 2, 0, 127, 2048);
    for (int b = 0; b < 3; b++) render(4, 2, 0, out);        /* the medieval sound is loud now */
    hit(4, 0, 0, 127, 2048); render(4, 0, 0, out);           /* a stock hit takes the voice */
    set_pad_words(2, 6, 8192, 8192, 8192);
    md_slot[2].start[6] = 0;
    hit(4, 2, 6, 127, 2048); render(4, 2, 6, out);           /* back to medieval, on a pad whose sound starts silent */
    int first = abs(out[0]);
    CHECK(first < 800, "medieval hit after a stock steal starts with %d (a stale fade)", first);
}

static void test_gate_shot(void)
{
    int16_t out[128];
    make_medieval(3);
    set_pad_words(3, 0, 4096, 8192, 8192);                    /* gate */
    hit(2, 3, 0, 127, 2048); render(2, 3, 0, out); render(2, 3, 0, out);
    int last = out[127];
    op1_drum_pad d = padw(3, 0); T->note_off(host_voice_obj[2], &d);
    CHECK(*vstate(2) == 2, "gate note-off: state %d", *vstate(2));
    render(2, 3, 0, out);
    int st = abs(out[0] - last), tail = 0;
    for (int i = 64; i < 128; i++) tail += abs(out[i]);
    CHECK(*vstate(2) == 0 && !tail && st < 2500, "gate fade: state %d, tail %d, step %d", *vstate(2), tail, st);
    set_pad_words(3, 0, 8192, 8192, 8192);                    /* one-shot */
    hit(3, 3, 0, 127, 2048); render(3, 3, 0, out);
    d = padw(3, 0); T->note_off(host_voice_obj[3], &d);
    render(3, 3, 0, out);
    int e = 0; for (int i = 0; i < 128; i++) e += abs(out[i]);
    CHECK(*vstate(3) == 2 && e > 1000, "one-shot plays on after note-off: state %d, level %d", *vstate(3), e);
}

static void test_retrigger(void)
{
    int16_t out[128]; int worst = 0;
    make_medieval(4);
    for (int p = 0; p < 24; p++) {
        hit(4, 4, p, 127, 2048);
        for (int b = 0; b < 3; b++) render(4, 4, p, out);
        int last = out[127];
        hit(4, 4, (p + 7) % 24, 127, 2048);
        render(4, 4, (p + 7) % 24, out);
        int st = abs(out[0] - last);
        if (st > worst) worst = st;
    }
    CHECK(worst < 3000, "retrigger step %d", worst);
    printf("retrigger: largest step at a retrigger %d (of 32767)\n", worst);
}

static void test_all_sounds(void)
{
    /* every sound on pad 0 with extreme settings, pitch from 1/4 to 4 times, forward and reverse */
    static const uint8_t decays[] = { 0, 15, 31 }, drives[] = { 0, 31 }, dusks[] = { 0, 31 }, ages[] = { 0, 31 },
                         starts[] = { 0, 31 };
    static const int steps[] = { 512, 2048, 8192 };
    int runs = 0, worst_first = 0, loudest = 0, never = 0;
    make_medieval(5);
    for (int s = 0; s < MD_NSOUNDS; s++)
        for (unsigned a = 0; a < 3; a++) for (unsigned b = 0; b < 2; b++) for (unsigned c = 0; c < 2; c++)
        for (unsigned e = 0; e < 2; e++) for (unsigned f = 0; f < 2; f++) for (unsigned g = 0; g < 3; g++)
        for (int rev = 0; rev < 2; rev++) {
            md_kit_t *k = &md_slot[5];
            k->snd[0] = (uint8_t)s; k->decay = decays[a]; k->drive = drives[b]; k->dusk = dusks[c]; k->age = ages[e];
            k->start[0] = starts[f];
            set_pad_words(5, 0, 8192, rev ? 16384 : 8192, 8192);
            int pk = 0, fs = 0;
            int n = play_out(5, 5, 0, 127, steps[g], &pk, &fs, 4000);
            runs++;
            if (n < 0) never++;
            if (fs > worst_first) { worst_first = fs; if (getenv("MD_WHY")) printf("first step %d: sound %d decay %d drive %d dusk %d age %d start %d step %d rev %d\n", fs, s, decays[a], drives[b], dusks[c], ages[e], starts[f], steps[g], rev); }
            if (pk > loudest) loudest = pk;
        }
    CHECK(!never, "%d hits never ended", never);
    CHECK(worst_first < 4000, "first-samples step %d", worst_first);
    printf("all sounds: %d hits, all ended; largest step in a hit's first 4 samples %d; loudest peak %d\n", runs,
           worst_first, loudest);
}

static void test_levels(void)
{
    make_medieval(6);
    int pk127 = 0, pk64 = 0, pkv = 0;
    set_pad_words(6, 0, 8192, 8192, 8192);
    play_out(6, 6, 0, 127, 2048, &pk127, 0, 4000);
    play_out(6, 6, 0, 64, 2048, &pk64, 0, 4000);
    set_pad_words(6, 0, 8192, 8192, 4096);
    play_out(6, 6, 0, 127, 2048, &pkv, 0, 4000);
    printf("levels (pad 1, battle kik): velocity 127 peak %d, velocity 64 peak %d, half volume peak %d\n", pk127, pk64, pkv);
    CHECK(pk127 > 10000 && pk127 < 32767, "full hit level %d", pk127);
    CHECK(pk64 < pk127 / 2 && pkv < pk127 / 2, "velocity / volume law");
    /* pitch: a hit at 2x the increment ends in about half the blocks */
    int n1 = play_out(6, 6, 0, 127, 2048, 0, 0, 4000), n2 = play_out(6, 6, 0, 127, 4096, 0, 0, 4000);
    CHECK(abs(2 * n2 - n1) <= 2, "pitch: %d blocks at 1x, %d at 2x", n1, n2);
}

static void test_save_load(void)
{
    make_medieval(7);
    md_check_slot(7);
    md_kit_t *k = &md_slot[7];
    host_last_pad = 9; host_shift = 0;
    T->page_turn(0, 7, 1, 2048 * 3);                          /* T1 green: sound +3 */
    T->page_turn(0, 7, 2, -1024 * 10);                        /* T1 white: decay -10 */
    T->page_turn(0, 7, 3, 1024 * 7);                          /* T1 orange: drive +7 */
    T->page_turn(1, 7, 1, 1024 * 5);                          /* T2 green: start +5 */
    T->page_turn(1, 7, 2, 1024 * 4);                          /* T2 white: dusk +4 */
    T->page_turn(1, 7, 3, 1024 * 2);                          /* T2 orange: age +2 */
    CHECK(k->snd[9] == 12 && k->decay == 21 && k->drive == 7 && k->start[9] == 5 && k->dusk == 4 && k->age == 2,
          "page edits: snd %d decay %d drive %d start %d dusk %d age %d", k->snd[9], k->decay, k->drive, k->start[9],
          k->dusk, k->age);
    CHECK(T->page_turn(0, 7, 0, 1024) == 0, "T1 blue (pitch) must go to the stock controller");
    host_shift = 1;
    CHECK(T->page_turn(0, 7, 3, 1024) == 0, "Shift + T1 orange (volume) must go to the stock controller");
    CHECK(T->page_turn(0, 7, 1, 1024) == 1, "Shift + other knobs: consumed");
    host_shift = 0;
    md_kit_t before = *k;
    memset(k, 0, sizeof *k);
    T->load(7, jv_key(&host_patch_json[7], OP1_DRUM_KEY));
    CHECK(!memcmp(&before, k, sizeof before), "kit after save and load differs");
    T->page_turn(1, 7, 0, 2048 * 2);                          /* T2 blue: kit III */
    CHECK(k->kit == 2 && k->snd[0] == 48 && k->start[9] == 0, "kit change: kit %d snd0 %d", k->kit, k->snd[0]);
    /* presses: T1 blue reverse, T1 green one-shot <-> gate */
    int16_t *w = host_pad_table[7] + 9 * 8;
    w[3] = 8192; w[4] = 8192;
    T->page_press(0, 7, 0); T->page_press(0, 7, 1);
    CHECK(w[4] == 16384 && w[3] == 4096, "presses: reverse %d playmode %d", w[4], w[3]);
    char lab[40];
    md_label(k, w, 0, 9, 2, lab); CHECK(!strcmp(lab, "decay 1.0s"), "label '%s'", lab);
    md_label(k, w, 1, 9, 0, lab); CHECK(!strcmp(lab, "kit iii"), "label '%s'", lab);
}

/* ---- preview frames ---- */
static void frame_json(const char *name)
{
    printf("{\"name\": \"%s\", \"lines\": [", name);
    for (int i = 0; i < nlines; i++)
        printf("%s[%d,%d,%d,%d,%d,[%d,%d,%d]]", i ? "," : "", lines[i].x0, lines[i].y0, lines[i].x1, lines[i].y1,
               lines[i].w, lines[i].c[0], lines[i].c[1], lines[i].c[2]);
    printf("], \"text\": [");
    for (int i = 0; i < ntext; i++)
        printf("%s{\"x\": %d, \"y\": %d, \"c\": [%d,%d,%d], \"s\": \"%s\"}", i ? "," : "", drawn[i]->x, drawn[i]->y,
               drawn[i]->c[0], drawn[i]->c[1], drawn[i]->c[2], drawn[i]->s);
    printf("]}\n");
}

/* frames: every 40 ms for `count` frames, hits on the pads given as "frame:pad,..." */
static void frames(int page, int count, const char *hits, int decay, int drive, int dusk, int age, int every)
{
    make_medieval(0);
    md_kit_t *k = &md_slot[0];
    k->decay = (uint8_t)decay; k->drive = (uint8_t)drive; k->dusk = (uint8_t)dusk; k->age = (uint8_t)age;
    host_drum_slot = 0;
    T->page_init();
    for (int f = 0; f < count; f++) {
        for (const char *p = hits; *p; ) {
            int hf = (int)strtol(p, (char **)&p, 10), pad = 0;
            if (*p == ':') pad = (int)strtol(p + 1, (char **)&p, 10);
            if (*p == ',') p++;
            if (hf == f) { int16_t out[128]; hit(0, 0, pad, 110, 2048); render(0, 0, pad, out); host_last_pad = pad; }
        }
        if (getenv("MD_TURN") && f == count - 10) {             /* "knob:delta" or "p:knob" (a press) */
            const char *t = getenv("MD_TURN");
            if (t[0] == 'p') T->page_press(page, 0, atoi(t + 2));
            else T->page_turn(page, 0, atoi(t), atoi(strchr(t, ':') + 1));
        }
        md_samples += 1764;                                   /* 40 ms */
        nlines = 0; ntext = 0;
        T->page_draw(page, 0, (void *)1);
        if (every && f % every == 0) { char n[16]; snprintf(n, 16, "%d", f); frame_json(n); }
    }
    if (!every) frame_json(page ? "t2" : "t1");
}

/* demo SCRIPT AUDIO: an event script (md_demo.py) played through the drum hooks on 12 voices, as the core would: the
 * mix as raw s32 to AUDIO, and a page frame as a JSON line every 1764 samples (25 fps) on stdout. Script lines:
 *   SAMPLE hit PAD VEL | off PAD | turn KNOB DELTA | press KNOB | page P | sel PAD | pitch PAD SEMITONES | end
 * A pad that is still sounding is restruck on its own voice, else a free voice, else the oldest. Pitch is the stock
 * pad word (T1 blue), played as the increment 2048 * 2^(semitones / 12). */
static void demo(const char *script, const char *audio)
{
    FILE *in = fopen(script, "r"), *au = fopen(audio, "wb");
    if (!in || !au) { perror("demo"); exit(2); }
    int vpad[12], vstep[12], vvel[12], page = 0, have = 0, a = 0, b = 0, frame = 0;
    uint32_t von[12], frame_s = 0;
    long et = 0;
    char line[128], cmd[16];
    for (int v = 0; v < 12; v++) { vpad[v] = -1; vstep[v] = 2048; vvel[v] = 0; von[v] = 0; }
    make_medieval(0);
    host_drum_slot = 0; host_last_pad = 0;
    T->page_init();
    for (uint32_t s = 0, end = 0; !end; s += 128) {
        while (!end) {                                        /* the events due by this block */
            if (!have) {
                if (!fgets(line, sizeof line, in)) break;
                a = b = 0;
                if (sscanf(line, "%ld %15s %d %d", &et, cmd, &a, &b) < 2) continue;
                have = 1;
            }
            if (et > (long)s) break;
            have = 0;
            if (!strcmp(cmd, "hit") && (unsigned)a < 24) {
                int v = -1;
                for (int i = 0; i < 12 && v < 0; i++) if (vpad[i] == a && *vstate(i)) v = i;
                for (int i = 0; i < 12 && v < 0; i++) if (!*vstate(i)) v = i;
                if (v < 0) { v = 0; for (int i = 1; i < 12; i++) if (von[i] < von[v]) v = i; }
                int semis = host_pad_table[0][a * 8] >> 9;
                semis = semis < -24 ? -24 : semis > 23 ? 23 : semis;  /* (4 times at most: the << 17 fits) */
                vstep[v] = (int)lrint(2048.0 * pow(2.0, semis / 12.0)); vvel[v] = b; vpad[v] = a; von[v] = s;
                hit(v, 0, a, b, vstep[v]);
                host_last_pad = a;
            } else if (!strcmp(cmd, "off")) {
                for (int i = 0; i < 12; i++)
                    if (vpad[i] == a && *vstate(i)) { op1_drum_pad d = padw(0, a); T->note_off(host_voice_obj[i], &d); }
            } else if (!strcmp(cmd, "turn")) T->page_turn(page, 0, a, b);
            else if (!strcmp(cmd, "press")) T->page_press(page, 0, a);
            else if (!strcmp(cmd, "page")) page = a & 1;
            else if (!strcmp(cmd, "sel") && (unsigned)a < 24) host_last_pad = a;
            else if (!strcmp(cmd, "pitch") && (unsigned)a < 24) {
                host_last_pad = a;
                host_pad_table[0][a * 8] = (int16_t)(b << 9);
                if (page == 0) T->page_turn(0, 0, 0, 1);         /* (the stock controller's knob: shows the scroll) */
            } else if (!strcmp(cmd, "end")) end = 1;
        }
        int32_t mix[128] = { 0 };
        int16_t out[128];
        for (int v = 0; v < 12; v++) {
            if (vpad[v] < 0 || !*vstate(v)) continue;
            host_voice_pad[v] = vpad[v];
            for (int i = 0; i < 128; i++) {
                host_buf_inc[i] = vstep[v] << 17;
                host_buf_vel[i] = (int16_t)(vvel[v] << 8);
            }
            render(v, 0, vpad[v], out);
            for (int i = 0; i < 128; i++) mix[i] += out[i];
        }
        fwrite(mix, 4, 128, au);
        for (; frame_s < s + 128; frame_s += 1764) {
            md_samples = frame_s;
            nlines = 0; ntext = 0;
            T->page_draw(page, 0, (void *)1);
            char n[16]; snprintf(n, 16, "%d", frame++); frame_json(n);
        }
    }
    fclose(in); fclose(au);
}

int main(int argc, char **argv)
{
    init();
    if (argc > 2 && !strcmp(argv[1], "render")) {             /* render SND: one clean hit as raw s16 on stdout */
        make_medieval(0);
        md_slot[0].snd[0] = (uint8_t)atoi(argv[2]);
        int16_t out[128];
        hit(0, 0, 0, 127, 2048);
        for (int b = 0; b < 4000; b++) {
            render(0, 0, 0, out);
            fwrite(out, 2, 128, stdout);
            if (*vstate(0) == 0) break;
        }
        return 0;
    }
    if (argc > 3 && !strcmp(argv[1], "demo")) { demo(argv[2], argv[3]); return 0; }   /* demo SCRIPT AUDIO */
    if (argc > 1 && !strcmp(argv[1], "frame")) {               /* frame page count hits decay drive dusk age every */
        if (argc < 10) return 2;
        frames(atoi(argv[2]), atoi(argv[3]), argv[4], atoi(argv[5]), atoi(argv[6]), atoi(argv[7]), atoi(argv[8]),
               atoi(argv[9]));
        return 0;
    }
    test_hooks();
    test_gate_shot();
    test_steal_back();
    test_retrigger();
    test_levels();
    test_save_load();
    test_all_sounds();
    nlines = 0; ntext = 0;
    frames(0, 40, "2:0,10:14,20:7,30:20", 31, 0, 0, 0, 0);
    printf("page: %d lines and %d texts in a frame with rings and notes\n", nlines, ntext);
    printf(fails ? "FAILED: %d\n" : "OK: all drum type checks passed\n", fails);
    return fails != 0;
}
