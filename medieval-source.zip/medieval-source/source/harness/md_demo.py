#!/usr/bin/env python3
"""A demo video of the medieval drum engine: a one-minute performance played through the real drum hooks, voices and
pages (md_test.c's demo mode: a host build of md_fw.c, md_voice.c and md_page.c with the bank built in), rendered as an
MP4 with the sound and the animated screen, and the same sound as a WAV.

    python3 harness/md_demo.py HUNDEKRAFT_SDK/synth_sdk OP1R_SRC/synth_sdk out_dir

The sound is the engine's own output, dry: the OP-1's FX and master section are not part of the plugin. The whole mix
gets one gain so that its loudest moment peaks at -1 dBFS. The script stands in for the core: it strikes the pads,
turns the knobs, picks the voice for each hit and turns the stock pad pitch into the playback speed.
Under the screen: the caption, the 24 keys (lit as they are struck) and the four knobs (lit as they are turned).
Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import json, math, os, subprocess, sys, wave
import cairo
import numpy as np

hk, op1r, out = sys.argv[1:4]
HERE = os.path.dirname(os.path.abspath(__file__))
PLUG = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(PLUG, 'tools'))
from gen_font import G, parse, advance                       # the pages' textura letters, for the captions

os.makedirs(out, exist_ok=True)
exe = os.path.join(out, 'md_test_demo')
subprocess.run(['cc', '-O2', '-Wall', '-DOP1_HOST', '-I', PLUG, '-I', HERE, '-I', hk, '-I', op1r,
                os.path.join(HERE, 'md_test.c'), *(os.path.join(PLUG, s) for s in ('md_fw.c', 'md_voice.c', 'md_page.c')),
                '-lm', '-o', exe], check=True)

RATE, FPS = 44100, 25
FRAME = RATE // FPS                                          # 1764 samples, as md_test.c draws them
STEP = 52 * 128                                              # a 16th: 52 render blocks, about 99 bpm
BAR = 16 * STEP

# ---- the performance ----
EV, HITS, KNOBS, PAGES, CAPS = [], [], [], [(0, 0)], []
VEL = {'X': 127, 'x': 112, 'o': 78}


def t(bar, step=0):
    return int(round((bar * 16 + step) * STEP))


def ev(s, cmd):
    EV.append((s, cmd))


def hit(s, pad, vel=112):
    ev(s, f'hit {pad} {vel}'); HITS.append((s, pad, vel))


def turn(s, page, knob, delta):
    ev(s, f'turn {knob} {delta}'); KNOBS.append((s, page, knob, delta))


def press(s, page, knob):
    ev(s, f'press {knob}'); KNOBS.append((s, page, knob, 0))


def page(s, p):
    ev(s, f'page {p}'); PAGES.append((s, p))


def pitch(s, pad, semis, delta=1024):
    ev(s, f'pitch {pad} {semis}'); KNOBS.append((s, 0, 0, delta))


def play(bar, bars, pat):
    """pat: {pad: rows of 16 steps ('X' 'x' 'o' a hit, '.' none), repeated over the bars}"""
    for pad, rows in pat.items():
        rows = rows.replace(' ', '')
        for i in range(bars * 16):
            ch = rows[i % len(rows)]
            if ch in VEL:
                hit(t(bar + i // 16, i % 16), pad, VEL[ch])


def caption(b0, b1, title, sub):
    CAPS.append((t(b0), t(b1), title, sub))


WAR = {0: 'x.....x...x..... x.....x.x.x.....', 5: '....x.......x...', 15: '..o...o...o...o.', 23: '........o.......',
       20: '................ ..............x.', 22: 'o............... ................'}

caption(0, 2, 'medieval', 'EP-1320 Medieval sounds as a drum engine for the OP-1   ·   Project Medieval v0.2.2')
hit(t(0, 8), 21, 127); hit(t(0, 8), 0, 127)                  # intro: hell bell, battle kik, a war tom fill
for i, (pad, st) in enumerate([(4, 8), (6, 10), (7, 12), (9, 14)]):
    hit(t(1, st), pad, 100 + 8 * i)

caption(2, 5, 'kit i  war drums', 'Kicks, stomps, war toms, the big clap, chains, anvil and sword')
play(2, 3, WAR)
for pad, st in [(4, 12), (6, 13), (7, 14), (9, 15)]:
    hit(t(4, st), pad, 120)

caption(5, 8, 'kit ii  tavern', 'T2 blue picks the kit: frame drums, clappers, coconuts and tambourines')
page(t(4, 14), 1); turn(t(5), 1, 0, 2048); page(t(6), 0)
play(5, 3, {0: 'x.....x.x....... x.....x...x.....', 12: '....x.......x...', 15: 'o.x.o.x.o.x.o.x.',
            1: '...o......o....o', 5: '.......o......o.', 8: '...........o....'})
hit(t(6), 22, 100); hit(t(7, 12), 23, 127)
for pad, st in [(4, 8), (6, 10), (7, 14)]:
    hit(t(7, st), pad, 118)

caption(8, 11, 'kit iii  armory', 'Junk, scrap, clanks, swords and chains')
page(t(7, 14), 1); turn(t(8), 1, 0, 2048); page(t(9), 0)
play(8, 3, {0: 'x......x..x..... x......x.x......', 3: '....x.......x...', 10: '..o...o...o...o.',
            13: '.o..............', 7: '................ ..............o.'})
hit(t(8), 19, 112); hit(t(9, 8), 18, 118); hit(t(10, 8), 16, 118); hit(t(10, 10), 17, 118); hit(t(10, 12), 22, 127)

caption(11, 14, 'kit iv  royal court', 'The royal kik, plague drums, stabs, trumpet and horn')
page(t(10, 14), 1); turn(t(11), 1, 0, 2048); page(t(12), 0)
play(11, 3, {0: 'x.......x.x.....', 3: '....x.......x...', 1: '..o...o...o..oo.'})
for bar, st, pad in [(11, 0, 15), (11, 6, 12), (11, 10, 14), (12, 0, 23), (12, 8, 20), (12, 12, 17), (13, 0, 16),
                     (13, 8, 22), (13, 14, 13)]:
    hit(t(bar, st), pad, 118)
for pad, st in [(4, 12), (6, 14)]:
    hit(t(13, st), pad, 118)

caption(14, 15, 'kit i', 'Back to the war drums, to shape them')
page(t(13, 14), 1); turn(t(14), 1, 0, -3 * 2048); page(t(15), 0)
play(14, 9, WAR)

caption(15, 17, 'decay', 'T1 white: from the whole sound down to a short hit, and back')
for i in range(16):                                          # 31 -> 4 -> 31
    turn(t(15, i), 0, 2, -2048 if i < 11 else -1024)
    turn(t(16, i), 0, 2, 2048 if i < 11 else 1024)

caption(17, 19, 'drive', 'T1 orange: a soft clip that drives the hits harder. The rings flare and throw sparks')
for i in range(16):
    turn(t(17, i), 0, 3, 2048)                               # 0 -> 31, held for a bar, then off
turn(t(18, 15), 0, 3, -32 * 1024)

caption(19, 21, 'dusk', 'T2 white: a low pass. The moon rises')
page(t(19), 1)
for i in range(14):
    turn(t(19, i), 1, 2, 2048)                               # 0 -> 28
turn(t(20, 15), 1, 2, -32 * 1024)

caption(21, 23, 'age', 'T2 orange: fewer bits and held samples. Dust drifts down')
for i in range(16):
    turn(t(21, i), 1, 3, 2048)
turn(t(22, 15), 1, 3, -32 * 1024)

caption(23, 24, 'reverse', 'T1 blue press: the hell bell swells in backwards')
play(23, 1, {0: 'x.....x...x.....', 15: '..o...o...o...o.'})
page(t(23), 0); ev(t(23), 'sel 21'); press(t(23), 0, 0)
hit(t(23, 10), 21, 127)

caption(24, 25, 'pitch', 'T1 blue turn: the stock pad pitch. The horns tilt with it')
hit(t(24), 0, 127); hit(t(24), 5, 120); hit(t(24, 8), 0, 112)
for i in range(8):                                           # a war tom climbing in whole tones
    pitch(t(24, 2 * i), 4, 2 * i, 2048 if i else 0)
    hit(t(24, 2 * i), 4, 104 + 3 * i)

caption(25, 26.5, 'medieval', 'Project Medieval v0.2.2   ·   sounds: Teenage Engineering EP-1320 Medieval')
pitch(t(25), 4, 0, -14 * 1024)
for pad in (0, 5, 20, 22):
    hit(t(25), pad, 127)
END = t(26, 8)
ev(END, 'end')

EV.sort(key=lambda e: e[0])
script = os.path.join(out, 'demo_script.txt')
with open(script, 'w') as f:
    f.writelines(f'{s} {c}\n' for s, c in EV)

# ---- sound and frames from the engine ----
raw = os.path.join(out, 'demo_mix.s32')
frames_path = os.path.join(out, 'demo_frames.jsonl')
with open(frames_path, 'w') as f:
    subprocess.run([exe, 'demo', script, raw], check=True, stdout=f)
mix = np.fromfile(raw, '<i4').astype(np.float64)
peak = np.abs(mix).max()
gain = 10 ** (-1 / 20) * 32767 / peak
pcm = np.clip(np.round(mix * gain), -32768, 32767).astype('<i2')
wav = os.path.join(out, 'medieval_demo.wav')
with wave.open(wav, 'wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(RATE); w.writeframes(pcm.tobytes())
print(f'mix peak {peak:.0f} of 32767 ({20 * math.log10(peak / 32767):+.1f} dBFS); gain {20 * math.log10(gain):+.1f} dB '
      f'-> {wav}, {len(pcm) / RATE:.1f} s')

# ---- video ----
W, H = 1920, 1080
S = 4.5                                                      # screen scale: 320 x 160 -> 1440 x 720
SX, SY = (W - 320 * S) / 2, 34
BG = (0.06, 0.06, 0.07)
PALE, GREY, RED = (0xAE / 255, 0xB1 / 255, 0xDC / 255), (0.42, 0.43, 0.45), (1, 0x3A / 255, 0x5D / 255)
KNOB_COL = [(0x4D / 255, 0x9E / 255, 1), (0, 0xED / 255, 0x95 / 255), (1, 1, 1), (1, 0x8C / 255, 0x1A / 255)]
KNOB_NAME = [['pitch', 'sound', 'decay', 'drive'], ['kit', 'start', 'dusk', 'age']]
WHITE_KEYS = [0, 2, 4, 6, 7, 9, 11, 12, 14, 16, 18, 19, 21, 23]
BLACK_KEYS = {1: 0, 3: 1, 5: 2, 8: 4, 10: 5, 13: 7, 15: 8, 17: 9, 20: 11, 22: 12}   # key: the white key it follows


def textura(c, x, y, s, text, col, initial=None):
    """the pages' textura at s px per grid unit; (x, y) the top left. Returns the width."""
    c.save(); c.set_line_width(s * 1.05); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    x0 = x
    for i, ch in enumerate(text):
        st = parse(G.get(ch, ''))
        c.set_source_rgb(*(initial if initial and i == 0 else col))
        for p in st:
            c.move_to(x + p[0][0] * s, y + p[0][1] * s)
            for px, py in p[1:]:
                c.line_to(x + px * s, y + py * s)
            if len(p) == 1:
                c.line_to(x + p[0][0] * s, y + p[0][1] * s + 0.1)
            c.stroke()
        x += (advance(st) if ch != ' ' else 4) * s
    c.restore()
    return x - x0


def textura_w(text, s):
    return sum((advance(parse(G.get(ch, ''))) if ch != ' ' else 4) * s for ch in text)


def sans(c, x, y, size, text, col, align=0.0, weight=cairo.FONT_WEIGHT_NORMAL):
    c.select_font_face('Inter', cairo.FONT_SLANT_NORMAL, weight); c.set_font_size(size)
    w = c.text_extents(text).x_advance
    c.set_source_rgb(*col); c.move_to(x - w * align, y); c.show_text(text)


def screen(c, fr):
    c.save(); c.translate(SX, SY)
    c.set_source_rgb(0, 0, 0); c.rectangle(0, 0, 320 * S, 160 * S); c.fill()
    c.rectangle(0, 0, 320 * S, 160 * S); c.clip()
    c.scale(S, S); c.set_line_cap(cairo.LINE_CAP_ROUND)
    for x0, y0, x1, y1, w, col in fr['lines']:
        c.set_source_rgb(*(v / 255 for v in col)); c.set_line_width(w / 1024)
        c.move_to(x0 / 1024, y0 / 1024); c.line_to(x1 / 1024, y1 / 1024); c.stroke()
    c.restore()
    c.set_source_rgb(0.2, 0.2, 0.22); c.set_line_width(2)
    c.rectangle(SX - 10, SY - 10, 320 * S + 20, 160 * S + 20); c.stroke()


def glow(age, life):
    return math.exp(-age / life) if age >= 0 else 0.0


def keys(c, s):
    kw, kh, x0, y0 = 60, 118, SX, 924
    lit = {}
    for hs, pad, vel in HITS:
        if hs <= s:
            g = glow((s - hs) / RATE, 0.22) * vel / 127
            lit[pad] = max(lit.get(pad, 0), g)
    for i, pad in enumerate(WHITE_KEYS):
        g = lit.get(pad, 0)
        c.set_source_rgb(0.86 + 0.14 * g, 0.86 - 0.31 * g, 0.88 - 0.78 * g)
        c.rectangle(x0 + i * kw + 2, y0, kw - 4, kh); c.fill()
    for pad, after in BLACK_KEYS.items():
        g = lit.get(pad, 0)
        c.set_source_rgb(0.16 + 0.84 * g, 0.16 + 0.39 * g, 0.18 - 0.08 * g)
        c.rectangle(x0 + (after + 1) * kw - 19, y0, 38, kh * 0.6); c.fill()


def knobs(c, s, pg):
    x0, y0, r, gap = SX + 14 * 60 + 70, 970, 34, 104
    for p in (0, 1):                                         # T1 / T2
        on = p == pg
        sans(c, x0 - r + p * 70, y0 - 50, 22, f'T{p + 1}', (1, 1, 1) if on else GREY, 0, cairo.FONT_WEIGHT_BOLD)
    for k in range(4):
        cx = x0 + k * gap
        ang, g = -math.pi / 2, 0.0
        for ks, kp, kk, d in KNOBS:
            if kk == k and ks <= s:
                ang += d / 1024 * math.radians(18)
                g = max(g, glow((s - ks) / RATE, 0.5))
        col = KNOB_COL[k]
        c.set_source_rgb(*(v * (0.35 + 0.65 * g) for v in col)); c.arc(cx, y0, r, 0, 2 * math.pi); c.fill()
        c.set_source_rgb(0.06, 0.06, 0.07); c.set_line_width(5)
        c.move_to(cx + 0.25 * r * math.cos(ang), y0 + 0.25 * r * math.sin(ang))
        c.line_to(cx + 0.85 * r * math.cos(ang), y0 + 0.85 * r * math.sin(ang)); c.stroke()
        name = KNOB_NAME[pg][k]
        sans(c, cx, y0 + r + 30, 19, name, tuple(GREY[i] + (1 - GREY[i]) * g for i in range(3)), 0.5)


def at(lst, s, default):
    v = default
    for ts, x in lst:
        if ts <= s:
            v = x
    return v


ffmpeg = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'bgra', '-s', f'{W}x{H}',
                           '-r', str(FPS), '-i', '-', '-i', wav, '-c:v', 'libx264', '-preset', 'medium', '-crf', '18',
                           '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-ac', '2', '-b:a', '256k', '-shortest',
                           '-movflags', '+faststart', os.path.join(out, 'medieval_demo.mp4')], stdin=subprocess.PIPE)
surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H)
c = cairo.Context(surf)
n = 0
with open(frames_path) as f:
    for line in f:
        fr = json.loads(line)
        s = int(fr['name']) * FRAME
        c.set_source_rgb(*BG); c.paint()
        screen(c, fr)
        cap = next((x for x in CAPS if x[0] <= s < x[1]), None)
        if cap:
            a = min(1.0, (s - cap[0]) / (0.3 * RATE), (cap[1] - s) / (0.3 * RATE) if cap[1] < END else 1.0)
            fade = lambda col: tuple(BG[i] + (col[i] - BG[i]) * a for i in range(3))
            ts = 5
            textura(c, (W - textura_w(cap[2], ts)) / 2, 790, ts, cap[2], fade(PALE), fade(RED))
            sans(c, W / 2, 892, 27, cap[3], fade((0.85, 0.85, 0.88)), 0.5)
        keys(c, s)
        knobs(c, s, at(PAGES, s, 0))
        sans(c, W / 2, 1066, 17, 'Rendered on a PC from the plugin\'s own code: the real engine, pages and EP-1320 '
             'samples, dry (no OP-1 FX). Not a recording of the OP-1.', GREY, 0.5)
        surf.flush()
        ffmpeg.stdin.write(bytes(surf.get_data()))
        n += 1
ffmpeg.stdin.close()
ffmpeg.wait()
print('->', os.path.join(out, 'medieval_demo.mp4'), n, 'frames')
