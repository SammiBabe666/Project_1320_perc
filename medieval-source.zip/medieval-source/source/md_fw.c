/* medieval as an OP-1 drum type (kennel feature API, op1_feature_drum.h): the drum hook drum+ uses.
 * The core calls md_note_on / md_render / md_note_off for every voice of every drum kit. A voice struck on a medieval
 * kit plays a sound of the EP-1320 bank (md_voice.c) and ignores the kit's own samples; every other kit, and every
 * voice struck on one, goes to the stock DrumSampler functions unchanged.
 * Stock pad words still apply to medieval pads: pitch (T1 blue), volume (Shift + T1 orange), reverse and one-shot /
 * gate (T1 blue / green presses), and the velocity of each hit.
 * Persistence: the kit's "op1r" object, {"engine": "medieval", "kit", "decay", "drive", "dusk", "age",
 * "pads": [[sound, start], ... 24]}, in the drum patch JSON: the core keeps it across load, the stock writer saves it.
 * Copyright (C) 2026 Sammi (Project Medieval). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and
 * NOTICE). */
#include "op1_feature_drum.h"
#include "md_fw.h"

#define MD_SLOTS   OP1_DRUM_SLOTS
#define MD_VOICES  OP1_DRUM_VOICES

#ifndef OP1_HOST
#define VOICE_OBJ  ((void *const *)0x01AAAD30)                /* voice objects [12] */
#define VOICE_PAD  ((const int32_t *)0xFF801334)              /* pad of voice v (note_on_drum) */
#define VOICE_VEL  ((const int16_t *)0xFF8012EC)              /* velocity << 8 of voice v */
#define DRUM_SLOT  (*(const volatile int32_t *)0x01AAAC10)    /* current drum slot */
#define BUF_INC    ((const int32_t *)0xFF801950)              /* per-sample increments (<< 17), refilled per voice */
#define BUF_VEL    ((const int16_t *)0xFF801D50)              /* per-sample velocity << 8, per voice */
#define STOCK_RENDER   OP1_DRUM_STOCK_RENDER
#define STOCK_NOTE_ON  OP1_DRUM_STOCK_NOTE_ON
#define STOCK_NOTE_OFF OP1_DRUM_STOCK_NOTE_OFF
#define DRUM_TO_PATCH  ((void (*)(void *))0x019FFC50)         /* live pad table -> patch JSON (+ changed) */
#define DRUM_PATCH(s)  ((void *)(0x01DDD9A8 + (s) * 0x38))
/* Json::Value (16 bytes, type byte at +8), firmware functions as drumplus/dp_fw.c and kennel/kn_drum.c use them */
#define JV_KEY      ((void *(*)(void *, const char *))0x019BFEB4)     /* Value::operator[](const char *) */
#define JV_IDX      ((void *(*)(void *, unsigned))0x019BFAF8)         /* Value::operator[](ArrayIndex) */
#define JV_ASSIGN   ((void *(*)(void *, const void *))0x019BDDC0)     /* Value::operator= */
#define JV_SIZE     ((unsigned (*)(const void *))0x019BE8D8)          /* Value::size */
#define JV_DTOR     ((void (*)(void *, int))0x019BDD18)
#define JV_FROM_INT ((void *(*)(void *, int))0x019BD890)              /* Value(int) */
#else
#include "harness/md_host.h"                                  /* the same names, on host arrays and a small JSON */
#endif
enum { JV_NULL = 0, JV_INT = 1, JV_UINT = 2, JV_STRING = 4, JV_ARRAY = 6, JV_OBJECT = 7 };
enum { ST_OFF = 0, ST_HELD = 1, ST_RELEASED = 2 };            /* stock voice state (drumplus/dp_voice.h) */
typedef struct { int32_t pos, state; uint32_t blocks; } stock_voice;

md_kit_t md_slot[MD_SLOTS];
uint8_t md_foreign[MD_SLOTS];                                 /* the slot's "op1r" belongs to another engine (drum+) */
static md_voice_t md_v[MD_VOICES];
static uint8_t md_mine[MD_VOICES];                            /* the voice's last hit was a medieval one */
static uint8_t md_vslot[MD_VOICES];

/* for the pages (md_page.c): a counter that steps on every hit, the last hit's pad and velocity, and a clock */
volatile uint8_t md_hit_count, md_hit_pad, md_hit_vel;
volatile uint32_t md_samples;                                 /* audio clock: 64 per tick */

static int voice_index(void *self)
{
    for (int i = 0; i < MD_VOICES; i++) if (VOICE_OBJ[i] == self) return i;
    return -1;
}
static stock_voice *model(void *self) { return (stock_voice *)((uint8_t *)self + 8); }
static int pad_of(int v) { int p = VOICE_PAD[v]; return (uint32_t)p < MD_PADS ? p : 0; }

static void md_note_on(void *self, const op1_drum_pad *pad)
{
    int v = voice_index(self), slot = DRUM_SLOT;
    if (v < 0 || (uint32_t)slot >= MD_SLOTS || !md_slot[slot].on) {
        if (v >= 0) {                                         /* a stock hit takes the voice: forget the medieval */
            md_mine[v] = 0;                                   /* sound it played, so a later medieval hit doesn't */
            md_v[v].state = MD_OFF;                           /* fade a stale sample out (v0.2.3) */
        }
        STOCK_NOTE_ON(self, pad);
        return;
    }
    int p = pad_of(v);
    stock_voice *m = model(self);
    m->state = ST_HELD; m->blocks = 0; m->pos = 0;
    md_mine[v] = 1; md_vslot[v] = (uint8_t)slot;
    md_voice_on(&md_v[v], &md_slot[slot], p, pad->reverse >> 14);
    md_hit_pad = (uint8_t)p; md_hit_vel = (uint8_t)(VOICE_VEL[v] >> 8); md_hit_count++;
}

static void md_note_off(void *self, const op1_drum_pad *pad)
{
    int v = voice_index(self);
    if (v < 0 || !md_mine[v]) { STOCK_NOTE_OFF(self, pad); return; }
    stock_voice *m = model(self);
    if (m->state == ST_OFF) return;
    if ((pad->playmode >> 13) != 1) md_voice_release(&md_v[v]);  /* gate (and loop): stop, with a short fade */
    m->state = ST_RELEASED;                                       /* one-shot plays on; render says when it is done */
}

static void md_render(void *self, int16_t *out, const op1_drum_pad *pad)
{
    int v = voice_index(self);
    if (v < 0 || !md_mine[v]) { STOCK_RENDER(self, out, pad); return; }
    stock_voice *m = model(self);
    if (!md_voice_render(&md_v[v], &md_slot[md_vslot[v]], out, BUF_INC, BUF_VEL, pad->volume)) m->state = ST_OFF;
    m->blocks++;
}

static void md_tick(const op1_beat_t *beat) { (void)beat; md_samples += 64; }

/* ---- persistence ---- */
static uint8_t jv_type(const void *v) { return ((const uint8_t *)v)[8]; }
static int32_t jv_int(const void *v, int32_t dflt)
{
    int32_t w = *(const int32_t *)v;                          /* 32-bit Int / UInt in the 8-byte union */
    return jv_type(v) == JV_INT || (jv_type(v) == JV_UINT && w >= 0) ? w : dflt;
}
static int jv_is_str(const void *v, const char *s)
{
    if (jv_type(v) != JV_STRING) return 0;
    const char *p = *(const char *const *)v;
    if (!p) return 0;
    while (*s && *p == *s) p++, s++;
    return *p == *s;
}
static int step_of(int32_t x) { return x < 0 ? 0 : x > MD_STEPS - 1 ? MD_STEPS - 1 : (int)x; }

/* the slot's kit from its "op1r" object (0: a stock kit). Not a medieval kit: the slot plays stock. */
static void md_load(int slot, void *op)
{
    if ((unsigned)slot >= MD_SLOTS) return;
    md_kit_t *k = &md_slot[slot];
    k->on = 0;
    md_foreign[slot] = 0;
    if (!op || jv_type(op) != JV_OBJECT) return;
    if (!jv_is_str(JV_KEY(op, "engine"), MD_ENGINE)) { md_foreign[slot] = 1; return; }
    md_kit_defaults(k);
    k->kit = (uint8_t)(jv_int(JV_KEY(op, "kit"), 0) & 3);
    md_kit_set(k, k->kit);
    k->decay = (uint8_t)step_of(jv_int(JV_KEY(op, "decay"), MD_STEPS - 1));
    k->drive = (uint8_t)step_of(jv_int(JV_KEY(op, "drive"), 0));
    k->dusk = (uint8_t)step_of(jv_int(JV_KEY(op, "dusk"), 0));
    k->age = (uint8_t)step_of(jv_int(JV_KEY(op, "age"), 0));
    void *pads = JV_KEY(op, "pads");
    if (jv_type(pads) == JV_ARRAY) {
        unsigned np = JV_SIZE(pads);
        for (unsigned p = 0; p < np && p < MD_PADS; p++) {
            void *a = JV_IDX(pads, p);
            if (jv_type(a) != JV_ARRAY || JV_SIZE(a) < 2) continue;
            int32_t s = jv_int(JV_IDX(a, 0), -1);
            if (s >= 0 && s < MD_NSOUNDS) k->snd[p] = (uint8_t)s;
            k->start[p] = (uint8_t)step_of(jv_int(JV_IDX(a, 1), 0));
        }
    }
    k->on = 1;                                                /* last: the audio thread checks it on a hit */
}

static void put_int(void *dst, int32_t x)
{
    uint32_t tmp[4];
    JV_FROM_INT(tmp, x);
    JV_ASSIGN(dst, tmp);
    JV_DTOR(tmp, 2);
}

/* the slot's kit into its "op1r" object, then marks the patch changed (the stock writer saves it) */
void md_store(int slot)
{
    if ((unsigned)slot >= MD_SLOTS || !md_slot[slot].on) return;
    const md_kit_t *k = &md_slot[slot];
    void *op = JV_KEY(OP1_DRUM_PATCH_JSON(slot), OP1_DRUM_KEY);
    if (jv_type(op) != JV_OBJECT) return;                     /* not a kit of the type */
    put_int(JV_KEY(op, "kit"), k->kit);
    put_int(JV_KEY(op, "decay"), k->decay);
    put_int(JV_KEY(op, "drive"), k->drive);
    put_int(JV_KEY(op, "dusk"), k->dusk);
    put_int(JV_KEY(op, "age"), k->age);
    void *pads = JV_KEY(op, "pads");
    if (jv_type(pads) == JV_ARRAY || jv_type(pads) == JV_NULL)
        for (int p = 0; p < MD_PADS; p++) {
            void *a = JV_IDX(pads, (unsigned)p);              /* (null -> array; grows with null entries) */
            if (jv_type(a) != JV_ARRAY && jv_type(a) != JV_NULL) continue;
            put_int(JV_IDX(a, 0), k->snd[p]);
            put_int(JV_IDX(a, 1), k->start[p]);
        }
    md_pad_words_changed(slot);
}

void md_pad_words_changed(int slot) { DRUM_TO_PATCH(DRUM_PATCH(slot)); }

/* A kit just made medieval (the "drum+" row picked in the drum type browser) may not have been loaded through
 * md_load: the pages call this while they show the slot. The core wrote "op1r": {"engine": "medieval"}. */
void md_check_slot(int slot)
{
    if ((unsigned)slot >= MD_SLOTS || md_slot[slot].on || md_foreign[slot]) return;
    void *op = JV_KEY(OP1_DRUM_PATCH_JSON(slot), OP1_DRUM_KEY);  /* (the page shows only slots with the key) */
    if (jv_type(op) != JV_OBJECT) return;
    md_load(slot, op);
    if (md_slot[slot].on) md_store(slot);                     /* write the defaults, so the kit saves complete */
}

static const struct op1_drum_type md_type = {
    .api = OP1_DRUM_API, .id = OP1_DRUM_TYPE_ID, .name = MD_ENGINE,
    .load = md_load,
    .render = md_render, .note_on = md_note_on, .note_off = md_note_off,
    .page_init = md_page_init, .page_draw = md_page_draw, .page_turn = md_page_turn, .page_press = md_page_press,
};
/* priority 400: before the built-in drum+ (500), so the core takes this file's drum type (kn_drum_finish takes the
 * first feature, in priority order, that has one). No claims: a claim the built-in drum+ shared would switch this
 * file off. */
const op1_feature_t FEATURE_medieval = {
    .api = OP1_FEATURE_API, .priority = 400, .name = "medieval", .tick = md_tick, .drum = &md_type,
};
